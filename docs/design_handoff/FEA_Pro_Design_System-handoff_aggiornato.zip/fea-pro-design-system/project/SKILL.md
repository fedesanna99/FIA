---
name: fea-pro-design
description: Use this skill to generate well-branded interfaces and assets for FEA Pro — a finite element analysis (FEM) webapp for Italian structural engineers — either for production or throwaway prototypes/mocks. Contains essential design guidelines (Precision v2.0 light direction · sharp geometry · hairline borders · cyan singular accent), colors, type (Inter / Inter Tight / JetBrains Mono), fonts, assets, and React UI kit components for prototyping. Italian-language product covering Eurocodici EC2/EC3/EC5/EC8 + NTC 2018.
user-invocable: true
---

Read the `README.md` file within this skill first — it contains:

- Product context (FEA Pro · v2.3.7, frozen pending UX redesign)
- Persona (Italian structural engineer freelance, mobile for consultation, desktop for setup)
- Content fundamentals (Italian, tecnico-onesto tone, sentence case, mono uppercase eyebrows, no emoji, normative always named)
- Visual foundations (Precision v2.0: light default, all radii 0, hairline 1px borders, no shadows beyond hairlines, cyan singular accent)
- Iconography (lucide-react, stroke 1.8, currentColor, unicode math symbols for σ τ ε δ etc.)
- 7 non-negotiable UX principles (every result has a number; every element ispezionabile in 1 tap; mobile-first for consultation; discoverability via UI; system state always clear; normative standards always named; professional catalog)

Then explore the other files:

- `colors_and_type.css` — all design tokens as CSS custom properties (light + dark themes, type scale, motion, spacing, z-index)
- `assets/` — logo SVGs (note: favicon `#185fa5` is historical, not in Precision cyan palette — flag if you reuse it)
- `preview/` — 30+ small reference cards for type, colors, spacing, components, brand
- `ui_kits/webapp_desktop/` — JSX components mirroring the current Precision desktop UI (Dashboard, TopBar, HubCard, ProjectCard, sidebar widgets)
- `ui_kits/mobile_redesign/` — scaffolding for the mobile redesign target (in iOS frames). Element Inspector + Results-with-peak-labels demonstrate the two most important UX principles.
- `uploads/` — original briefs: `UX_REDESIGN_BRIEF.md`, `CLAUDE_DESIGN_KICKOFF_PROMPT.md`, `PROJECT_STATE.md`

### When creating visual artifacts (slides, mocks, throwaway prototypes)

Copy assets out and create static HTML files for the user to view. Import `colors_and_type.css` to get tokens for free. Reuse the JSX components from `ui_kits/webapp_desktop/` (load via `<script type="text/babel" src="…">`) or copy the patterns directly into your file.

### When working on production code

The source of truth is the repo [github.com/fedesanna99/FIA](https://github.com/fedesanna99/FIA). This skill is a faithful extract — explore the repo for store layout (Zustand multi-store), API client, Three.js viewport engine, and the actual TSX components. Stack is **immutable**: React 18 + TypeScript + Vite + Tailwind v3 + Three.js + Zustand + TanStack Query.

### If the user invokes this skill without other guidance

Ask what they want to build or design — a slide deck for investors? A new component mockup? A redesign of an existing screen? An asset (logo lockup, social card)? — then ask 3-5 focused questions in Italian or English depending on the user's language. Act as an expert designer who outputs HTML artifacts *or* production code, matching the user's need. **Default to Italian copy** unless the user signals otherwise.

### Brand musts (never violate without explicit user request)

1. Italian language for UI copy.
2. Sentence case for titles, mono UPPERCASE for eyebrow/tag/shortcut.
3. No emoji in UI.
4. Every result has a numeric label (`M_max = 12.45 kNm @ x = 2.25 m`).
5. Every normative reference is named (`EC3 §6.3.2`, `NTC18 §3.5.3`).
6. Cyan singular accent — never invent secondary accents.
7. All radii are 0 — no rounded corners except `--r-full` for circles.
8. Hairline borders only — never multi-layer drop shadows.
9. Unicode math symbols (σ, τ, ε, δ, φ, λ, ξ, Δ, ≤, ≥, ±) — never SVG substitutes.
10. The only gradient permitted is the `run` button (emerald 500→600) for "Esegui analisi".
