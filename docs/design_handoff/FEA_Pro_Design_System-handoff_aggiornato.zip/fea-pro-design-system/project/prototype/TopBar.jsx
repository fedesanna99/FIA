// TopBar — dynamic breadcrumb + Esegui button + save chip + user.
function TopBar({ crumbs = [], onCrumb, onRun, running, savedAt = "14:32", user = "FS" }) {
  return (
    <header className="topbar" role="banner">
      <button
        className="brand-block"
        type="button"
        onClick={() => onCrumb && onCrumb({ id: "home" })}
        style={{ cursor: "pointer", border: "none", background: "none", padding: "0 16px 0 0" }}
        aria-label="Torna alla home"
      >
        <div className="brand-mark"><span>F</span></div>
        <span className="brand-name">FEA Pro</span>
      </button>

      {crumbs.length > 0 && (
        <nav className="crumbs" aria-label="Breadcrumb">
          {crumbs.map((c, i) => (
            <React.Fragment key={i}>
              {i > 0 && <span className="sep">/</span>}
              {c.onClick ? (
                <button type="button" className={`crumb ${c.live ? "live" : ""}`} onClick={c.onClick}>
                  {c.label}
                </button>
              ) : (
                <span className={`crumb ${c.live ? "live" : ""}`}>{c.label}</span>
              )}
            </React.Fragment>
          ))}
        </nav>
      )}

      <span className="spacer" />

      <span className="save-chip">
        <Icon.Check s={10} />
        Salvato {savedAt}
      </span>

      {onRun && (
        <button
          className="tb-btn run"
          type="button"
          onClick={onRun}
          disabled={running}
          style={running ? { opacity: 0.6 } : {}}
        >
          <Icon.Play /> {running ? "In corso…" : "Esegui"}
        </button>
      )}

      <button className="tb-btn icon" type="button" aria-label="Notifiche">
        <Icon.Bell />
      </button>

      <div className="user-chip">
        <div className="avatar">{user}</div>
      </div>

      <span className="tier-pill">FREE</span>
    </header>
  );
}

window.TopBar = TopBar;
