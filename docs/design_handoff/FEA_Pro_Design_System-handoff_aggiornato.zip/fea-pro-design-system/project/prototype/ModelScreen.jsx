// Model viewer — center canvas + right inspector.
// Click an element to populate inspector (default = empty state).
function ModelScreen({ modelId, modelName, status, addToast }) {
  const [selected, setSelected] = React.useState(modelId === "telaio" ? "EL5" : null);
  const [tool, setTool] = React.useState("select");
  const [view, setView] = React.useState("stress"); // stress | deformed | wireframe

  const onApplyHEA240 = () => {
    setSelected(null);
    addToast({
      kind: "success",
      ttl: "HEA 240 applicata",
      msg: "EL5 aggiornato. Nuova UR = 0.86 — entro limiti EC3 §6.3.3.",
    });
  };

  return (
    <div className="viewer" data-screen-label="02 Model viewer">

      {/* CENTER CANVAS */}
      <div className="viewer-canvas">

        <div className="viewer-toolbar">
          <button type="button" className={`tool ${tool === "select" ? "active" : ""}`} onClick={() => setTool("select")} title="Seleziona"><Icon.Cursor /></button>
          <button type="button" className={`tool ${tool === "pan" ? "active" : ""}`}    onClick={() => setTool("pan")}    title="Pan"><Icon.Pan /></button>
          <button type="button" className={`tool ${tool === "zoom" ? "active" : ""}`}   onClick={() => setTool("zoom")}   title="Zoom"><Icon.Zoom /></button>
          <button type="button" className="tool" title="Visualizza"><Icon.Eye /></button>
        </div>

        <svg className="model" viewBox="0 0 1200 700" preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id="stress-grad" x1="0" y1="1" x2="1" y2="0">
              <stop offset="0%" stopColor="#8FD14F" />
              <stop offset="40%" stopColor="#FBBF24" />
              <stop offset="75%" stopColor="#FB923C" />
              <stop offset="100%" stopColor="#F87171" />
            </linearGradient>
            <marker id="arr" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M0,0 L5,5 L0,10 z" fill="#FB923C" />
            </marker>
          </defs>

          <g transform="translate(600 380)">
            {/* Back face (isometric depth) */}
            <g stroke="#262B33" strokeWidth="1" fill="#16191F" opacity="0.6">
              <polygon points="-260,-220 -220,-260 -220,180 -260,140" />
              <polygon points="260,-220 220,-260 220,180 260,140" />
              <polygon points="-220,-260 220,-260 260,-220 -260,-220" />
            </g>

            {/* Front faces — stress contour */}
            {view === "stress" && (
              <>
                <polygon points="-260,-220 -220,-220 -220,180 -260,180"
                         fill="url(#stress-grad)" opacity="0.42"
                         stroke="#F2F4F7" strokeWidth="1.2" />
                <polygon points="220,-220 260,-220 260,180 220,180"
                         fill="url(#stress-grad)" opacity="0.42"
                         stroke="#F2F4F7" strokeWidth="1.2" />
                <polygon points="-260,-260 220,-260 220,-220 -260,-220"
                         fill="url(#stress-grad)" opacity="0.55"
                         stroke="#F2F4F7" strokeWidth="1.2" />
              </>
            )}
            {view !== "stress" && (
              <g stroke="#F2F4F7" strokeWidth="1.4" fill="none">
                <polygon points="-260,-220 -220,-220 -220,180 -260,180" />
                <polygon points="220,-220 260,-220 260,180 220,180" />
                <polygon points="-260,-260 220,-260 220,-220 -260,-220" />
              </g>
            )}

            {/* Centerline */}
            <line x1="-240" y1="-240" x2="240" y2="-240" stroke="#F2F4F7" strokeWidth="0.8" strokeDasharray="2,4" opacity="0.4" />

            {/* Deformed shape ghost */}
            {(view === "deformed" || view === "stress") && (
              <g stroke="#6EDDF5" strokeWidth="1.8" fill="none" strokeDasharray="3,4" opacity="0.9">
                <path d="M-240,180 L-240,-240 Q0,-200 240,-240 L240,180" />
              </g>
            )}

            {/* Nodes */}
            <g fill="#F2F4F7">
              <circle cx="-240" cy="-240" r="4" />
              <circle cx="240"  cy="-240" r="4" />
              <circle cx="-240" cy="180"  r="4" />
              <circle cx="240"  cy="180"  r="4" />
            </g>

            {/* Critical node animation */}
            {selected === "EL5" && (
              <>
                <circle cx="0" cy="-240" r="7" fill="#F87171" stroke="#FFFFFF" strokeWidth="1.5" />
                <circle cx="0" cy="-240" r="13" fill="none" stroke="#F87171" strokeWidth="1.5" opacity="0.5">
                  <animate attributeName="r" values="13;22;13" dur="1.8s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.6;0;0.6" dur="1.8s" repeatCount="indefinite" />
                </circle>
              </>
            )}

            {/* Fixed supports */}
            <g stroke="#F2F4F7" strokeWidth="1.2" fill="none">
              <line x1="-280" y1="180" x2="-200" y2="180" />
              <g transform="translate(-280 180)">
                {[0,1,2,3,4,5].map(i => (
                  <line key={i} x1={i*13} y1="0" x2={i*13+8} y2="14" />
                ))}
              </g>
              <line x1="200" y1="180" x2="280" y2="180" />
              <g transform="translate(200 180)">
                {[0,1,2,3,4,5].map(i => (
                  <line key={i} x1={i*13} y1="0" x2={i*13+8} y2="14" />
                ))}
              </g>
            </g>

            {/* Distributed load */}
            <g stroke="#FB923C" strokeWidth="1.2" fill="none">
              <line x1="-220" y1="-300" x2="220" y2="-300" />
              {[-200,-160,-120,-80,-40,0,40,80,120,160,200].map(x => (
                <line key={x} x1={x} y1="-300" x2={x} y2="-272" markerEnd="url(#arr)" />
              ))}
            </g>

            {/* Element labels (clickable hotspots) */}
            <g onClick={() => setSelected("EL3")} style={{ cursor: "pointer" }}>
              <line x1="-240" y1="20" x2="-260" y2="20" stroke="transparent" strokeWidth="40" />
            </g>
            <g onClick={() => setSelected("EL5")} style={{ cursor: "pointer" }}>
              <line x1="-50" y1="-240" x2="50" y2="-240" stroke="transparent" strokeWidth="40" />
            </g>
          </g>
        </svg>

        {/* In-canvas annotations */}
        {selected === "EL5" && (
          <>
            <div className="ann" style={{ top: "12%", left: "53%" }}>
              <span className="lbl">M<sub>max</sub> @ mezzeria · x = 4.000 m</span>
              <span className="val warn">62.10<small>kNm</small></span>
              <span className="meta">trave HEA 220 · S355 · EC3 §6.3.3</span>
            </div>
            <div className="ann" style={{ top: "32%", left: "8%" }}>
              <span className="lbl">UR critico · EL5</span>
              <span className="val bad">UR = 1.18</span>
              <span className="meta">stabilità flesso-torsionale superata</span>
            </div>
            <div className="ann" style={{ top: "62%", left: "70%" }}>
              <span className="lbl">δ<sub>max</sub> orizzontale</span>
              <span className="val">8.42<small>mm</small></span>
              <span className="meta">H / 712 &lt; H / 250 ✓</span>
            </div>
          </>
        )}

        {/* Legend at bottom */}
        <div className="viewer-legend" role="tablist">
          <button type="button" className={`seg ${view === "stress" ? "active" : ""}`}    onClick={() => setView("stress")}>
            <span className="sw" style={{ background: "linear-gradient(90deg, #8FD14F, #FBBF24, #FB923C, #F87171)" }} />
            σ Sforzi
          </button>
          <button type="button" className={`seg ${view === "deformed" ? "active" : ""}`} onClick={() => setView("deformed")}>
            δ Deformata
          </button>
          <button type="button" className={`seg ${view === "wireframe" ? "active" : ""}`} onClick={() => setView("wireframe")}>
            Wireframe
          </button>
        </div>
      </div>

      {/* RIGHT INSPECTOR */}
      <aside className="inspector" aria-label="Ispettore selezione">
        {selected === "EL5" ? (
          <>
            <div className="inspector-head">
              <div className="left">
                <span className="ttl">Elemento selezionato</span>
                <span className="name">EL5 · HEA 220</span>
                <span className="sub">S355 · L = 6.000 m</span>
              </div>
              <div className="ur">
                <span className="v">1.18</span>
                <span className="l">UR<sub>max</sub></span>
              </div>
            </div>

            <div className="kpi-grid">
              <div className="kpi">
                <span className="k">N</span>
                <span className="v">−1042.50<small>kN</small></span>
                <span className="pos">@ nodo i</span>
              </div>
              <div className="kpi">
                <span className="k">V<sub>y</sub></span>
                <span className="v">61.40<small>kN</small></span>
                <span className="pos">@ nodo j</span>
              </div>
              <div className="kpi">
                <span className="k">M<sub>z,max</sub></span>
                <span className="v">121.20<small>kNm</small></span>
                <span className="pos">@ x = 3.00 m</span>
              </div>
              <div className="kpi">
                <span className="k">σ<sub>max</sub></span>
                <span className="v">324.80<small>MPa</small></span>
                <span className="pos">f<sub>y</sub> = 355</span>
              </div>
            </div>

            <div className="checks">
              <span className="checks-ttl">Verifiche EC3 / NTC18</span>
              <div className="check">
                <div className="row"><span className="nm">N + M <small>§6.2.1</small></span><span className="vv ok">UR = 0.42</span></div>
                <div className="bar"><div style={{ width: "42%", background: "var(--success)" }} /></div>
              </div>
              <div className="check">
                <div className="row"><span className="nm">Flesso-tors. <small>§6.3.3</small></span><span className="vv bad">UR = 1.18</span></div>
                <div className="bar"><div style={{ width: "100%", background: "var(--danger)" }} /></div>
              </div>
              <div className="check">
                <div className="row"><span className="nm">Taglio <small>§6.2.6</small></span><span className="vv ok">UR = 0.18</span></div>
                <div className="bar"><div style={{ width: "18%", background: "var(--success)" }} /></div>
              </div>
            </div>

            <div className="suggest">
              <span className="eb">Copilot · suggerimento</span>
              <p>
                Stabilità flesso-torsionale supera <b>UR = 1</b>.
                Una <b>HEA 240</b> riduce UR a 0.86 mantenendo lo stesso peso/m (+8%).
              </p>
              <div className="actions">
                <button type="button" className="a-btn primary" onClick={onApplyHEA240}>Applica HEA 240</button>
                <button type="button" className="a-btn ghost">Vedi 3 alternative</button>
              </div>
            </div>
          </>
        ) : (
          <div className="inspector-empty">
            <Icon.Cursor s={28} />
            <span className="ttl">Nessuna selezione</span>
            <p>Clicca su un nodo, una trave o un pilastro nel viewport per ispezionare le proprietà e le verifiche.</p>
          </div>
        )}
      </aside>
    </div>
  );
}

window.ModelScreen = ModelScreen;
