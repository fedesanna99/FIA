// HomeScreen — D · Essenziale, but clickable.
function HomeScreen({ goto }) {
  const recent = [
    { id: "telaio", name: "Telaio portale 2D",        is3d: false, status: "run" },
    { id: "trave",  name: "Trave bi-appoggiata UC1",  is3d: false, status: "ok"  },
    { id: "ret3d",  name: "Reticolo 3D · Capannone",  is3d: true,  status: "ok"  },
    { id: "q4",     name: "Piastra Q4 2×2 m",         is3d: false, status: "draft"},
  ];

  return (
    <div className="home" data-screen-label="01 Home">

      <div className="home-main">

        <section className="hero" aria-label="Hero">
          <span className="hero-eyebrow"><span className="dot" /> 4 modelli · 1 in corso</span>
          <h1>Inizia un'analisi.</h1>
        </section>

        <section className="hubs" aria-label="Hub di lavoro">
          <button type="button" className="hub studio" onClick={() => goto({ id: "studio" })}>
            <span className="hub-tag studio">/ Studio Pro</span>
            <h2>Studio Pro</h2>
            <p>Modalità expert. Tutti gli strumenti.</p>
            <span className="cta">Apri <Icon.ArrowR /></span>
          </button>

          <button type="button" className="hub percorsi" onClick={() => goto({ id: "percorsi" })}>
            <span className="hub-tag percorsi">/ Percorsi</span>
            <h2>Percorsi</h2>
            <p>Guidato. Step per step.</p>
            <span className="cta">Apri <Icon.ArrowR /></span>
          </button>
        </section>

        <section aria-label="Modelli recenti">
          <div className="sect-head">
            <h2>Recenti</h2>
            <a href="#" onClick={(e) => e.preventDefault()}>Tutti →</a>
          </div>
          <div className="pgrid">
            {recent.map(m => (
              <ProjectCardClickable
                key={m.id}
                {...m}
                onClick={() => goto({ id: "model", modelId: m.id, modelName: m.name, status: m.status })}
              />
            ))}
          </div>
        </section>

      </div>

      <aside className="home-side" aria-label="Sidebar">
        <CreditsWidget used={42} cap={100} tier="FREE" />
      </aside>
    </div>
  );
}

function ProjectCardClickable({ name, is3d, status, onClick }) {
  const labels = { ok: "OK", run: "RUN", draft: "DRAFT" };
  return (
    <button type="button" className="pcard" onClick={onClick}>
      <div className="thumb">
        <div className="thumb-grid" />
        <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }} viewBox="0 0 200 120" preserveAspectRatio="xMidYMid meet">
          {is3d ? (
            <g stroke="var(--ink-muted)" strokeWidth="1.4" fill="none">
              <rect x="40" y="32" width="120" height="56" />
              <line x1="40"  y1="32" x2="60"  y2="20" />
              <line x1="160" y1="32" x2="180" y2="20" />
              <line x1="40"  y1="88" x2="60"  y2="76" />
              <line x1="160" y1="88" x2="180" y2="76" />
              <rect x="60" y="20" width="120" height="56" />
            </g>
          ) : (
            <g stroke="var(--ink-muted)" strokeWidth="1.4" fill="none">
              <line x1="30" y1="100" x2="30" y2="30" />
              <line x1="170" y1="100" x2="170" y2="30" />
              <line x1="30" y1="30" x2="170" y2="30" />
              <line x1="30" y1="100" x2="170" y2="100" />
              <path d="M30,30 Q100,18 170,30" stroke="var(--accent)" strokeWidth="1.5" strokeDasharray="3,3" />
            </g>
          )}
        </svg>
      </div>
      <div className="meta">
        <div className="name">{name}</div>
        <span className={`pstatus ${status}`}>{labels[status]}</span>
      </div>
    </button>
  );
}

function CreditsWidget({ used = 42, cap = 100 }) {
  const pct = Math.min(100, (used / cap) * 100);
  return (
    <section className="widget" aria-label="Crediti">
      <div className="widget-head">
        <span className="title">Crediti · Maggio</span>
        <span className="tier-pill">FREE</span>
      </div>
      <div className="widget-big">
        <span className="n">{used}</span>
        <span className="d">/ {cap}</span>
      </div>
      <div className="progress"><div style={{ width: `${pct}%` }} /></div>
      <div className="widget-foot">
        <span>€{(used * 0.1).toFixed(2).replace(".", ",")} spesi</span>
        <span>reset 1 giu</span>
      </div>
    </section>
  );
}

window.HomeScreen = HomeScreen;
