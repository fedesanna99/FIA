// Percorsi — list of guided workflows.
function PercorsiScreen({ goto, addToast }) {
  const paths = [
    {
      n: "01",
      name: "Verifica telaio 2D",
      sub: "Genera o importa il telaio, applica carichi e combinazioni, esegui le verifiche EC3 §6.2/§6.3. Output: relazione PDF con catene di calcolo.",
      steps: ["Geometria", "Materiali", "Carichi", "Combinazioni", "Verifiche", "Report"],
      target: "telaio",
    },
    {
      n: "02",
      name: "Beam check rapido",
      sub: "Singola trave. Sezione catalogo o parametrica, vincoli, carichi distribuiti/concentrati. UR per verifica in 2 minuti.",
      steps: ["Sezione", "Vincoli", "Carichi", "UR"],
      target: "trave",
    },
    {
      n: "03",
      name: "Pilastro CA · NTC18 §7.4.4",
      sub: "Pilastro armato. Verifica pressoflessione + taglio + duttilità. Riferimenti normativi sempre nominati.",
      steps: ["Sezione", "Armatura", "Sollecitazioni", "Verifiche"],
      target: null,
    },
    {
      n: "04",
      name: "Mensola legno · EC5",
      sub: "Trave a sbalzo in legno lamellare. Classi C18-C24-GL24h. SLU + SLE + verifica frecce L/250.",
      steps: ["Geometria", "Materiale", "Carichi", "UR"],
      target: null,
    },
  ];

  return (
    <div className="paths" data-screen-label="04 Percorsi">
      <div className="hero" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <span className="hero-eyebrow"><span className="dot" style={{ background: "var(--ink)" }} /> Percorsi · guidati</span>
        <h1>Scegli un percorso.</h1>
        <p>Step persistenti, validation per step, sempre passabile a Studio Pro. Per una traccia chiara.</p>
      </div>

      <div className="path-list">
        {paths.map(p => (
          <button key={p.n} type="button" className="path-card" onClick={() => {
            if (p.target) {
              addToast({ kind: "info", ttl: `Percorso avviato`, msg: `${p.name} — apro il modello base.` });
              goto({ id: "model", modelId: p.target, modelName: p.name, status: "draft" });
            } else {
              addToast({ kind: "info", ttl: "Percorso in arrivo", msg: `${p.name} sarà disponibile in v2.4.x.` });
            }
          }}>
            <div>
              <div className="head">
                <span className="num">{p.n}</span>
                <span className="name">{p.name}</span>
              </div>
              <p className="sub" style={{ margin: "10px 0 0 0" }}>{p.sub}</p>
              <div className="steps">
                {p.steps.map((s, i) => (
                  <React.Fragment key={i}>
                    {i > 0 && <span style={{ color: "var(--ink-faint)" }}>→</span>}
                    <span className="pill">{s}</span>
                  </React.Fragment>
                ))}
              </div>
            </div>
            <span className="open"><Icon.ArrowR s={18} /></span>
          </button>
        ))}
      </div>
    </div>
  );
}

window.PercorsiScreen = PercorsiScreen;
