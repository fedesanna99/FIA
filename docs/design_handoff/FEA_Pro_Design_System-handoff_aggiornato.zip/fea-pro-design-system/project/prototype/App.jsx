// App router — hash-based, so refresh keeps the current screen.
// Routes:
//   #/                          → home
//   #/studio                    → studio empty
//   #/percorsi                  → percorsi
//   #/model/{id}?name=...&status=...  → model viewer
function App() {
  const [route, setRoute] = React.useState(() => parseHash());
  const [toasts, setToasts] = React.useState([]);
  const [running, setRunning] = React.useState(false);

  React.useEffect(() => {
    const onHashChange = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const goto = (next) => {
    const hash = encodeRoute(next);
    if (window.location.hash !== hash) {
      window.location.hash = hash;
    }
  };

  const addToast = (t) => {
    const id = Math.random().toString(36).slice(2);
    setToasts(prev => [...prev, { id, ...t }]);
    setTimeout(() => setToasts(prev => prev.filter(x => x.id !== id)), 4200);
  };
  const dismiss = (id) => setToasts(prev => prev.filter(x => x.id !== id));

  const onRun = () => {
    setRunning(true);
    addToast({ kind: "info", ttl: "Analisi statica avviata", msg: "Solver lineare · ~12s rimanenti…" });
    setTimeout(() => {
      setRunning(false);
      addToast({ kind: "success", ttl: "Analisi completata", msg: "1416 sub-step risolti. Risultati pronti." });
    }, 2400);
  };

  // Build breadcrumb + topbar context per route
  const crumbs = buildCrumbs(route, goto);
  const showRun = route.id === "model" || route.id === "studio";

  return (
    <div className="app">
      <TopBar crumbs={crumbs} onCrumb={goto} onRun={showRun ? onRun : null} running={running} />

      <div className="page">
        {route.id === "home"     && <HomeScreen     goto={goto} />}
        {route.id === "studio"   && <StudioScreen   goto={goto} addToast={addToast} />}
        {route.id === "percorsi" && <PercorsiScreen goto={goto} addToast={addToast} />}
        {route.id === "model"    && (
          <ModelScreen
            modelId={route.modelId}
            modelName={route.modelName}
            status={route.status}
            addToast={addToast}
          />
        )}
      </div>

      <ToastStack toasts={toasts} dismiss={dismiss} />
    </div>
  );
}

function parseHash() {
  const h = window.location.hash || "#/";
  const [path, query] = h.slice(1).split("?");
  const parts = path.split("/").filter(Boolean);
  const q = new URLSearchParams(query || "");

  if (parts.length === 0) return { id: "home" };
  if (parts[0] === "studio")   return { id: "studio" };
  if (parts[0] === "percorsi") return { id: "percorsi" };
  if (parts[0] === "model") {
    return {
      id: "model",
      modelId: parts[1] || "telaio",
      modelName: q.get("name") || "Modello",
      status: q.get("status") || "ok",
    };
  }
  return { id: "home" };
}
function encodeRoute(r) {
  if (r.id === "home")     return "#/";
  if (r.id === "studio")   return "#/studio";
  if (r.id === "percorsi") return "#/percorsi";
  if (r.id === "model") {
    const q = new URLSearchParams();
    if (r.modelName) q.set("name", r.modelName);
    if (r.status)    q.set("status", r.status);
    const qs = q.toString();
    return `#/model/${r.modelId || "x"}${qs ? "?" + qs : ""}`;
  }
  return "#/";
}
function buildCrumbs(route, goto) {
  const home = { label: "Home", onClick: () => goto({ id: "home" }) };
  if (route.id === "home")     return [];
  if (route.id === "studio")   return [home, { label: "Studio Pro", live: true }];
  if (route.id === "percorsi") return [home, { label: "Percorsi",   live: true }];
  if (route.id === "model")    return [
    home,
    { label: "Studio Pro", onClick: () => goto({ id: "studio" }) },
    { label: route.modelName || "Modello", live: true },
  ];
  return [];
}

window.App = App;
