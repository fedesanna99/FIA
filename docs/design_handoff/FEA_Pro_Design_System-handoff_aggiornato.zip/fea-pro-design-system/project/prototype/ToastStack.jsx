// Toast stack — minimal queue-based notifications.
function ToastStack({ toasts, dismiss }) {
  return (
    <div className="toast-stack" aria-live="polite">
      {toasts.map(t => (
        <div key={t.id} className={`toast ${t.kind || "info"}`}>
          <span className="ico">
            {t.kind === "success"
              ? <Icon.Check />
              : <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>}
          </span>
          <div className="body">
            <div className="ttl">{t.ttl}</div>
            {t.msg && <div className="msg">{t.msg}</div>}
          </div>
          <button type="button" className="close" onClick={() => dismiss(t.id)} aria-label="Chiudi"><Icon.Close /></button>
        </div>
      ))}
    </div>
  );
}

window.ToastStack = ToastStack;
