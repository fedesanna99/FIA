// Studio Pro empty state — when you click "Apri Studio Pro" without a model.
function StudioScreen({ goto, addToast }) {
  return (
    <div className="studio-empty" data-screen-label="03 Studio Pro empty">
      <div className="hero">
        <span className="hero-eyebrow"><span className="dot" style={{ background: "var(--accent)" }} /> Studio Pro · Nuovo modello</span>
        <h1>Crea il tuo<br/>primo modello.</h1>
        <p>Tre modi per iniziare. Cambi metodo quando vuoi.</p>
      </div>

      <div className="start-grid">

        <button type="button" className="start-card" onClick={() => {
          addToast({ kind: "info", ttl: "Workspace creato", msg: "Modello vuoto pronto in Studio Pro." });
          goto({ id: "model", modelId: "telaio", modelName: "Nuovo modello", status: "draft" });
        }}>
          <span className="ico"><Icon.Plus /></span>
          <span className="name">Da zero</span>
          <span className="sub">Workspace vuoto. Geometria, materiali, sezioni: tutto a tua discrezione.</span>
          <span className="foot">Inizia →</span>
        </button>

        <button type="button" className="start-card" onClick={() => {
          addToast({ kind: "info", ttl: "Template applicato", msg: "Telaio portale 2D · IPE/HEA · SLU + SLE." });
          goto({ id: "model", modelId: "telaio", modelName: "Telaio portale 2D", status: "draft" });
        }}>
          <span className="ico"><Icon.Layers /></span>
          <span className="name">Da template</span>
          <span className="sub">9 schemi resistenti pre-impostati. Travi, pilastri, telai, reticoli, piastre.</span>
          <span className="foot">9 template →</span>
        </button>

        <button type="button" className="start-card" onClick={() => {
          addToast({ kind: "info", ttl: "Importazione", msg: "Wizard a 4 step · .ifc · .dxf · .json" });
        }}>
          <span className="ico"><Icon.FileUp /></span>
          <span className="name">Importa</span>
          <span className="sub">Wizard 4 step per .ifc, .dxf, .json. Geometria e metadata estratti.</span>
          <span className="foot">Apri wizard →</span>
        </button>

      </div>
    </div>
  );
}

window.StudioScreen = StudioScreen;
