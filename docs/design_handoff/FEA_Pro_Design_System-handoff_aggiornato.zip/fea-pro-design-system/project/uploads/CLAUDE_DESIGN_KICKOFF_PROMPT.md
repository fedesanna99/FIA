# Kickoff prompt per Claude Design

> Testo da copiare e incollare come **primo messaggio** in claude.ai/design,
> dopo aver creato il nuovo progetto e allegato `UX_REDESIGN_BRIEF.md`.

---

## Versione consigliata (incolla questo)

```
Ciao. Sono Federico Sanna, sviluppo FEA Pro — una webapp di analisi 
strutturale FEM per ingegneri civili italiani.

Allego il file UX_REDESIGN_BRIEF.md. Contiene:
- Chi userà l'app (ingegnere strutturista italiano)
- 20 problemi UX raccolti da un tester reale (collega ingegnere)
- 7 principi di design non negoziabili
- Inventario 13 componenti da ridisegnare in ordine di priorità
- Riferimenti UX di stile (Notion, Linear, Figma, ETABS, MIDAS)
- Vincoli tecnici (React 18 + Tailwind + Three.js, backend immutabile)

Prima di iniziare a disegnare, ti chiedo di fare 3 cose in ordine:

1. Leggi il brief allegato e dimmi se ci sono ambiguità o se 
   hai bisogno di chiarimenti su qualche principio o requisito.

2. Setup del design system FEA Pro. Ti darò accesso al repo 
   GitHub (oppure caricherò manualmente file di esempio dello 
   stato attuale). Costruisci il design system leggendo:
   - Tailwind config esistente
   - Componenti React attuali
   - Three.js scene setup
   - Eventuali file di style guide se presenti
   
   Output atteso: un design system FEA Pro con colori, tipografia, 
   spacing, componenti di base (button, input, card, panel, tab, 
   badge). Voglio mantenere l'identità visiva attuale dove funziona, 
   ma evolverla verso mobile-first e maggiore leggibilità.

3. Quando il design system è pronto, partiamo dal componente #1 
   dell'inventario: la mobile dashboard (home da telefono). 
   
   Non disegnare tutti i mockup in una sessione. Una pagina alla 
   volta, con la mia approvazione esplicita prima di passare al 
   prossimo. Il pattern è: brief → first draft → max 4-5 raffinamenti 
   → approvo → handoff a Claude Code → prossima pagina.

Persona di riferimento del redesign: Paoletto Lera, ingegnere 
strutturista che ha provato la versione attuale da smartphone e 
non è riuscito a completare nessun test. Il successo del redesign 
si misura su: "Paoletto apre l'app dal telefono, carica un template, 
fa girare un'analisi, capisce i risultati. Tutto senza chiedere aiuto."

Procedi con il punto 1 (lettura brief + chiarimenti).
```

---

## Note per te (Federico)

### Cosa dovrebbe rispondere Claude Design al kickoff

Una risposta che indica buon allineamento conterrebbe:

- Conferma di aver letto il brief
- 2-3 domande di chiarimento mirate (es. "vuoi mantenere il colore accent attuale o cambiarlo", "il logo FEA Pro lo vuoi rivedere o resta", "vuoi che applichi pattern Linear-style per le tabelle o ETABS-style?")
- Proposta di sequenza setup design system

Se Claude Design parte subito a disegnare senza chiarimenti, fermalo: "Ferma. Voglio prima il setup design system. Poi cominciamo dal mockup #1, una pagina alla volta."

### Se ti chiede file extra

Probabili richieste sensate:

- Screenshot della versione attuale dell'app
- Esempi di pagine simili che ti piacciono (URL o screenshot)
- File `tailwind.config.js` del repo
- Componenti React di esempio per capire pattern attuali

Rispondi quando ti chiede. Non anticipare tu allegando 30 file inutili.

### Se ti propone di cambiare stack frontend

Esempio: "Suggerisco di passare a Tailwind v4" o "Vorrei usare Radix UI per i componenti base".

Risposta: "Stack è immutabile per ora. React 18 + TS + Vite + Tailwind v3 + Three.js. Niente librerie UI nuove. Lavora dentro questi vincoli."

### Quando vai in difficoltà

Se Claude Design propone qualcosa che non capisci o non sai valutare:

1. Chiedigli di spiegare il perché ("perché qui hai messo bottom sheet invece di modal full-screen?")
2. Non approvare se non sei convinto — è gratis chiedere chiarimenti
3. Se la decisione è ambigua, scrivimi su claude.ai chat project: "Claude Design propone X, mi spiega Y, sei d'accordo?"

---

## Per riferimento — l'ordine di lavoro

Vai a `claude.ai/design`:

1. Create new project → nome **"FEA Pro · UX Redesign"**
2. Onboarding: connetti repo GitHub di FEA Pro (se accessibile)
3. Primo messaggio: allega `UX_REDESIGN_BRIEF.md` + incolla il kickoff prompt sopra
4. Aspetta risposta. Rispondi alle eventuali domande di chiarimento.
5. Quando dice "Design system pronto", chiedi di mostrartelo (Tailwind config, palette colori, tipografia)
6. Quando approvi il design system, dì: "Partiamo dal mockup #1 (mobile dashboard)"
7. Da qui ciclo: brief → draft → raffina → approvo → handoff → prossimo

Buona sessione.
