# FEA Pro · UX Redesign Brief

> Documento di visione per il redesign UX completo di FEA Pro.
> Da consegnare a Claude Design come allegato del primo prompt.
> Da tenere nel project knowledge di claude.ai come riferimento permanente.

---

## 1. Cos'è FEA Pro

Webapp di analisi strutturale agli elementi finiti (FEM) per ingegneri strutturisti italiani. Sviluppata da Federico Sanna (freelance, Cagliari). Backend Python solido (1416 test PASS), frontend React che richiede un redesign.

Stack frontend: **React 18 + TypeScript + Vite + Tailwind + Three.js (react-three-fiber) + Zustand multi-store + TanStack Query**.

Normative coperte: NTC 2018, Eurocodici EC2 (CA), EC3 (acciaio), EC5 (legno), EC8 (sismica).

Versione attuale: v2.3.7 (post-audit fase, prima del redesign).

## 2. Chi userà l'app

**Persona primaria — Strutturista italiano freelance**

- 35-50 anni, laurea ingegneria civile/edile
- Lavora su progetti piccoli e medi (palazzine 4-6 piani, capannoni industriali, ville unifamiliari, ristrutturazioni edifici storici)
- Usa SAP2000 o MIDAS Civil in studio, ma cerca alternative più moderne per progetti veloci
- Compila spesso relazioni tecniche per Sportello Unico Edilizia, firma con timbro professionale
- Conosce NTC 2018 a memoria, sa cos'è l'EC8 spettro di risposta, sa quando serve un'analisi sismica TH e quando basta uno spettro
- **NON è developer**. Non legge documentazione. Si aspetta che l'app sia auto-esplicativa.
- **Usa lo smartphone per consultare** risultati al volo (in cantiere, in riunione, durante un sopralluogo), e il desktop per modellare/calcolare seriamente

**Persona secondaria — Junior engineer / Ingegnere giovane**

- 25-35, primo lavoro o studio piccolo
- Meno sicuro tecnicamente, vuole guidance (wizard, sanity check, AI Copilot)
- Userà sia desktop che mobile, ma desktop principale

**Persona tester di riferimento**: **Paoletto Lera**, ingegnere strutturista amico di Federico. Ha provato l'app v2.3.7 da smartphone e non è riuscito a completare nessun test reale.

## 3. Inventario completo problemi UX raccolti

### 3a. Da test mobile di Paoletto (WhatsApp 2026-05-24)

| # | Finding | Severity tecnica | Severity UX reale |
|---|---|---|---|
| 1 | Cliccando elemento non vede menu chiaro con lunghezza assoluta, posizione nodi, materiale completo (E, fy, ν), sezione con caratteristiche meccaniche | P1 | **P0** |
| 2 | Diagrammi M/V/N visualizzati come forma colorata ma senza valore numerico di picco (M_max kNm, dove è il picco) | P1 | **P0** |
| 3 | Template demo non mostrano dimensioni della struttura né valore dei carichi applicati | P1 | **P0** |
| 4 | Click su elemento → singolo valore numerico ma ambiguo (è max? medio? al nodo i? al nodo j? al centro?) | P1 | **P0** |

### 3b. Da test esteso (file `IMPORTANTISSIMO_AGGIORNAMENTO_DOPO_TEST`)

| # | Finding | Categoria |
|---|---|---|
| 5 | Solo 3 sezioni rettangolari nel catalogo, serve molto di più (IPE/HEA/HEB/HEM/UPN/UPE/CHS/SHS/RHS/tonde/quadre/legno C18-C24-GL24-GL28-GL32/cls) | Catalogo |
| 6 | Manca possibilità di creare sezioni parametriche custom | Feature mancante |
| 7 | Catalogo materiali scarso. Inoltre l'utente non trova dove aggiungere materiali | Catalogo + Discoverability |
| 8 | Elemento creato compare in icona topbar ma non nel viewport (sync bug) | Bug UI |
| 9 | "Carico modellabile secondo le norme" — quali norme? Non documentato in UI | Documentazione UX |
| 10 | "metri" scritto con M maiuscola (refuso UI) | Refuso |
| 11 | Convertitore unità inline nei field numerici (es. inserisco "1.5 m" e accetta o converte a 1500 mm). A scomparsa, chiamabile facilmente | Feature richiesta |
| 12 | Test di discoverability: ogni funzione raggiungibile da UI navigation, non solo da Ctrl+K palette | Pattern UX |
| 13 | Vuoi più template demo, e possibilità di scegliere come vengono visualizzati | Catalogo + Customization |
| 14 | Attivata view deformata ma non visibile nel viewport | Bug viewport |
| 15 | Test su quanti elementi può discretizzare una struttura (limite tecnico?) | Limit + documentazione |
| 16 | Migliorare foglio report/export (output finale) | Export quality |
| 17 | Tasto destro apre troppe cose (context menu sovraffollato) | Pattern UX |
| 18 | Mentre il solver carica, l'UI resta interattiva (race condition / feedback mancante) | Stato sistema |
| 19 | Mesh non solo lineare ma anche 2D (membrane, piastre) e 3D (solidi) | Feature solver (già esiste backend!) |
| 20 | Diagrammi: di default visibili almeno valori max e min | Default UX |

### 3c. Sintesi del problema centrale

> *"Non riesco a capire cosa sto guardando."* — Paoletto Lera

Tutti i 20 finding sono varianti dello stesso problema: i dati esistono nel backend, ma il frontend non li espone in modo leggibile a un ingegnere. L'app è tecnicamente corretta e UX-cieca.

## 4. Principi di design non negoziabili

Questi 7 principi guidano ogni decisione del redesign. Sono criteri di accettazione per ogni mockup di Claude Design.

### Principio 1 · Ogni risultato ha un numero

Nessun diagramma N/V/M/σ può essere visualizzato senza etichette numeriche dei valori di picco (max e min). Etichette posizionate sopra/sotto il diagramma con `valore + unità + posizione`. Esempio: `M_max = 12.45 kNm @ x = 2.25 m`.

### Principio 2 · Ogni elemento è ispezionabile in 1 tap

Click/tap su qualsiasi elemento → pannello laterale persistente con:

- **Geometria**: lunghezza assoluta, coordinate nodi i e j, vettore direzione
- **Materiale completo**: nome, E (modulo elastico), fy (snervamento), ν (Poisson), ρ (densità), classe normativa
- **Sezione completa**: tipo (IPE 300), A, Iy, Iz, Wpl,y, Wpl,z, raffigurazione 2D
- **Risultati**: N/V/M con specifica posizione ("max", "al nodo i", "al centro elemento")
- **Verifiche**: UR (utilization ratio) per ogni verifica normativa applicabile

Niente modal che coprono il viewport. Pannello laterale che si apre senza nascondere il modello.

### Principio 3 · Mobile-first per consultazione, desktop per setup

L'ingegnere usa lo smartphone in cantiere/riunione per **leggere risultati**. Usa il desktop in studio per **modellare/calcolare**. Il redesign deve riconoscere questi due modi d'uso:

- **Mobile**: viewport + diagrammi + inspector + risultati. Setup minimo (apri modello esistente, run analisi, vedi risultati).
- **Desktop**: tutto il mobile + creazione modello, edit elementi, mesh fine, carichi complessi, report export.

Niente pattern "responsive che spreme la UI desktop su mobile". Mobile è una vera prima cittadina.

### Principio 4 · Discoverability via UI, palette come scorciatoia

Ogni funzione deve essere raggiungibile via navigazione UI (tabbar, menu, panel rail). Ctrl+K palette è una scorciatoia per utenti esperti, mai un requisito per principianti. Test: "Paoletto si siede davanti all'app per la prima volta, riesce a fare X cliccando soltanto?"

### Principio 5 · Stato del sistema sempre chiaro

- Quando il solver gira: UI bloccata con loading state ben visibile (overlay, spinner grande, percentuale stream se disponibile).
- Quando un elemento è creato/modificato/cancellato: il viewport si aggiorna immediatamente e visivamente (highlight, animazione breve).
- Quando un'azione fallisce: errore chiaro, non whitescreen, non console error invisibile.

### Principio 6 · Standard normativi sempre nominati

Carichi, combinazioni, verifiche devono sempre riportare la norma applicata: "EC1-1-4 §6.3.2", "NTC18 §3.5.3", "EC8 §3.2.2.2". L'ingegnere deve sapere su quale norma sta lavorando e poter verificare il calcolo manualmente.

### Principio 7 · Catalogo professionale

Sezioni: catalogo completo IPE/HEA/HEB/HEM/UPN/UPE/CHS/SHS/RHS (acciaio), tonde/quadre/rettangolari piene (CA), legno strutturale C18-C24-GL24h-GL28h-GL32h, sezioni parametriche custom. Materiali: tutti gli acciai EC3 (S235/275/355/420/460), calcestruzzi EC2 (C20-C25-C30-C35-C40-C45-C50), legno EC5, eventualmente alluminio EC9.

## 5. Inventario componenti da ridisegnare

In ordine di priorità (i primi sbloccano l'uso end-to-end da mobile):

| # | Componente | Mobile | Desktop | Priorità |
|---|---|---|---|---|
| 1 | Mobile dashboard (home da telefono) | sì | n/a | **P0** |
| 2 | Mobile viewport + bottom tabbar (no rails laterali) | sì | n/a | **P0** |
| 3 | Element inspector panel | sì | sì | **P0** |
| 4 | Diagrammi N/V/M con etichette di picco | sì | sì | **P0** |
| 5 | Section picker (catalogo esteso + parametrica) | sì | sì | **P0** |
| 6 | Material picker (catalogo esteso) | sì | sì | **P0** |
| 7 | Topbar minimal (mobile) e completa (desktop) | sì | sì | P1 |
| 8 | Template gallery con dimensioni/carichi visibili | sì | sì | P1 |
| 9 | Loading state durante solve | sì | sì | P1 |
| 10 | Convertitore unità inline nei field numerici | n/a | sì | P1 |
| 11 | Desktop tutto-in-uno (viewport + panel + diagrammi) | n/a | sì | P1 |
| 12 | Report PDF/XLSX (output finale) | n/a | sì | P2 |
| 13 | Context menu tasto destro (semplificato) | n/a | sì | P2 |

## 6. Riferimenti UX di stile

(Assunzioni di Federico — da correggere se vuole stile diverso)

### Estetica generale / UI

- **Notion** — gerarchia chiara, tipografia leggibile, niente fronzoli
- **Linear** — densità informativa alta ma ordinata, motion sottile, attenzione ai dettagli
- **Figma** — pattern panel laterali, palette command, sezioni espandibili

### Data density tecnica

- **ETABS / MIDAS Civil** — pattern di presentazione risultati strutturali (tabelle compatte di sollecitazioni, code colorimetriche per utilization ratio, viewer 3D ricco)
- **Tekla Structures** — manipolazione 3D elementi strutturali, inspector elementi

### Mobile

- **Linear mobile** — bottom tabbar, gesture cleanings, focus contestuale
- **Things 3** — chiarezza, niente clutter, ogni tap conta

## 7. Vincoli tecnici per Claude Design

- Stack frontend **immutabile**: React 18 + TS + Vite + Tailwind + Three.js (react-three-fiber) + Zustand + TanStack Query. Nessun framework UI nuovo (no MUI, no Chakra), Tailwind per styling.
- Backend Python FastAPI **non si tocca**. Gli API endpoint esistono e funzionano. Il redesign deve usare gli endpoint esistenti (`/api/models/*`, `/api/analysis/*`, `/api/verify/*`, `/api/postprocess/*`, ecc.).
- Tre.js scene esistente va riusata, non rifatta. Si può cambiare overlay, HUD, label, ma la rendering pipeline e le shader esistenti restano.
- Zustand store esistente va riusato (model, results, ui, history, snapshot, jobs, auth). Si possono aggiungere store nuovi (es. `selectionStore`, `inspectorStore`) ma non rifattorizzare quelli esistenti.

## 8. Cosa Claude Design deve produrre

Per ogni componente nell'inventario sezione 5:

1. **Mockup statico ad alta fedeltà** del componente (HTML + CSS Tailwind)
2. **Spec interazione** (cosa succede al tap/click, cosa è statico, cosa è animato)
3. **Spec responsive** (come cambia tra mobile 375px e desktop 1440px)
4. **Spec accessibilità** (focus order, ARIA, contrasto colore)
5. **Spec dati richiesti dal backend** (quali API endpoint chiama, quale shape dati si aspetta)

Output finale per pagina: handoff bundle per Claude Code (Export → Handoff to Claude Code).

## 9. Cosa Claude Design NON deve fare

- Non riscrivere il backend
- Non proporre cambi di stack frontend
- Non inventare endpoint API che non esistono (chiedere a Federico se incerto)
- Non disegnare 9 mockup in una sessione — uno alla volta, approvazione esplicita prima di passare al prossimo
- Non scrivere codice React vero (quello è compito di Claude Code post-handoff)

## 10. Riferimenti documenti project

Per contesto aggiuntivo, Claude Design può consultare (se Federico li allega):

- `PROJECT_STATE.md` — stato attuale FEA Pro v2.3.7
- `FEM_Business_Plan_Pay_Per_Use.pdf` — visione commerciale (target utenti)
- `EXPORT_STATE_v1.2.md` — architettura tecnica (storica ma utile per stack)
- Mockup HTML v1.3 (`fea_pro_ui_*.html`) — riferimento di cosa c'era prima (da NON copiare, è il design attuale che non funziona)

---

**Fine brief.** Claude Design può iniziare con la pagina #1 dell'inventario (Mobile dashboard).
