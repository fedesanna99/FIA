# PROJECT STATE · FEA Pro

> Stato vivo del progetto. Aggiornare a fine di ogni sprint.
> Letto a inizio di ogni nuova chat.

**Ultimo aggiornamento**: 2026-05-24 (sera)
**Versione corrente**: `v2.3.7-solver-internals-audit`
**Branch attivo**: `test` (sincronizzato con `main`)
**Ultimo SHA**: `ea835fa`
**⚠ Decisione strategica attiva**: Redesign UX completo (v2.4.x congelato fino a fine redesign)

---

## 1. Decisione strategica corrente

**Tutto il lavoro backend è congelato fino a quando il redesign UX non è in implementazione.**

### Perché

Paoletto Lera (ingegnere strutturista amico di Federico) ha testato FEA Pro v2.3.7 da smartphone. **Non è riuscito a completare nessun test reale**. Ha lasciato 20 finding UX (4 in WhatsApp + 16 nel file `IMPORTANTISSIMO_AGGIORNAMENTO_DOPO_TEST`). Il backend funziona, il frontend impedisce l'uso reale dell'app.

Fixare la shell formulation (NEW-1, NEW-3, NEW-4) è tecnicamente importante ma inutile a livello di adozione utente finché un ingegnere reale non riesce a leggere i risultati.

### Cosa cambia

- **Filone principale**: Redesign UX mobile-first via Claude Design + Claude Code
- **Filone rimandato**: shell fix `v2.4.3a/b/c` (5-7 giorni) → ripreso dopo redesign
- **Stima totale redesign**: 4-6 settimane (Claude Design + Claude Code in cascata)

### Workflow nuovo a 3 ambienti

```
[claude.ai project chat]  →  strategia, PM, brief, decisioni
        ↓ vision doc
[claude.ai/design]        →  redesign UX (canvas + iterazione visiva)
        ↓ handoff bundle
[Claude Code CLI]         →  implementazione contro repo FEA Pro
```

Federico opera in tutti e tre, ma per scope diversi. Vedere file `PACKAGE_README.md` consegnato nel pacchetto UX redesign per dettagli operativi.

## 2. Stato sintetico tecnico

Aggiornato dopo gli sprint v2.3.3 → v2.3.7:

- **Solver 1D**: solido. Beam Euler-Bernoulli, modale, buckling, dinamica Newmark → errore < 0.001% su benchmark
- **Solver 2D shell**: **bug strutturali noti**, diagnosi completa, fix rimandato per UX redesign
  - NEW-1 LE1 anti-convergenza (root cause: stress recovery centroide + carichi 85%)
  - NEW-3 MITC `uz=0` LE10 (root cause: `assembler.py:244` dispatch incompleto)
  - NEW-4 σ_yy=0 LE10 (root cause: `shell_quad4.py:156` ignora rotazioni)
- **Verifiche normative**: EC2 staffe fixato (v2.4.1), EC3 ben coperto, EC5/EC8 gap noti
- **Legal/security**: GDPR DELETE + rate limit + security headers tutti chiusi (v2.4.2)
- **Documentazione**: onesta. README dichiara cosa funziona e cosa no
- **Test suite**: 1416 pytest PASS, 584 vitest PASS, 12 FAIL pre-esistenti tollerati

## 3. Sprint chiusi recenti (cronologia)

| Tag | Tipo | Cosa ha chiuso |
|---|---|---|
| `v2.3.3-docs-sync` | docs | README + BACKLOG + ROADMAP riallineati alla realtà v2.3.2 |
| `v2.3.4-quality-checkpoint` | diagnosi | L1 crawler + L2 flow, 25 finding (15 nuovi + 16 noti) |
| `v2.3.5-nafems-truth-audit` | diagnosi | Bug seri scoperti: LE1 −32%, LE10 σ=0, #30 NaN silent, #6 EC2 staffe |
| `v2.3.6-honesty-fix` | docs | README onesto e radicale: "non per progetti reali fino a v2.4.x" |
| `v2.4.0-singular-matrix-fix` | fix P0 | `SingularMatrixError` + `safe_spsolve` in static_solver |
| `v2.4.0bis-safe-spsolve-extend` | fix P0 | `safe_spsolve` esteso ad arclength/dynamic/nonlinear (5 solver) |
| `v2.4.1-ec2-stirrups-fix` | fix P0 | `shear_check(V_Ed)` per `needs_stirrups = V_Ed > V_Rd_c` |
| `v2.4.2-legal-security` (compound) | fix P0 ×3 | #22 GDPR delete + #28 rate limit + #17 security headers |
| `v2.3.7-solver-internals-audit` | diagnosi | Root cause NEW-1..4 shell formulation (file:riga noto) |

## 4. Bug chiusi

5 P0 chiusi nei sprint v2.4.x:
- **#6** EC2 "Staffe non nec." quando UR>1 (safety verifica strutturale)
- **#17** Security headers mancanti HSTS/CSP/X-Frame/X-Content (security)
- **#22** GDPR DELETE account (legal UE Art. 17)
- **#28** Rate limit login brute force (security)
- **#30** Engine non ferma su matrice singolare → NaN/spostamenti folli silent (safety solver)

Un finding chiuso come falso positivo:
- **NEW-2** Q4 = MITC su LE1 → non è bug, fisica corretta

## 5. ⚠ Filone principale corrente · UX Redesign

### 5a. Inventario completo problemi UX

**Da WhatsApp Paoletto (2026-05-24)**:
1. Pannello info elemento incompleto (lunghezza, materiale completo E/fy/ν, sezione)
2. Diagrammi N/V/M senza numeri di picco (M_max, V_max)
3. Template senza dimensioni e carichi visibili
4. Click su elemento → numero ambiguo (max? medio? nodo i?)

**Da file `IMPORTANTISSIMO_AGGIORNAMENTO_DOPO_TEST`**:
5. Solo 3 sezioni rettangolari → catalogo da estendere (IPE/HEA/HEB/ecc.)
6. Sezioni parametriche custom mancanti
7. Catalogo materiali scarso, UX non trova dove aggiungerli
8. Bug sync: elemento creato compare in topbar icon ma non viewport
9. Carichi normati → quali norme? non documentato
10. Refuso "Metri" maiuscolo
11. Convertitore unità inline a scomparsa (feature richiesta)
12. Discoverability via UI navigation (non solo Ctrl+K)
13. Più template demo + scelta visualizzazione
14. View deformata attivata ma non visibile
15. Limite discretizzazione (quanti elementi max?)
16. Foglio report/export migliorabile
17. Tasto destro context menu sovraffollato
18. UI interattiva durante caricamento solver (race condition)
19. Mesh 2D e 3D, non solo lineare (backend lo supporta già!)
20. Diagrammi: default visibili max e min

### 5b. Pacchetto UX redesign consegnato

File creati e consegnati a Federico il 2026-05-24:

- `PROJECT_STATE_v2_aggiornato.md` (questo file, sostituisce vecchio PROJECT_STATE)
- `UX_REDESIGN_BRIEF.md` (vision doc completo per Claude Design)
- `CLAUDE_DESIGN_KICKOFF_PROMPT.md` (testo da incollare in claude.ai/design)
- `PACKAGE_README.md` (guida operativa)

### 5c. Inventario componenti da ridisegnare (in ordine priorità)

| # | Componente | Stato |
|---|---|---|
| 1 | Mobile dashboard | da disegnare |
| 2 | Mobile viewport + bottom tabbar | da disegnare |
| 3 | Element inspector panel | da disegnare |
| 4 | Diagrammi N/V/M con etichette di picco | da disegnare |
| 5 | Section picker (catalogo + parametrica) | da disegnare |
| 6 | Material picker (catalogo esteso) | da disegnare |
| 7 | Topbar minimal mobile / completa desktop | da disegnare |
| 8 | Template gallery con dimensioni/carichi | da disegnare |
| 9 | Loading state solver | da disegnare |
| 10 | Convertitore unità inline | da disegnare |
| 11 | Desktop tutto-in-uno | da disegnare |
| 12 | Report PDF/XLSX migliorato | da disegnare |
| 13 | Context menu tasto destro semplificato | da disegnare |

### 5d. 7 principi UX non negoziabili (vedi `UX_REDESIGN_BRIEF.md`)

1. Ogni risultato ha un numero
2. Ogni elemento è ispezionabile in 1 tap
3. Mobile-first per consultazione, desktop per setup
4. Discoverability via UI, palette come scorciatoia
5. Stato sistema sempre chiaro
6. Standard normativi sempre nominati (EC1, NTC18, ecc.)
7. Catalogo professionale (sezioni + materiali completi)

## 6. Marketplace (idea da rielaborare in sessione dedicata)

Da file `idea_` nel project knowledge: *"marketplace per scaricare/caricare contenuti come preset, modelli, formule, test etc. Gratuito o a pagamento?"*

**Stato**: spunto annotato, rielaborazione strategica fatta in chat precedente ma non più reperibile. Da riprendere in sessione brainstorming dedicata **dopo** che il redesign UX è in implementazione (almeno mockup 1-6 approvati).

Probabile direzione: marketplace user-to-user per preset/modelli/formule/test. Vincoli importanti da considerare: responsabilità professionale (firma con timbro), validazione qualità, IP modelli condivisi, monetization model.

## 7. Debt tracked (v2.4.2 follow-ups)

| ID | Descrizione | Severity | Stima fix |
|---|---|---|---|
| **#22bis** | GDPR cascade incomplete: 4 stub (billing/audit/owner_id models) | P1 | ~1 giorno |
| **#28bis** | Rate limit in-memory single-instance (no multi-machine) | P2 | ~half day |
| **#17bis** | CSP report-only → promozione enforcement dopo 1-2 settimane osservazione | P2 reminder | ~half day |

## 8. Bug shell rimandati (pipeline post-redesign)

Da riprendere quando UX redesign in implementazione:

| Bug | Root cause | File:riga | Fix stima |
|---|---|---|---|
| **NEW-3** MITC `uz=0` su LE10 | `if el.type == SHELL_Q4:` ignora MITC | `assembler.py:244` | ~3 ore |
| **NEW-4** σ_yy=0 LE10 | `stresses()` legge solo `u_x,u_y` (ignora rotazioni) | `shell_quad4.py:156` + schema | ~2-3 giorni |
| **NEW-1** LE1 anti-convergenza | Stress recovery al centroide + carichi nodali 85% | `shell_quad4.py:165` + builder test | ~2-3 giorni |

## 9. Altri bug aperti (pre-audit, da affrontare dopo redesign)

- **#2** Export PDF/XLSX broken (P0 feature) — collegato a finding UX #16
- **#9** Undo/Redo v2.3.0 broken in produzione (P0 feature)
- **#14** EC3 section class sistematico HEA/IPE (P1)
- **#15** EC5 timber classes: 4/27 supportate (P1) — collegato a finding UX #5
- **#16** EC2 punching/crack/deflection mancanti (P1)
- **#19** EC4/EC6/EC7/EC9 mancanti (P1)
- **#23** Open-Meteo timeout intermittente (P1 provider)
- **#27** AI Copilot = MockProvider (P1, è feature non-bug)
- **#29** NTC18 soil_class ignorato (P1, sismica)
- BUG-001..010 UI da v2.3.4 + 5 P2 — alcuni potrebbero risolversi con redesign

## 10. Decisioni strategiche prese

### Pattern operativo (consolidato)

- **Sequenza fix**: Approccio B (cluster separati per bug con root cause distinte)
- **Brief compound**: per gruppi di fix indipendenti con diagnosi chiara, 1 brief con 3-5 sprint atomici in catena
- **Brief atomico**: per fix singoli o lavori a rischio
- **Investigation phase**: obbligatoria se una modifica tocca funzione con > 1 caller
- **Diagnosi prima del fix**: confermato funzionante (v2.3.5 + v2.3.7)

### Nuova (2026-05-24)

- **UX prima di backend**: quando un ingegnere reale non riesce a completare un test, fixare il backend è secondario
- **Workflow 3-ambienti**: claude.ai project chat (PM) + claude.ai/design (UX) + Claude Code (implementation)
- **Mobile-first**: una vera prima cittadina, non responsive squeeze del desktop
- **Catalogo esteso prima del solver**: senza sezioni/materiali professionali, il solver è inutile in pratica

### Versioning e branching

- Branch principale di lavoro: `test`
- `main` segue `test` con sync dopo ogni sprint chiuso
- Versioning: `vN.M.X-<slug>`, `vN.M.Xbis-<slug>` per extension, `vN.M.X.y-<slug>` per hotfix
- Tag rollup per brief compound

### Cose escluse o rimandate

- Mai aggiungere dipendenze pip senza brief esplicito
- Test "lenti" o "pre-esistenti rotti": NON skippare automaticamente
- Refactor opportunistico: vietato
- Cambio stack frontend durante redesign: vietato (React 18 + Tailwind + Three.js immutabile)

## 11. Prossimo passo immediato

**Federico**: installa il pacchetto UX redesign:

1. Sostituisci questo file (`PROJECT_STATE.md`) nel project knowledge
2. Aggiungi `UX_REDESIGN_BRIEF.md` come knowledge file
3. Apri `claude.ai/design` → nuovo progetto → punta a repo FEA Pro
4. Allega `UX_REDESIGN_BRIEF.md` + incolla `CLAUDE_DESIGN_KICKOFF_PROMPT.md`
5. Lavora con Claude Design pagina per pagina

Dopo che il primo mockup (Mobile dashboard) è approvato in Claude Design: torna in chat claude.ai project con il bundle di handoff e Claude scriverà il brief Claude Code per implementarlo.

## 12. Sequenza pianificata sprint successivi

**Filone UX (filone principale, 4-6 settimane)**:

1. Setup Claude Design + design system FEA Pro
2. Mockup 1 (mobile dashboard) → approva → Claude Code implementa
3. Mockup 2 (mobile viewport + bottom tabbar) → idem
4. Mockup 3 (element inspector) → idem
5. Mockup 4 (diagrammi con etichette) → idem
6. Mockup 5-6 (section/material picker) → idem
7. Mockup 7-13 in cascata
8. Test E2E con Paoletto sul deploy → se "riesce a fare un test completo" = redesign OK

**Filone tecnico (post-redesign)**:

9. **v2.4.3a-shell-pressure-mitc-fix** (~3 ore)
10. **v2.4.3b-shell-bending-stress-recovery** (~2-3 giorni)
11. **v2.4.3c-shell-stress-recovery-nodal** (~2-3 giorni)
12. **v2.4.5** export PDF/XLSX + undo/redo
13. **v2.4.6** EC3/EC5/EC8 coverage gaps
14. **v2.4.7** UI bugs residui non risolti dal redesign
15. **v2.4.8** pushover diagnostic
16. **v2.4.9** debt v2.4.2 (#22bis cascade complete)

**Filone strategico (in parallelo, sessioni dedicate)**:

17. Brainstorming marketplace (preset/modelli/formule/test)
18. Pricing pay-per-use definitivo (Stripe live)

**Totale stima a v2.5.0 production-ready**: 2-3 mesi realistici.

## 13. Convenzioni progetto (consolidate)

### Stack runtime
- Backend: `:8000` di default (in dev locale `:8765`)
- Frontend dev: Vite `:5173` (alcune build `:5273`/`:5274`)
- WebSocket: `/ws/analysis/{model_id}`, `/ws/collab/{model_id}`

### Pattern API
- REST: `/api/<resource>/<id>` (no trailing slash sui singoli)
- Lista: `/api/models/` (con slash)
- Import full payload: `POST /api/models/import` (NON `POST /api/models/`)

### Pattern frontend
- Mutazioni: TanStack Query `useMutation`
- State: Zustand multi-store (model, results, ui, history, snapshot, jobs, auth, ecc.)
- Risultati lunghi: persisti in `resultsStore` per visualizzazione viewport
- Tailwind breakpoint: sm:768, md:1024, lg:1280, xl:1440

### Baseline test (a oggi)
- pytest: **1416 PASS** / 12 FAIL pre-esistenti tollerati
- vitest: **584 PASS** / 0 FAIL
- E2E Playwright: 10/10 step smoke + suite v2.3.4 quality checkpoint runnabile
- tsc: 0 errori
