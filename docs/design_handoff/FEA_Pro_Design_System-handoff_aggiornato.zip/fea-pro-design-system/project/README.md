# FEA Pro · Design System

> **Precision direction v2.0** — light default · sharp geometry (radius 0) · hairline borders · cyan singular accent · Inter / Inter Tight / JetBrains Mono.
> Italian-language structural engineering webapp for civil/structural engineers.

---

## 1 · What is FEA Pro

FEA Pro is a **finite element analysis (FEM) webapp** for Italian structural engineers — built by Federico Sanna (freelance, Cagliari). Browser-first, cloud-aware, opinionated about *one tool per job*.

**Tagline (Italian, from product home)**: *"Inizia un'analisi."* — *"Due modi per costruire e analizzare un modello strutturale. Algoritmo prima, AI per accelerare — niente black box, tutti i calcoli tracciabili a formule normative."*

**Coverage** — Eurocodici **EC2** (CA), **EC3** (acciaio), **EC5** (legno), **EC8** (sismica) + **NTC 2018** (norme tecniche italiane). 10 solver (statica, modale, dinamica Newmark, buckling, pushover, sismica time-history, non-lineare Newton-Raphson / arc-length Crisfield, unilateral). 13 elementi finiti (beam 2D/3D, truss, cable, T3, shell Q4 Mindlin / MITC4 / layered, solid H8/T4/T10).

**Status** — `v2.3.7-solver-internals-audit`. Backend solido (1416 pytest PASS). Frontend in fase **redesign UX completo** (mobile-first) — la 2.3.x è **non raccomandata per progetti reali**. Sprint correttivo `v2.4.x` congelato fino a fine redesign.

### Two surfaces, one product

1. **Studio Pro** — modalità expert, controllo totale, qualsiasi ordine, no guardrail. Per chi sa già cosa fare.
2. **Percorsi** — guidato, step persistenti, validation per step, sempre passabile a Studio Pro. Per chi vuole una traccia chiara.

L'utente cambia hub dalla Dashboard. Il viewport 3D Three.js è sempre il protagonista. Sidebar destra di 304px ospita widget contestuali (crediti, checklist, Copilot, ⌘K tip).

### Sources

- **GitHub repo**: [fedesanna99/FIA](https://github.com/fedesanna99/FIA) — `main` @ `ea835fa` (default branch). Explore for component implementations, store layout (Zustand multi-store), API client (`src/api/client.ts`), test patterns, viewport engine (`src/viewport-engine/`).
- **UX Redesign Brief**: `uploads/UX_REDESIGN_BRIEF.md` — la vision doc consegnata a Claude Design per il redesign mobile-first.
- **Kickoff prompt**: `uploads/CLAUDE_DESIGN_KICKOFF_PROMPT.md` — istruzioni operative per la sessione di redesign.
- **Project state**: `uploads/PROJECT_STATE.md` — stato vivo del progetto, sprint, decisioni strategiche.
- **Internal redesign spec (legacy)**: `UI_REDESIGN_SPEC.md` nel repo — proposta "5 workspace + rail sinistro" **superata** dal nuovo brief mobile-first.

> The reader should consult the GitHub repo for any deep production work — this design system is a faithful extract of *visual + interaction* DNA, not a substitute for the source of truth.

---

## 2 · Persona di riferimento

**Primaria** — **Strutturista italiano freelance**, 35-50 anni. Lavora su palazzine 4-6 piani, capannoni, ville, ristrutturazioni. Usa SAP2000 / MIDAS Civil in studio. Compila relazioni tecniche per Sportello Unico Edilizia, firma con timbro professionale. **Conosce NTC 2018 a memoria**. NON è developer. Si aspetta che l'app sia auto-esplicativa.

**Tester reale** — **Paoletto Lera**, ingegnere strutturista. Ha provato `v2.3.7` da smartphone e non è riuscito a completare nessun test. *"Non riesco a capire cosa sto guardando."* — è la frase che ha innescato l'intero redesign.

**Modi d'uso** — smartphone in cantiere/riunione per **leggere risultati**, desktop in studio per **modellare/calcolare seriamente**. Mobile è prima cittadina, non responsive squeeze.

---

## 3 · Content fundamentals

### Lingua

**Italiano per default.** Sempre. Anche i menu, i toast, i tooltip, i label dei campi. Inglese ammesso solo per termini tecnici inattaccabili (`Solve`, `Make`, `mesh`, `node`, `pushover`, `time-history`) e per le sigle normative (`EC3`, `EC8 §3.2.2.2`, `NTC18`).

### Tono

- **Tecnico, denso, onesto.** Niente marketing. Il README del prodotto dichiara apertamente *"Stato validazione: questa versione NON è raccomandata per progetti strutturali reali"* — quel livello di trasparenza è la voce.
- **Imperativo all'utente**, mai *"clicca qui per..."*: *"Apri Studio Pro"*, *"Scegli un percorso"*, *"Esegui"*, *"Verifica"*, *"Riprova"*.
- **Riferimenti normativi sempre nominati**: *"EC3 acciaio"*, *"NTC 2018 §3.5.3"*, *"EC8 spettro elastico"*. Mai un calcolo senza la norma applicata.
- **Italiano tecnico**: *"trave bi-appoggiata"*, *"telaio portale"*, *"reticolo spaziale"*, *"sollecitazioni"*, *"sezione"*, *"vincolo"*, *"carrello"*, *"incastro"*, *"cerniera"*, *"snervamento"*. Niente anglicismi inutili (*"sollecitazioni"*, non *"loads"*; *"carichi"*, non *"forces"*).

### Casing

- **Sentence case** per titoli e CTA: *"Inizia un'analisi."*, *"Apri Studio Pro"*, *"Vedi fatturazione"* — solo la prima lettera maiuscola, punto finale sui hero.
- **UPPERCASE + mono** per eyebrow, tag, stato, scorciatoie: `STUDIO PRO`, `BETA`, `9 TPL`, `DRAFT`, `⌘ N`, `FREE`. Tracking ampio (`letter-spacing: 0.14em` ~ `tracking-wide-3`). Sempre `font-mono` (JetBrains Mono).
- **Tutti minuscoli + slash prefix** per axis tag dei due hub: `/ Studio Pro`, `/ Percorsi`. È *l'unica* eccezione al sentence-case, ed è un pattern brand-specific.
- **Niente Title Case**. Mai *"Apri Studio Pro Da Qui"*.

### Pronomi e persona

- **Tu**, mai *"voi"* né *"Lei"*. L'app si rivolge a un singolo ingegnere, non a un'azienda. *"Apri il primo modello in 10 secondi"*, non *"Aprite..."*.
- **Niente *"noi"*** dall'app verso l'utente. L'app è uno strumento, non un compagno. *"Algoritmo prima"*, non *"Crediamo che l'algoritmo venga prima"*.
- **Eccezione Copilot**: quando il Copilot AI parla, può usare prima persona (*"L'elemento 5 (mezzeria) ha UR_max = 0.240, governato da LTB."*). Resta secco, tecnico, no chitchat.

### Emoji

- **No emoji decorative** nella UI. La lingua è tecnica, l'aestetica è Precision (sharp, hairline).
- **Eccezione operativa**: gli specs interni di redesign usano emoji per categorizzare workspace (🏗️ Modello, ⚙️ Analisi, 📊 Risultati, ✅ Verifiche, 🔄 I/O & Collab) — quelli **non** vanno nella UI finale, sono solo etichette per developer/designer in markdown.
- **Niente emoji nei toast, label, tooltip, dialog, empty state.**

### Numerica

- **Tabular nums sempre** sui dati: `font-variant-numeric: tabular-nums`. Allineamento per decimali importantissimo nelle tabelle di risultati.
- **Unità sempre esplicite**: `12.45 kNm`, `2.25 m`, `S275`, `IPE 300`. Mai un numero nudo.
- **Posizione sempre specificata** sui risultati: `M_max = 12.45 kNm @ x = 2.25 m`, mai *"M = 12.45"* ambiguo (è max? medio? al nodo i?). Vedi Principio UX #1.
- **Decimali italiani in copy narrativa** (`€11,40`), **punto decimale in numerica tecnica** (`12.45 kNm`, `0.240 UR`). La numerica è "sistema internazionale tecnico", la copy è "italiana".

### Esempi di copy reale (estratti dal repo)

| Contesto | Testo |
|---|---|
| Hero dashboard | *"Inizia un'analisi."* |
| Hero sub | *"Due modi per costruire e analizzare un modello strutturale. Algoritmo prima, AI per accelerare — niente black box, tutti i calcoli tracciabili a formule normative."* |
| Hub Studio Pro | *"Controllo totale sul modello."* / *"Modalità expert. Tutti gli strumenti, qualsiasi ordine, senza guardrail. Per chi sa già cosa fare."* |
| Hub Percorsi | *"Guidato, senza perdere controllo."* / *"Step persistenti, validation per step, sempre passabile a Studio Pro. Per chi vuole una traccia chiara."* |
| Empty state | *"Nessuna selezione. Clicca su un nodo o un elemento nel viewport (o nell'albero modello) per ispezionare le proprietà."* |
| Errore | *"Backend/database non disponibile. La UI resta navigabile, ma modelli e salvataggi richiedono le API."* |
| Tip | *"La command palette esegue qualsiasi azione: cerca per nome (\"esegui\", \"ispeziona\", \"report\") senza sapere dove sta nel menu."* |
| Save chip | *"Salvato 14:32"* |
| Suggerimento brand | *"Onestà sopra marketing"* (README repo) |

---

## 4 · Visual foundations

### Direction · Precision v2.0

Nasce nel `REDESIGN ARCHITETTI.zip` (2026-05-23). Sostituisce la direzione "dark by default" precedente (settore CAE è abituato al dark, ma per FEA Pro Federico ha scelto **light di default** — più leggibile in cantiere con la luce). Tre regole ferree:

1. **Sharp geometry** — TUTTI i border-radius sono `0`. L'unica eccezione: `--r-full: 9999px` per cerchi puri (avatar, dot indicator). Tailwind `rounded-xl/2xl/3xl` è forzato a 0 via override globale.
2. **Hairline borders** — niente multi-layer shadow, niente gradient ombre. Solo `box-shadow: 0 0 0 1px rgba(0,0,0,.06)` per pop / elev / dialog. La separazione tra elementi è sempre un border `1px`, mai un'ombra.
3. **Cyan singular accent** — `#0891B2` (light) / `#5DD7F2` (dark). Un solo accent. Studio Pro e Percorsi si distinguono per **layout e axis-tag** (pill cyan vs pill ink-black), non per colore tema.

### Colore

**Palette completa**: vedi `colors_and_type.css`. Cinque famiglie semantiche (`success`, `warn`, `coral`, `purple`, `danger`) usate solo dove **necessarie** — `success` per OK, `warn` per attenzione, `coral` per badge azione (`NEW`, `RUN`), `purple` per enterprise/premium, `danger` per errori/eliminazioni. **Tints di superficie** dedicati per ogni tono (`--bg-success`, `--bg-warn`, ecc.) per chip e banner — mai un colore semantico applicato a un fondo come solid fill.

**Background system** — cinque elevazioni: `bg` (page), `bg-panel` (sidebar/topbar), `bg-elevated` (dialog/dropdown — stesso colore di panel in light), `bg-hover`, `bg-viewport` (3D canvas), `bg-active` (riga selezionata).

**Ink system** — quattro livelli: `ink` (body, headings), `ink-muted` (descrizioni), `ink-dim` (label/eyebrow), `ink-faint` (placeholder, disabled). Contrasti tutti ≥ WCAG AA.

### Tipografia

**Tre famiglie:**

- **Inter** — sans default, body, UI labels, paragraph. Pesi 400/500/600/700.
- **Inter Tight** — display, per hero `h1/h2/h3` e titoli che vogliono tracking stretto (`-0.025em` su h1). Pesi 500/600/700.
- **JetBrains Mono** — numerica (sempre tabular-nums), eyebrow, kbd, code, eyebrow tag, version chip, IDs. Pesi 400/500/600.

**Scale** — 9 step, dal `xs (11/15)` al `4xl (44/46)`. Dashboard hero è `clamp` da 32px a 48px. Body default è **13px / 19** — densità informativa alta intenzionalmente, l'app è uno strumento tecnico-professionale (cfr. Linear, non Notion).

**Letter-spacing** — `tight-1..4` per display, `wide-1..4` per eyebrow/uppercase. Usato sistematicamente: `tracking-tight-2` su h2, `tracking-wide-3` su eyebrow, mai un default.

### Spacing & layout

**Scala 4px** (Tailwind default). Densità tipica:

- TopBar: **h-12** (48px) fissa.
- MobileTabbar: **h-14** (56px) + safe-area-bottom rispettato.
- Hub card: **min-h-200px**, padding `22px`.
- Dashboard side widget: **w-304px** fissa (desktop ≥ lg), padding interno `14px`.
- Gap card-grid: **gap-3** (12px) tra quick-actions, **gap-4/6/8** crescente tra sezioni.
- Form input height: **h-8** (32px); button height: **xs/sm/md/lg = 24/28/32/40px**.

**Breakpoints** (Tailwind sovrascritti): `sm 768px`, `md 1024px`, `lg 1280px`, `xl 1440px`. Mobile-first via Tailwind, ma con la regola del brief: **il mobile non è desktop spremuto** — viewport + bottom tabbar + inspector pannello, niente rail laterali.

### Animation

- **Tre durate**: `--d-fast 120ms` (hover, color), `--d-mid 200ms` (slide-up, transition), `--d-slow 360ms` (dialog enter, complex).
- **Tre easing**: `standard` (cubic-bezier 0.2, 0, 0, 1) — default, `decelerate` (entry), `accelerate` (exit).
- **Keyframe set canonico**: `fade-in`, `slide-up`, `slide-down`, `slide-right`, `slide-left` + Precision additivi (`precision-spin`, `precision-pulse`, `precision-shimmer`, `precision-indeterminate`, `precision-tick`, `precision-sweep`, `precision-spotlight`).
- **Stagger** via `[data-stagger]` — children animati con delay incrementale di 60ms (1..8) per sidebar cards / list items.
- **`prefers-reduced-motion`** rispettato globalmente — tutto a 0.01ms.
- **No bounce, no spring** — tutto easing standard. Il prodotto è uno strumento tecnico, non un'app consumer.

### Hover / focus / press

- **Hover** — cambia border (`border` → `border-light` o `ink-3` per emphasis) o bg (`bg-hover`). Mai opacity o scale.
- **Focus visible** — `outline: 2px solid var(--accent); outline-offset: 1px` globalmente. Su button/input anche `ring-2 ring-accent/30`.
- **Press / active** — sui pulsanti primary, `bg-accent-hover` → `bg-accent` con `active:bg-accent`. Mai scale-down, mai shadow-lift.
- **Touch targets ≥ 44px** in `@media (pointer: coarse)` (WCAG 2.5.5 AAA), eccetto icon button espliciti in topbar/statusbar via classe `no-touch-min`.

### Borders, shadows, radii

- **Border**: 3 strength — `border` (default), `border-light` (più discreto), `border-strong` (per dropzone, header table). Tutti hairline `1px`.
- **Shadow**: solo `pop` / `elev` / `dialog` — tutti varianti di `0 0 0 1px rgba(0,0,0,N)` con N crescente. Niente blur, niente offset.
- **Radii**: TUTTI `0`. Nessuna eccezione tranne `--r-full 9999px` per cerchi (avatar, status dot, severity chip nei resultsTable). Tailwind `rounded-md/lg/xl/2xl/3xl` è overridato a 0 con `!important`.

### Cards

Ogni card è: **`bg-bg-panel` + `border border-border` + `radius 0`**. Header opzionale con titolo h3 + descrizione muted + actions a destra, separato da bottom border. Padding `p-4` standard, `p-3` per liste dense (`dense` prop). **No drop-shadow.** Il "lift" su hover è `border-color` → `border-accent` o `border-ink-3`, mai un shadow-pop.

**Hub card** (Studio Pro / Percorsi) — variante speciale: padding `22px`, axis-tag `position: absolute; top: 0; left: 0` con `bg-accent` (Studio Pro) o `bg-ink` (Percorsi), uppercase mono `10px tracking-wide-2`. Hero h2 a `28px tracking-tight-3`. Bullet list mono `11px` con dash leading `w-2 h-px bg-ink-3`. CTA arrow in fondo.

**Project card** — thumb `h-110px` con grid pattern `12px` + SVG isometric del modello 3D/2D, status badge in alto a destra (`OK / DRAFT / RUN / ERR`), nome + meta mono in basso.

### Backgrounds & textures

- **Niente background image, niente full-bleed photo.** L'app non lo richiede.
- **Niente gradient** se non sul bottone `variant="run"` (verde emerald 500→600, **unica eccezione gradiente in tutto il sistema** — è la CTA "Esegui analisi" — vedi `Button.tsx`).
- **Grid pattern** nel viewport thumbnail dei modelli: `12×12px`, opacity 7%, `linear-gradient` doppio (orizzontale + verticale).
- **Pattern dropzone**: `border: 1px dashed var(--border-strong)`.

### Transparency / blur

- **Praticamente assente.** Il design system non usa `backdrop-filter` né tinte semi-trasparenti come surface. Le tints semantiche (`bg-info`, `bg-success`) sono colori solid, non rgba.
- **Eccezione**: dialog backdrop `rgba(0,0,0,0.40)` con `animation: fade-in 120ms`.

### Color vibe of imagery

L'app non ha imagery propria. I "modelli" sono **schemi SVG vettoriali deterministici** disegnati a runtime sulla griglia del viewport — telai 2D, reticoli isometrici. Tutto in `currentColor` con stroke `ink-2`. **Nessuna foto, nessuna illustrazione, nessuna icona colorata.** L'asset visivo è sempre **geometria pura**.

### Iconography

Vedi sezione 5 dedicata.

### Layout rules

- **Fixed elements**: TopBar (top, h-12), MobileTabbar (bottom mobile, h-14), Dashboard sidebar destra (304px su ≥ lg).
- **Viewport 3D Three.js** è centrale, sempre. Niente lo copre se non un dialog modale o un workspace panel a comparsa.
- **Grid main** Dashboard: `1fr + 304px sidebar`, stack su mobile.
- **Max-width** Dashboard: 1440px centered.
- **Z-index scale** rigorosa: `viewport 0`, `panel 10`, `toolbar 20`, `dropdown 30`, `popover 35`, `dialog 40`, `toast 50`, `tooltip 60`.

### Print

`@media print` nasconde topbar, leftrail, rightrail, statusbar, missionbar, dialog, `[data-no-print]`. Sfondo bianco, ink nero. Per il PDF report (reportlab server-side) ha layout separato.

---

## 5 · Iconography

### Sistema canonico

**[`lucide-react`](https://lucide.dev/)** è il sistema icona ufficiale del repo (vedi `package.json` → `"lucide-react": "^1.16.0"`). Anche `@tabler/icons-react` è installato per casi specifici (`^3.44.0`), ma lucide è il default.

**Stroke**: `1.8` (light, alcune topbar) o `2` (default lucide). Mai più di 2. Mai filled.
**Sizing**: `w-3 h-3` (10/12px in chip), `w-3.5 h-3.5` (14px, dashboard CTA), `w-4 h-4` (16px, default), `w-5 h-5` (20px, mobile tabbar inactive).
**Colore**: sempre `currentColor`. Mai colorate hard-coded. Il colore viene dal parent text.

### Usage tipico

| Contesto | Icone |
|---|---|
| Topbar | `Play` (run), `Check` (saved), `Undo2/Redo2`, `Bell` (notifiche), `Pencil` (edit), `Loader2` (loading) |
| Mobile tabbar | `Box` (modello), `Hammer` (make), `Zap` (solve), `BarChart3` (risultati), `MoreHorizontal` (altro) |
| Dashboard quick | `Plus` (new), `FileUp` (import), `Layers` (template), `FlaskConical` (esempi) |
| Stato | `WifiOff` (offline), `RefreshCcw` (retry), `ArrowRight` (CTA) |
| Copilot | `MessageSquare` |

### Emoji nella UI?

**No.** L'unico contesto dove appaiono emoji è nei *docs interni di redesign* (`UI_REDESIGN_SPEC.md`) per etichettare workspace: 🏗️ Modello, ⚙️ Analisi, 📊 Risultati, ✅ Verifiche, 🔄 I/O & Collab. **Questi non vanno mai nella UI finale.**

### Unicode chars?

**Sì, per simbologia tecnica matematica.** Sempre. Mai sostituire con immagini SVG quando un simbolo unicode esiste:

- Forze interne: `N`, `V`, `M` (mai `Normale`, `Taglio`, `Momento` come simbolo)
- Sollecitazioni: `σ` (sigma, stress), `τ` (tau, shear), `ε` (epsilon, strain), `δ` (delta, displacement), `ω` (omega, freq angolare), `Δ` (delta capital, variation)
- Coordinate: `uₓ`, `uᵧ`, `u_z`, `θₓ`, `θᵧ`, `θ_z` (subscript)
- Modi propri: `φ` (phi, eigenvector), `λ` (lambda, eigenvalue), `ξ` (xi, damping ratio)
- Verifica: `UR` (utilization ratio — sempre uppercase), `≤`, `≥`, `±`

### Asset SVG locali

- `assets/favicon.svg` — F bianco su quadrato `#185fa5` rounded — **logo storico**, da non usare nel redesign (non è in palette Precision cyan).
- `assets/pwa-icon.svg` — variante 512×512 PWA. Stesso logo storico.

> **NOTA al lettore**: il logo attuale `#185fa5` (un blu medio) **non è in Precision palette**. La direzione cyan (`#0891B2`) è recente; il logo non è ancora stato aggiornato. Tutti i mockup di redesign usano l'iniziale **"F"** come glyph testuale dentro un quadrato `bg-accent/10` con `border border-accent/40` — vedi `TopBar.tsx` riga ~120. Federico, chiedi se vuoi che ridisegniamo anche il logo, o se lo lasciamo storico.

### CDN fallback

Se serve un'icona non in `lucide-react`, **fall back a lucide via CDN** (`https://unpkg.com/lucide@latest/dist/umd/lucide.js`) prima di considerare altri set. Tabler è già installato come secondo. Mai mescolare set diversi nella stessa view.

---

## 6 · Manifest · cosa c'è in questa cartella

```
.
├── README.md                  ← questo file
├── SKILL.md                   ← skill manifest (cross-compatibile Agent Skills)
├── colors_and_type.css        ← design tokens completi (light + dark + type + spacing)
├── assets/
│   ├── favicon.svg            ← logo storico (F bianco su quadrato blu #185fa5)
│   └── pwa-icon.svg           ← variante 512×512 PWA
├── preview/                   ← cards 700×N px per il Design System tab
│   ├── colors-primary.html
│   ├── colors-semantic.html
│   ├── colors-tints.html
│   ├── colors-ink.html
│   ├── type-display.html
│   ├── type-body.html
│   ├── type-mono.html
│   ├── type-eyebrow.html
│   ├── spacing-scale.html
│   ├── spacing-radii.html
│   ├── elevation-borders.html
│   ├── motion.html
│   ├── btn-variants.html
│   ├── btn-sizes.html
│   ├── chip-badge.html
│   ├── form-fields.html
│   ├── cards.html
│   ├── empty-state.html
│   ├── kbd-mono.html
│   ├── icons.html
│   ├── logo-axis.html
│   └── copy-voice.html
└── ui_kits/
    ├── webapp_desktop/        ← Studio Pro · Dashboard, TopBar, sidebar widgets, viewport
    │   ├── README.md
    │   ├── index.html
    │   ├── TopBar.jsx
    │   ├── Dashboard.jsx
    │   ├── ProjectCard.jsx
    │   ├── HubCard.jsx
    │   ├── QuickAction.jsx
    │   ├── SideWidget.jsx
    │   ├── Chip.jsx
    │   ├── Button.jsx
    │   ├── Field.jsx
    │   └── Card.jsx
    └── mobile_redesign/       ← target redesign direction (in-progress)
        ├── README.md
        ├── index.html
        ├── MobileFrame.jsx
        ├── MobileTabbar.jsx
        ├── MobileHero.jsx
        ├── MobileProjectList.jsx
        ├── MobileTopbar.jsx
        └── ElementInspector.jsx
```

> The repo `fedesanna99/FIA` is the source of truth. Explore it for component implementations, store layout (Zustand multi-store: `modelStore`, `resultsStore`, `analysisStore`, `workspaceStore`, `historyStore`, `snapshotStore`, `jobsStore`, `authStore`, `climateStore`, `notificationsStore`, `toastStore`), API client patterns, Three.js viewport engine in `src/viewport-engine/`, and the legacy spec `UI_REDESIGN_SPEC.md` (superseded by `uploads/UX_REDESIGN_BRIEF.md` here).

---

## 7 · 7 principi UX non negoziabili

Dal `UX_REDESIGN_BRIEF.md`. Criteri di accettazione per ogni mockup di redesign:

1. **Ogni risultato ha un numero.** N/V/M/σ sempre con etichette di picco (`M_max = 12.45 kNm @ x = 2.25 m`). Mai un diagramma colorato senza valore.
2. **Ogni elemento è ispezionabile in 1 tap.** Pannello laterale persistente con geometria + materiale completo (E, fy, ν, ρ) + sezione completa (A, Iy, Iz, Wpl) + risultati con posizione esplicita + UR per ogni verifica.
3. **Mobile-first per consultazione, desktop per setup.** Niente responsive squeeze del desktop. Mobile è una vera prima cittadina.
4. **Discoverability via UI, palette come scorciatoia.** Ogni funzione raggiungibile da navigazione UI. ⌘K è un boost per esperti, mai un requisito.
5. **Stato del sistema sempre chiaro.** Solver running → UI bloccata con overlay. Modifiche → viewport aggiornato + highlight. Errori → mai whitescreen.
6. **Standard normativi sempre nominati.** *"EC1-1-4 §6.3.2"*, *"NTC18 §3.5.3"*. L'ingegnere deve poter verificare manualmente.
7. **Catalogo professionale.** Sezioni IPE/HEA/HEB/HEM/UPN/UPE/CHS/SHS/RHS + parametriche custom. Materiali S235/275/355/420/460 + C20-C50 + legno C18-C24-GL24h-GL28h-GL32h.

---

## 8 · Caveats & open questions

- **Font sostituzioni**: tutti i 3 font (Inter, Inter Tight, JetBrains Mono) sono Google Fonts ufficiali — nessuna sostituzione richiesta.
- **Logo non aggiornato**: il favicon `#185fa5` blu medio non è in palette Precision cyan. Da rivedere o accettare come storico. Vedi sezione 5.
- **Dark mode**: tokens completi sono qui (vedi `colors_and_type.css` blocco `[data-theme="dark"]`), ma le preview card sono in **light** (canonical default Precision). Dark è opt-in.
- **Mobile UI kit**: il mockup #1 (Mobile Dashboard) è il **prossimo passo** del redesign — la cartella `ui_kits/mobile_redesign/` qui è lo *scaffolding* pronto a riceverlo, non il mockup approvato. Ferma con Federico prima di trattarlo come finale.
- **Sample slides**: nessun deck attaccato → cartella `slides/` non creata.
- **Logo redesign**: aperto. Vedi sezione 5.

---

## 9 · Index dei file

- **`README.md`** ← qui
- **`SKILL.md`** — skill manifest, leggibile da Claude / Claude Code via `invoke_skill`
- **`colors_and_type.css`** — tutti i design tokens come CSS vars (light + dark)
- **`assets/`** — logo storico + PWA icon
- **`preview/`** — 21+ cards per il Design System tab (Type · Colors · Spacing · Components · Brand)
- **`ui_kits/webapp_desktop/`** — Studio Pro desktop (Dashboard hero, hub cards, sidebar, topbar)
- **`ui_kits/mobile_redesign/`** — scaffolding per il redesign mobile-first (in attesa del Mockup #1 approvato)
- **`uploads/`** — brief consegnati: `UX_REDESIGN_BRIEF.md`, `CLAUDE_DESIGN_KICKOFF_PROMPT.md`, `PROJECT_STATE.md`
