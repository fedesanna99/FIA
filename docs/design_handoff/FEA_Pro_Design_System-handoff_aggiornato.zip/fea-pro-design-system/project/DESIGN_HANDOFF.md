# FEA Pro · Design Handoff to Claude Code

> Documento maestro per implementare il redesign in `fedesanna99/FIA`.
> **Direzione**: Soft · Light default · Cyan singular accent · Plus Jakarta Sans display + Inter body.
> **Versione tokens**: v2.1 — fonte unica `src/tokens.css` (mirror TS in `src/tokens.ts`).
>
> Tutti i mockup HTML hi-fi sono il **contratto visivo** — quando il codice React diverge dal mockup, vince il mockup.

---

## 0 · Quick orientation

| Cosa | Dove | Status |
|---|---|---|
| Sitemap navigabile + token strip | `Sitemap.html` | ✅ Hub |
| Tokens CSS variables | `src/tokens.css` | ✅ v2.1 |
| Tokens TS mirror | `src/tokens.ts` | ✅ v2.1 |
| Studio Pro shell (Risultati workspace) | `ui_kits/webapp_desktop/Nuovo Guscio.html` | ✅ Reference |

**Per iniziare**: apri `Sitemap.html` nel browser. Ogni card è un link al mockup HTML hi-fi corrispondente. Le card con badge "NEXT" sono il prossimo step da implementare.

---

## 1 · Stile bloccato (NON cambiare senza chiedere)

### 1.1 Colors

| Token | Light | Dark | Uso |
|---|---|---|---|
| `--bg` | `#FAFAFA` | `#0E1014` | Sfondo app |
| `--bg-panel` | `#FFFFFF` | `#16191F` | Cards, sidebar, dialog |
| `--bg-elevated` | `#FFFFFF` | `#1D2128` | Popover, command palette |
| `--bg-hover` | `#F4F5F7` | `#1D2128` | Stato hover |
| `--bg-viewport` | `#F4F5F7` | `#08090C` | Sfondo 3D viewport |
| `--bg-active` | `#E6F1FB` | `#15314A` | Riga selezionata |
| `--border` | `#E5E6E8` | `#262B33` | Border hairline (default) |
| `--border-light` | `#D4D6DA` | `#2F3640` | Border hover/focus |
| `--border-strong` | `#A8ACB3` | `#3D4754` | Divider intenso |
| `--ink` | `#15161A` | `#F2F4F7` | Testo body |
| `--ink-muted` | `#4A4F57` | `#B5BAC2` | Testo secondario |
| `--ink-dim` | `#7B808A` | `#80868F` | Labels eyebrow |
| `--ink-faint` | `#B0B5BD` | `#555C66` | Disabled, tickmarks |
| `--accent` | `#0891B2` | `#6EDDF5` | Cyan singular |
| `--accent-hover` | `#0E7490` | `#88E2F5` | Hover su accent |
| `--accent-active` | `#155E75` | `#5DD7F2` | Click/pressed |
| `--accent-subtle` | `#ECFEFF` | rgba(110,221,245,.12) | Tinted bg |
| `--success` | `#65A30D` | `#8FD14F` | Run, validated |
| `--warn` | `#B45309` | `#FBBF24` | Preliminary, attention |
| `--coral` | `#C2410C` | `#FB923C` | Carichi, ridotto |
| `--purple` | `#534AB7` | `#B19BFB` | Verifiche, brand sec. |
| `--danger` | `#DC2626` | `#F87171` | Error, UR>1 |

**Regole d'uso**:
- **Cyan è singular accent**: usalo per CTA primarie, link, selezione, focus ring. Mai usare success/warn/danger per CTA — quelli sono semantic only.
- **Coral** = carichi distribuiti, forze applicate. Mai per altro.
- **Purple** = verifiche, normative, audit. Mai per altro.
- **Tinted backgrounds** (`--bg-*`) usali per banner contestuali e badge — mai per CTA.

### 1.2 Type

| Famiglia | Font | Uso |
|---|---|---|
| Display | Plus Jakarta Sans 700 | h1–h3, hero titles, modello name |
| Body | Inter 400/500/600 | Tutto il body, label, input |
| Mono | JetBrains Mono 500/600/700 | Numerici, code, eyebrow labels, kbd, units, status bar |

**Type scale**: `--fs-xs` (11) → `--fs-5xl` (56). Vedi `src/tokens.css` §4.

**Regole**:
- Numerici (valori, UR, M_Ed) **sempre in Mono** con `font-variant-numeric: tabular-nums`.
- Eyebrow labels (`SECTION · TITLE`) **sempre Mono uppercase**, `letter-spacing: var(--ls-wide-3)`, font-size 10–11px.
- Hero titles usano `letter-spacing: -0.035em` (Plus Jakarta Sans, sembra "loose" se non lo aggiungi).

### 1.3 Shape (Soft)

`--r-xs:4` · `--r-sm:6` · `--r-md:8` · `--r-lg:10` · `--r-xl:12` · `--r-2xl:16` · `--r-3xl:20` · `--r-full:9999`

| Elemento | Radius |
|---|---|
| Pulsanti, input, badges | 6–8 (sm/md) |
| Cards, panel sections | 10–14 (lg/xl) |
| Dialog, command palette | 14–16 (xl/2xl) |
| Avatar, dots, switch | 9999 (full) |

**Opt-in Sharp**: `<html data-radius="sharp">` azzera tutti i radii (utenti che preferiscono Precision strict).

### 1.4 Shadows (NEW v2.1)

| Token | Uso |
|---|---|
| `--shadow-pop` | Hairline only (1px border-color sostituibile) |
| `--shadow-elev` | Floating chip, badge sopra container |
| `--shadow-card` | Cards in griglia |
| `--shadow-hover` | Cards al hover (translateY-2px) |
| `--shadow-dialog` | Modal, command palette |

Filosofia: **mai shadow drammatiche**. Ombre soft + hairline border. In dark mode le ombre sono più scure (più alpha) per leggere come tali.

### 1.5 Motion

- **Durate**: `--d-fast: 120ms` (hover, toggle), `--d-mid: 200ms` (tab change, slide), `--d-slow: 360ms` (dialog enter, progress).
- **Easing**: `--ease-standard` per qualsiasi cosa. `--ease-decelerate` per enter (dialog appears). `--ease-accelerate` per exit.
- **Mai animazioni bouncy**. Mai parallax.

---

## 2 · Architettura del codice

### 2.1 Struttura target

```
fedesanna99/FIA/frontend/
├── src/
│   ├── tokens.css                          # ⬅ COPIA DAL HANDOFF
│   ├── tokens.ts                           # ⬅ COPIA DAL HANDOFF
│   │
│   ├── shell/                              # Studio Pro shell
│   │   ├── ShellTopBar.tsx
│   │   ├── ShellRail.tsx
│   │   ├── ShellViewport.tsx
│   │   ├── ShellPanel.tsx
│   │   ├── ShellStatusBar.tsx
│   │   ├── ShellCommandPalette.tsx
│   │   └── workspaces/
│   │       ├── ModelloWorkspace.tsx
│   │       ├── AnalisiWorkspace.tsx
│   │       ├── RisultatiWorkspace.tsx
│   │       ├── VerificheWorkspace.tsx
│   │       └── IOWorkspace.tsx
│   │
│   ├── auth/
│   │   ├── LoginPage.tsx
│   │   ├── SignupPage.tsx
│   │   ├── ForgotPasswordPage.tsx
│   │   └── EmailVerifyPage.tsx
│   │
│   ├── dashboard/
│   │   ├── DashboardPage.tsx
│   │   ├── TemplateGallery.tsx
│   │   └── RecentProjects.tsx
│   │
│   ├── percorsi/
│   │   ├── PercorsiList.tsx
│   │   └── PercorsoStepper.tsx
│   │
│   ├── dialogs/
│   │   ├── NodeDialog.tsx
│   │   ├── ElementDialog.tsx
│   │   ├── LoadDialog.tsx
│   │   ├── ConstraintDialog.tsx
│   │   ├── NewModelDialog.tsx
│   │   └── MeshParametricWizard.tsx
│   │
│   ├── settings/
│   │   └── SettingsPage.tsx
│   │
│   ├── states/
│   │   ├── EmptyState.tsx
│   │   ├── SolverRunningState.tsx
│   │   ├── ErrorState.tsx
│   │   └── NotFoundState.tsx
│   │
│   └── shared/                             # UI primitives
│       ├── Button.tsx
│       ├── Input.tsx
│       ├── NumericInput.tsx          // con UnitChip integrato
│       ├── Select.tsx
│       ├── Tabs.tsx
│       ├── Dialog.tsx                // Radix UI Dialog
│       ├── Tooltip.tsx               // Radix UI Tooltip
│       ├── KbdHint.tsx               // <kbd>⌘K</kbd>
│       ├── TrustBadge.tsx            // Preliminary/Draft/Validated
│       ├── URBar.tsx                 // verifica EC3 strip
│       ├── MetricTile.tsx            // δ/σ/f₁ tile
│       ├── HelpSheet.tsx             // slide-over help inline
│       ├── DataTable.tsx
│       └── icons/                    // lucide-react, no SVG inline
```

### 2.2 Stack tecnologico raccomandato

| Layer | Tool | Note |
|---|---|---|
| Framework | React 18 + TS strict | Già esistente |
| Bundler | Vite | Già esistente |
| Styling | Tailwind + CSS variables | Tailwind config legge da `tokens.css` |
| Headless UI | **Radix UI** | Per Dialog/Tooltip/Popover/Tabs/Select — accessibilità free |
| Forms | **react-hook-form + zod** | Validazione consistente |
| State | Zustand (già esistente) | |
| Server state | TanStack Query (già esistente) | |
| 3D viewport | Three.js + R3F (già esistente) | |
| Icons | **lucide-react** | Stroke 1.8, currentColor |
| Charts | Recharts (già esistente) | |
| Command palette | **cmdk** (Vercel) | Per ⌘K, ricerca fuzzy |

**Da aggiungere al package.json**:
```json
{
  "@radix-ui/react-dialog": "^1.1",
  "@radix-ui/react-tooltip": "^1.1",
  "@radix-ui/react-tabs": "^1.1",
  "@radix-ui/react-select": "^2.1",
  "@radix-ui/react-popover": "^1.1",
  "react-hook-form": "^7.53",
  "zod": "^3.23",
  "lucide-react": "^0.453",
  "cmdk": "^1.0"
}
```

### 2.3 Tailwind config snippet

```js
// tailwind.config.ts
import { tokens } from "./src/tokens";

export default {
  content: ["./src/**/*.{ts,tsx,html}"],
  theme: {
    extend: {
      colors: {
        // Bridge to CSS variables — auto-reactive to data-theme
        bg:          "var(--bg)",
        panel:       "var(--bg-panel)",
        elevated:    "var(--bg-elevated)",
        hover:       "var(--bg-hover)",
        viewport:    "var(--bg-viewport)",
        active:      "var(--bg-active)",
        border:      "var(--border)",
        "border-light":  "var(--border-light)",
        "border-strong": "var(--border-strong)",
        ink:         "var(--ink)",
        "ink-muted": "var(--ink-muted)",
        "ink-dim":   "var(--ink-dim)",
        "ink-faint": "var(--ink-faint)",
        accent:      "var(--accent)",
        "accent-hover":  "var(--accent-hover)",
        "accent-active": "var(--accent-active)",
        "accent-subtle": "var(--accent-subtle)",
        success: "var(--success)",
        warn:    "var(--warn)",
        coral:   "var(--coral)",
        purple:  "var(--purple)",
        danger:  "var(--danger)",
        info:    "var(--info)",
      },
      borderRadius: {
        xs: "4px", sm: "6px", md: "8px", lg: "10px",
        xl: "12px", "2xl": "16px", "3xl": "20px",
      },
      fontFamily: {
        sans: tokens.font.sans.split(",").map(s => s.trim().replace(/^"|"$/g, "")),
        display: tokens.font.display.split(",").map(s => s.trim().replace(/^"|"$/g, "")),
        mono: tokens.font.mono.split(",").map(s => s.trim().replace(/^"|"$/g, "")),
      },
      transitionDuration: {
        fast: "120ms", mid: "200ms", slow: "360ms",
      },
      transitionTimingFunction: {
        standard: tokens.motion.easeStandard,
        decelerate: tokens.motion.easeDecelerate,
        accelerate: tokens.motion.easeAccelerate,
      },
      boxShadow: {
        pop: "var(--shadow-pop)",
        elev: "var(--shadow-elev)",
        card: "var(--shadow-card)",
        hover: "var(--shadow-hover)",
        dialog: "var(--shadow-dialog)",
      },
      zIndex: tokens.zIndex,
    },
  },
};
```

### 2.4 Theme switch

Implementazione minimal — un hook `useTheme()` che legge/scrive `data-theme` su `<html>` e persiste in `localStorage`:

```ts
// src/shared/useTheme.ts
import { useEffect, useState } from "react";

type Theme = "light" | "dark";
const STORAGE_KEY = "feapro.theme";

export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(() => {
    if (typeof window === "undefined") return "light";
    return (localStorage.getItem(STORAGE_KEY) as Theme) ?? "light";
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem(STORAGE_KEY, theme);
  }, [theme]);

  return [theme, setThemeState] as const;
}
```

---

## 3 · Studio Pro Shell — contratto

Riferimento visivo: `ui_kits/webapp_desktop/Nuovo Guscio.html`.

### 3.1 Layout grid

```
┌────────────────────────────────────────────────────────────────┐
│ TopBar (h-12)                                                  │
├────┬─────────────────────────────────────────────┬─────────────┤
│Rail│         Viewport                            │   Panel     │
│ 56 │         (flex 1)                            │   380       │
│    │                                             │             │
├────┴─────────────────────────────────────────────┴─────────────┤
│ StatusBar (h-7)                                                │
└────────────────────────────────────────────────────────────────┘
```

CSS:
```css
.shell {
  display: grid;
  grid-template-rows: 48px 1fr 28px;
  grid-template-areas: "topbar" "mid" "status";
  height: 100vh;
}
.shell-mid {
  display: grid;
  grid-template-columns: 56px 1fr 380px;
  grid-area: mid;
}
```

### 3.2 TopBar — elementi (sx → dx)

1. **Brand block** (border-right): mark cyan 24px + "FEA Pro" + tier badge ("FREE"/"PRO") + version
2. **Model selector** (button): `[UC1]` + "Trave bi-appoggiata" + chevron-down → apre selector progetti recenti
3. **Save chip** (verde): "Salvato 14:32" — auto-update da last-mutation timestamp
4. **Trust badge** (giallo): "Preliminary" — pulsante che apre HelpSheet con spiegazione disclaimer v2.3.x
5. **Spacer flex-1**
6. **⌘K search**: pill 280px min con icona search + placeholder + kbd hint
7. **Run button** (verde gradient): "▶ Esegui" + kbd "F5"
8. Undo · Redo · Notifications (badge) · Avatar

### 3.3 Rail — 5 workspace

| # | id | Label | Icon (lucide) | Kbd |
|---|---|---|---|---|
| 1 | modello | Modello | Box | 1 |
| 2 | analisi | Analisi | Cog | 2 |
| 3 | risultati | Risultati | Activity | 3 |
| 4 | verifiche | Verifiche | CheckCircle | 4 |
| 5 | io | I/O & Collab | Shuffle | 5 |

Separator, poi:
- Auto-detect (Bug) — kbd "F3"
- Docs (BookOpen) — kbd "?"

Spacer, in fondo:
- Settings (Settings)

**Stato attivo**: bg `accent-subtle`, color `accent`, accent strip 3px sul lato sinistro che esce di -7px (decorativo).

**Tooltip**: appare su hover con label + kbd shortcut.

### 3.4 Viewport — HUD floating

5 HUD posizionati così:
- **vp-legend** (top-left): colormap stress legend (16x9 chip)
- **vp-controls** (top-right): persp/ortho + solid/wire + grid toggle
- **vp-selection** (top-center): chip breadcrumb selezione attiva (`EL 5 · IPE 300 · S355`)
- **vp-gizmo** (bottom-right): axes XYZ 88×88
- **vp-ruler** (bottom-left): scala 1m
- **vp-zoom** (bottom-center): pan + zoom out/in + zoom% + fit + maximize

Tutti gli HUD: `--bg-panel` + `--border` + `--shadow-card` + `--r-lg`.

**Watermark**: quando `trustState !== "validated"`, overlay diagonale "PRELIMINARY · PRELIMINARY" rotato -12°, opacity 0.05, font Mono 88px peso 800.

### 3.5 Right Panel — anatomia

```
┌─────────────────────────┐
│ Header (icon · title · ?)│ 14/16 padding, border-bottom
│ Description             │
├─────────────────────────┤
│ Tabs (border-bottom)    │ 10/12 padding, accent underline su .active
├─────────────────────────┤
│ Scroll body             │
│  ┌─ Section ─────────┐  │ ogni section: padding 14/16, border-bottom
│  │ eyebrow · action │  │
│  │  content         │  │
│  └──────────────────┘  │
│  ...                    │
└─────────────────────────┘
```

### 3.6 Command Palette ⌘K (cmdk)

- Modal centrato con backdrop blur
- Input grande (16px) con placeholder "Cerca azioni, modelli, norme… o chiedi all'AI"
- Lista raggruppata: Suggerito ora · Workspace · Analisi · Verifiche · Modello · Sistema
- **AI integration**: la prima riga in "Suggerito ora" è sempre un suggerimento AI contestuale (`Chiedi al Copilot: "..."`)
- Footer: kbd hints + AI eyebrow
- Cmd+K toggle, Esc chiude, ↑↓ naviga, ↵ esegue

---

## 4 · Endpoint backend mapping

### 4.1 Routes implementate ma NON esposte in UI v2.3 (gap)

| Endpoint | Workspace | Componente | Priority |
|---|---|---|---|
| `POST /api/mesh/parametric` | Modello | `MeshParametricWizard` | HIGH |
| `POST /api/verify/ec2` | Verifiche | `Verify EC2 tab` | HIGH |
| `POST /api/verify/ec5` | Verifiche | `Verify EC5 tab` | HIGH |
| `POST /api/verify/ec8` | Verifiche | `Verify EC8 tab + spettro` | HIGH |
| `POST /api/analyze/pushover` | Analisi | `PushoverParams` | MED |
| `POST /api/analyze/seismic-th` | Analisi | `SeismicTimeHistory + drift` | MED |
| `POST /api/analyze/fatigue` | Analisi | `FatigueRainflow` | LOW |
| `POST /api/import/dxf` | I/O | `ImportDXF` | HIGH |
| `POST /api/import/ifc` | I/O | `ImportIFC` | MED |
| `POST /api/export/dxf` | I/O | `ExportDXF` | MED |
| `POST /api/export/ifc` | I/O | `ExportIFC` | MED |
| `POST /api/compare` | I/O | `CompareABTab` | HIGH |
| `POST /api/autodetect` | Sistema | `AutoDetectPanel + fixes` | HIGH |
| `GET /api/accelerograms` | I/O | `AccelerogramCatalog` | MED |
| `POST /api/postprocess/isolines` | Risultati | `Postprocess tab → Iso-linee` | MED |
| `POST /api/postprocess/slice` | Risultati | `Postprocess tab → Slice planes` | MED |
| `POST /api/quality/zz` | Risultati | `Qualità tab → ZZ error` | LOW |
| `POST /api/quality/refine` | Risultati | `Qualità tab → h-refinement` | LOW |
| `WS /ws/collab` | Sistema | `CollabCursors + lock` | LOW |
| `POST /api/ai/ask` | Sistema | `AICopilot + ⌘K integration` | MED |

### 4.2 WebSocket contracts

**`/ws/solver`** — invio progress durante analisi
```ts
type SolverMessage =
  | { type: "started", solver: "static" | "modal" | ..., n_dof: number }
  | { type: "progress", step: number, total: number, msg: string }
  | { type: "done", duration_ms: number, results_url: string }
  | { type: "error", code: "SINGULAR_MATRIX" | "NAN" | "...", explainer: string }
```

**`/ws/collab`** — cursori e lock real-time
```ts
type CollabMessage =
  | { type: "presence", users: User[] }
  | { type: "cursor", userId: string, pos: { x, y, z } }
  | { type: "lock", userId: string, entityId: string, action: "acquire" | "release" }
  | { type: "operation", op: Operation, lamport: number }
```

---

## 5 · UI Primitives — specifiche

### 5.1 Button

```tsx
type ButtonProps = {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  kbd?: string;          // shortcut hint
  icon?: ReactNode;
  iconPosition?: "leading" | "trailing";
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
};
```

| variant | bg | color | border |
|---|---|---|---|
| primary | `--accent` | `#fff` | transparent |
| secondary | transparent | `--ink` | `--border` |
| ghost | transparent | `--ink-muted` | transparent |
| danger | `--danger` | `#fff` | transparent |

| size | h | padding | font |
|---|---|---|---|
| sm | 28 | 0 10 | 12 |
| md | 32 | 0 14 | 13 |
| lg | 40 | 0 18 | 14 |

Radius: `--r-md` (8px). Run-button è una variante speciale con gradient verde.

### 5.2 NumericInput (specifico FEA)

```tsx
type NumericInputProps = {
  value: number;
  onChange: (v: number) => void;
  unit?: string;        // "kN", "m", "MPa"
  step?: number;
  min?: number; max?: number;
  precision?: number;
  helpText?: string;    // tooltip su hover "?"
  errorText?: string;
};
```

Layout: input numerico tabular-nums + UnitChip mono uppercase. Help icon "?" che apre tooltip.

### 5.3 TrustBadge

```tsx
type TrustState = "preliminary" | "draft" | "validated";
type TrustBadgeProps = { state: TrustState; clickable?: boolean };
```

Colori per stato:
- preliminary: bg `--bg-warn`, color `--warn`, pulse dot 6px
- draft: bg `--bg-info`, color `--accent`
- validated: bg `--bg-success`, color `--success`

Cliccando apre HelpSheet con spiegazione contestuale del trust level.

### 5.4 URBar (verifica EC*)

```tsx
type URBarProps = {
  elementId: number;
  ur: number;          // 0..1+
  governing: "RES" | "LTB" | "BUCK" | "SHEAR" | "AXIAL";
  selected?: boolean;
};
```

Bar colorata: ur<0.5 success, ur<0.8 warn, ur≥1 danger. Su click: seleziona elemento nel viewport.

### 5.5 MetricTile

```tsx
type MetricTileProps = {
  label: string;       // eyebrow mono ("δ_max")
  value: string;       // mono tabular ("9.61")
  unit?: string;       // small dim ("mm")
  sub?: string;        // mono dim ("@ x = 3.00 m")
  tone?: "default" | "ok" | "warn" | "danger";
};
```

---

## 6 · Interaction storyboard

### 6.1 Sequenza Quickstart (Percorso UC1)

1. **Login** → Auth.html state "login" → POST /auth/login → redirect /dashboard
2. **Dashboard** → click "Percorso UC1" → /percorsi/uc1
3. **Step 1 · Geometria**: span input (default 6m) → "Avanti" disabled finché valore valido
4. **Step 2 · Vincoli**: tap su nodo sx → apre ConstraintDialog → seleziona Cerniera → apply. Stesso per nodo dx con Carrello.
5. **Step 3 · Carichi**: click "Aggiungi carico distribuito" → LoadDialog → q = 10 kN/m → apply.
6. **Step 4 · Solve**: "▶ Esegui" → SolverRunningState (WS streaming progress) → ~0.8s → success transition
7. **Step 5 · Verify**: tab EC3 → URBar per elemento → governing LTB
8. **Step 6 · Export**: "Genera report" → POST /api/export/pdf → download

### 6.2 Sequenza click su elemento

1. User clicca su Beam EL 5 nel viewport
2. Viewport: halo cyan attorno all'elemento, accent label `EL 5` sopra
3. Right panel: scrolla automaticamente alla section "Ispettore · EL 5"
4. Status bar: aggiorna "Selezione: Elemento 5 · IPE 300"
5. Breadcrumb selezione fluttua sopra viewport con close-x

### 6.3 Sequenza ⌘K

1. ⌘K → opens CommandPalette overlay con backdrop
2. Autofocus input. Riga "Suggerito ora" mostra suggerimento AI contestuale.
3. User digita "esp" → fuzzy match: "Esporta report PDF" + altre
4. ↵ → chiude palette + esegue azione
5. Esc → chiude senza azione

---

## 7 · Accessibility checklist

- [ ] Tutti i pulsanti: focus visibile con outline 2px `--accent` + offset 2px
- [ ] Color contrast: ink/bg ≥ 7:1 (WCAG AAA), ink-muted/bg ≥ 4.5:1 (AA)
- [ ] Tutti i dialog: focus trap (Radix Dialog lo fa automaticamente), Esc chiude
- [ ] Tutti gli icon button hanno `aria-label`
- [ ] Tabs hanno role="tablist" / "tab" / "tabpanel" (Radix Tabs)
- [ ] Tooltip su shortcut hint: anche descrizione (es. "Apri palette ⌘K — Cmd+K")
- [ ] Numerici devono accettare paste con virgola decimale (IT) e convertire
- [ ] Modalità keyboard-only: ⌘K + frecce + ↵ + Esc devono coprire 80% delle azioni

---

## 8 · Implementation checklist per Claude Code

### Fase 1 · Foundation (giorno 1)
- [ ] Copiare `src/tokens.css` e `src/tokens.ts` dal handoff
- [ ] Aggiornare `tailwind.config.ts` con il bridge a CSS variables
- [ ] Installare Radix UI + lucide-react + cmdk + react-hook-form + zod
- [ ] Creare hook `useTheme()` e wrapper `<ThemeProvider>` in `App.tsx`
- [ ] Importare font Google (Plus Jakarta Sans · Inter · JetBrains Mono) in `index.html`
- [ ] Rifare `src/shared/Button.tsx` come reference per gli altri primitives

### Fase 2 · Studio Pro shell (giorno 2-3)
- [ ] `ShellTopBar` — replica esatta di Nuovo Guscio.html
- [ ] `ShellRail` con 5 workspace + tooltip Radix
- [ ] `ShellPanel` con tabs Radix
- [ ] `ShellStatusBar`
- [ ] `ShellCommandPalette` con cmdk
- [ ] Cablare `useTheme`, `data-radius`, `data-accent` switches
- [ ] **Acceptance test**: confronto visivo screenshot ↔ Nuovo Guscio.html, deve essere identico

### Fase 3 · Risultati workspace (giorno 4)
- [ ] `RisultatiWorkspace` con sections: Snapshot · Metriche · Display · Scala · Verify · Inspector
- [ ] `MetricTile` primitive
- [ ] `URBar` primitive
- [ ] `Inspector` component
- [ ] Connessione TanStack Query a `/api/results/:modelId`

### Fase 4 · Auth + Dashboard + Percorsi (giorno 5-6)
Vedi mockup specifici.

### Fase 5 · Modello + Analisi + Verifiche + I/O (giorno 7-10)
Vedi mockup specifici.

### Fase 6 · Dialogs + Wizards + States + Settings (giorno 11-12)
Vedi mockup specifici.

---

## 9 · Cosa NON fare

- ❌ **Non inventare nuovi colori**. Se serve un colore, usalo dai tokens. Se manca un token, chiedi.
- ❌ **Non usare emoji** come decoro UI (solo le icone lucide-react). Eccezione: badge "NEW" può avere "✨" se concordato.
- ❌ **Non usare `style={{...}}` inline** in produzione — sempre Tailwind classes o CSS modules.
- ❌ **Non bypassare Radix UI** per modal/tooltip/popover — l'accessibilità non è negoziabile.
- ❌ **Non hardcodare numeri** dai mockup (UR=0.24, δ=9.61mm) — sono placeholder, vengono dal backend.
- ❌ **Non implementare WebSocket senza retry/reconnect logic**. Vedi `useWebSocket` hook.
- ❌ **Non rimuovere il TrustBadge** dalla TopBar finché v2.3.x non è validata.
- ❌ **Non aggiungere shadow drammatiche o glow effects**. Filosofia Soft = hairline + sottile.

---

## 10 · Domande aperte / decisioni da prendere

Tieni traccia di queste mentre implementi:

- [ ] Vogliamo "accent semantic per workspace" (es. Verifiche=purple, I/O=coral)? Default: NO, cyan singular.
- [ ] Mobile-first redesign in scope per v2.4? Default: NO, desktop-first.
- [ ] Animazione transizione workspace switch (slide vs fade)? Default: fade 200ms.
- [ ] Salvare workspace attivo + tab attivo per progetto (URL params)? Raccomandato SI per deep-link.
- [ ] Trust badge: il click apre HelpSheet o dropdown con cambio stato? Default: HelpSheet (read-only).

---

## 11 · Contatti

- **Designer**: AI assistant via questa chat — `Sitemap.html` è il punto di partenza
- **Repo target**: github.com/fedesanna99/FIA
- **Doc maestro**: questo file

Quando un mockup HTML differisce dal codice esistente: il **mockup vince**. Se hai dubbi su un dettaglio (spacing, peso font, durata animazione), apri il mockup nel browser, ispeziona, copia i valori dal CSS computato.

---

*v0.1 · Generato col redesign Nuovo Guscio · da estendere con ogni nuovo mockup*
