// Mobile Dashboard — SCAFFOLDING for redesign Mockup #1.
// This is the structural sketch (tokens + tabbar + hub layout), NOT the
// approved final mockup. Mockup #1 lands in the next Claude Design session.
function MobileDashboard() {
  const recent = [
    { name: "Trave bi-appoggiata UC1", meta: "11 N · 10 EL · ieri",  is3d: false, status: "ok" },
    { name: "Telaio portale 2D",        meta: "18 N · 21 EL · 2 ore", is3d: false, status: "run" },
    { name: "Reticolo 3D · Capannone",  meta: "36 N · 84 EL · 4 mag", is3d: true,  status: "ok" },
    { name: "Piastra Q4 2×2 m",         meta: "9 N · 4 EL · 2 mag",   is3d: false, status: "draft" },
  ];

  return (
    <section className="mscreen" data-screen-label="Mobile Dashboard (scaffolding)">
      <MobileTopbar />
      <div className="mbody">
        <div className="scaffold-banner" role="note">
          <span className="lbl">Scaffold</span>
          <span>Direzione, non mockup approvato. Il Mockup #1 (Mobile Dashboard) arriva nella sessione Claude Design successiva, dopo approvazione del design system.</span>
        </div>

        <div className="mhero">
          <span className="eb"><span className="dot" /> 4 modelli · 1 in run</span>
          <h1>Inizia<br/>un'analisi.</h1>
          <p>Algoritmo prima, AI per accelerare. Tutti i calcoli tracciabili a formule normative.</p>
        </div>

        <article className="mhub">
          <span className="mhub-tag studio">/ Studio Pro</span>
          <h2>Controllo totale<br/>sul modello.</h2>
          <p>Modalità expert. Tutti gli strumenti, qualsiasi ordine.</p>
          <div className="cta-row">
            <button className="cta primary" type="button">Apri Studio Pro <MIcon.ArrowR /></button>
          </div>
        </article>

        <article className="mhub">
          <span className="mhub-tag percorsi">/ Percorsi</span>
          <h2>Guidato,<br/>senza perdere controllo.</h2>
          <p>Step persistenti, validation per step. Per chi vuole una traccia chiara.</p>
          <div className="cta-row">
            <button className="cta outline" type="button">Scegli un percorso <MIcon.ArrowR /></button>
          </div>
        </article>

        <div>
          <div className="msect-head">
            <h2>Modelli recenti</h2>
            <a href="#">Tutti →</a>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 10 }}>
            {recent.map((m, i) => (
              <button key={i} type="button" className="mprow">
                <div className="thumb">
                  <div className="thumb-grid" />
                  <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }} viewBox="0 0 56 44" preserveAspectRatio="xMidYMid meet">
                    {m.is3d ? (
                      <g stroke="var(--ink-muted)" strokeWidth="1" fill="none">
                        <rect x="10" y="10" width="32" height="20" />
                        <rect x="16" y="6"  width="32" height="20" />
                        <line x1="10" y1="10" x2="16" y2="6" />
                        <line x1="42" y1="10" x2="48" y2="6" />
                        <line x1="10" y1="30" x2="16" y2="26" />
                        <line x1="42" y1="30" x2="48" y2="26" />
                      </g>
                    ) : (
                      <g stroke="var(--ink-muted)" strokeWidth="1" fill="none">
                        <line x1="8" y1="34" x2="8" y2="10" />
                        <line x1="48" y1="34" x2="48" y2="10" />
                        <line x1="8" y1="10" x2="48" y2="10" />
                        <line x1="8" y1="34" x2="48" y2="34" />
                      </g>
                    )}
                  </svg>
                </div>
                <div className="info">
                  <div className="name">{m.name}</div>
                  <div className="sub">{m.meta}</div>
                </div>
                <span className={`pstatus ${m.status}`}>{({ ok: "OK", run: "RUN", draft: "DRAFT" })[m.status]}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
      <MobileTabbar active="model" />
    </section>
  );
}

window.MobileDashboard = MobileDashboard;
