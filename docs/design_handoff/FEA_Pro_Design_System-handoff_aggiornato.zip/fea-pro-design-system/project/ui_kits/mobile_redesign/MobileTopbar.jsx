// Mobile TopBar — 44pt, minimal. Logo + page title + search/menu.
function MobileTopbar({ title, leftBack, onBack, right = "menu" }) {
  return (
    <header className="mtopbar">
      {leftBack ? (
        <button className="micon-btn" type="button" onClick={onBack} aria-label="Indietro" style={{ color: "var(--ink)" }}>
          <MIcon.ChevL />
        </button>
      ) : (
        <div className="mbrand">
          <div className="mbrand-mark"><span>F</span></div>
          <span className="mbrand-name">FEA Pro</span>
        </div>
      )}
      {title && <span style={{ fontSize: 14, fontWeight: 600, marginLeft: leftBack ? 0 : 8 }}>{title}</span>}
      <div className="right">
        <button className="micon-btn" type="button" aria-label="Cerca"><MIcon.Search /></button>
        {right === "menu" && <button className="micon-btn" type="button" aria-label="Menu"><MIcon.Menu /></button>}
      </div>
    </header>
  );
}

window.MobileTopbar = MobileTopbar;
