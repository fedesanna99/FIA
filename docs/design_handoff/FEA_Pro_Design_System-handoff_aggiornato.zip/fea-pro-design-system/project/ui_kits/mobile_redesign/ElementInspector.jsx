// Element Inspector — concrete demonstration of UX Principio #2:
// "Every element is inspectable in 1 tap" with FULL data (geometry,
// material, section, results-with-position, UR per check).
function ElementInspector() {
  return (
    <section className="mscreen" data-screen-label="Mobile Element Inspector">
      <MobileTopbar leftBack title="Elem #5 · Trave" />

      <div className="insp-body" style={{ flex: 1, overflowY: "auto", padding: "14px 14px 28px", display: "flex", flexDirection: "column", gap: 14 }}>

        {/* Geometria */}
        <div className="insp-group">
          <div className="gh">
            <span>Geometria</span>
            <span className="norm">L = 6.000 m</span>
          </div>
          <div className="gb">
            <div className="insp-row"><span className="k">nodo i</span> <span className="v">N3</span></div>
            <div className="insp-row"><span className="k">nodo j</span> <span className="v">N4</span></div>
            <div className="insp-row"><span className="k">x<sub>i</sub></span> <span className="v">2.000 m</span></div>
            <div className="insp-row"><span className="k">x<sub>j</sub></span> <span className="v">8.000 m</span></div>
            <div className="insp-row"><span className="k">tipo</span> <span className="v">beam2d</span></div>
            <div className="insp-row"><span className="k">orient.</span> <span className="v">+X</span></div>
          </div>
        </div>

        {/* Materiale */}
        <div className="insp-group">
          <div className="gh">
            <span>Materiale · S275</span>
            <span className="norm">EC3 §3.2 / NTC18 §11.3</span>
          </div>
          <div className="gb">
            <div className="insp-row"><span className="k">E</span> <span className="v">210 000 MPa</span></div>
            <div className="insp-row"><span className="k">f<sub>y</sub></span> <span className="v">275 MPa</span></div>
            <div className="insp-row"><span className="k">ν</span> <span className="v">0.30</span></div>
            <div className="insp-row"><span className="k">ρ</span> <span className="v">7850 kg/m³</span></div>
            <div className="insp-row"><span className="k">G</span> <span className="v">80 769 MPa</span></div>
            <div className="insp-row"><span className="k">α<sub>T</sub></span> <span className="v">12e-6 1/K</span></div>
          </div>
        </div>

        {/* Sezione */}
        <div className="insp-group">
          <div className="gh">
            <span>Sezione · IPE 300</span>
            <span className="norm">Catalogo EN 10025</span>
          </div>
          <div className="gb">
            <div className="insp-row"><span className="k">A</span> <span className="v">53.81 cm²</span></div>
            <div className="insp-row"><span className="k">J</span> <span className="v">20.12 cm⁴</span></div>
            <div className="insp-row"><span className="k">I<sub>y</sub></span> <span className="v">8356 cm⁴</span></div>
            <div className="insp-row"><span className="k">I<sub>z</sub></span> <span className="v">604 cm⁴</span></div>
            <div className="insp-row"><span className="k">W<sub>pl,y</sub></span> <span className="v">628 cm³</span></div>
            <div className="insp-row"><span className="k">W<sub>pl,z</sub></span> <span className="v">125 cm³</span></div>
          </div>
        </div>

        {/* Risultati con posizione esplicita */}
        <div className="insp-group">
          <div className="gh">
            <span>Sollecitazioni · statica</span>
            <span className="norm">SLU · γ = 1.35/1.50</span>
          </div>
          <div className="gb insp-1col">
            <div className="insp-row"><span className="k">N <small style={{ color: "var(--ink-faint)" }}>(max @ nodo i)</small></span> <span className="v">−340.12 kN</span></div>
            <div className="insp-row"><span className="k">V<sub>y</sub> <small style={{ color: "var(--ink-faint)" }}>(max @ nodo j)</small></span> <span className="v">18.40 kN</span></div>
            <div className="insp-row"><span className="k">M<sub>z, max</sub> <small style={{ color: "var(--ink-faint)" }}>@ x = 3.00 m (mezzeria)</small></span> <span className="v">12.45 kNm</span></div>
            <div className="insp-row"><span className="k">M<sub>z, min</sub> <small style={{ color: "var(--ink-faint)" }}>@ x = 0.00 m</small></span> <span className="v">−6.20 kNm</span></div>
            <div className="insp-row"><span className="k">δ<sub>y, max</sub> <small style={{ color: "var(--ink-faint)" }}>@ x = 3.00 m</small></span> <span className="v">8.42 mm</span></div>
          </div>
        </div>

        {/* Verifiche */}
        <div className="insp-group">
          <div className="gh">
            <span>Verifiche EC3</span>
            <span className="norm">EC3 §6.2 / §6.3</span>
          </div>
          <div style={{ padding: "10px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
            <div>
              <div className="insp-row" style={{ borderBottom: "none" }}>
                <span className="k">Resistenza N+M (§6.2)</span>
                <span className="v">UR = 0.24</span>
              </div>
              <div className="uc-bar"><div style={{ width: "24%", background: "var(--success)" }} /></div>
            </div>
            <div>
              <div className="insp-row" style={{ borderBottom: "none" }}>
                <span className="k">Stabilità flesso-tors. (§6.3.3)</span>
                <span className="v warn">UR = 0.82</span>
              </div>
              <div className="uc-bar"><div style={{ width: "82%", background: "var(--warn)" }} /></div>
            </div>
            <div>
              <div className="insp-row" style={{ borderBottom: "none" }}>
                <span className="k">Taglio (§6.2.6)</span>
                <span className="v">UR = 0.18</span>
              </div>
              <div className="uc-bar"><div style={{ width: "18%", background: "var(--success)" }} /></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

window.ElementInspector = ElementInspector;
