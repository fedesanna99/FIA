// Results screen — concrete demonstration of UX Principio #1:
// "Every result has a number" — peak labels visible by default.
function ResultsView() {
  return (
    <section className="mscreen" data-screen-label="Mobile Results (peak labels)">
      <MobileTopbar leftBack title="Trave bi-appoggiata UC1" />
      <div className="mbody" style={{ paddingBottom: 72 }}>
        <div>
          <div className="msect-head">
            <h2>Diagramma M<sub>z</sub></h2>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--ink-dim)" }}>SLU · γ=1.35/1.50</span>
          </div>
          <div className="mvp" style={{ marginTop: 10 }}>
            <div className="grid" />
            <span className="stamp">M<sub>z</sub> · kNm</span>
            <svg viewBox="0 0 360 220" preserveAspectRatio="xMidYMid meet">
              <g fill="var(--danger)" fillOpacity="0.20" stroke="none">
                <path d="M40,110 Q180,30 320,110 L320,140 Q180,80 40,140 Z" />
              </g>
              <g stroke="var(--ink)" strokeWidth="1.5" fill="none">
                <line x1="40" y1="110" x2="320" y2="110" />
                <line x1="40" y1="140" x2="320" y2="140" />
              </g>
              <g fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" fill="var(--danger)" textAnchor="middle">
                <text x="180" y="46">M<tspan baselineShift="sub" fontSize="9">max</tspan> = 12.45 kNm</text>
                <text x="180" y="60" fontSize="9" fill="var(--ink-dim)">@ x = 3.00 m (mezzeria)</text>
              </g>
              <g fontFamily="JetBrains Mono" fontSize="10" fontWeight="600" fill="var(--ink-dim)">
                <text x="40" y="170" textAnchor="middle">−6.20</text>
                <text x="320" y="170" textAnchor="middle">−5.80</text>
              </g>
              {/* Supports */}
              <g stroke="var(--ink)" strokeWidth="1.5" fill="none">
                <path d="M40,140 L32,156 L48,156 Z" fill="var(--ink)" />
                <circle cx="320" cy="156" r="6" fill="var(--bg-panel)" />
              </g>
            </svg>
          </div>
        </div>

        <div>
          <div className="msect-head">
            <h2>Diagramma V<sub>y</sub></h2>
          </div>
          <div className="mvp" style={{ marginTop: 10 }}>
            <div className="grid" />
            <span className="stamp">V<sub>y</sub> · kN</span>
            <svg viewBox="0 0 360 200" preserveAspectRatio="xMidYMid meet">
              <g fill="var(--accent)" fillOpacity="0.18" stroke="var(--accent)" strokeWidth="1.5">
                <path d="M40,80 L180,80 L180,140 L40,140 Z" />
                <path d="M180,140 L320,140 L320,80 L180,80 Z" opacity="0.6" />
              </g>
              <g fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" fill="var(--accent)">
                <text x="60" y="70">+18.40 kN</text>
                <text x="220" y="160">−16.20 kN</text>
              </g>
              <g stroke="var(--ink)" strokeWidth="1.5" fill="none">
                <line x1="40" y1="110" x2="320" y2="110" />
                <path d="M40,140 L32,156 L48,156 Z" fill="var(--ink)" />
                <circle cx="320" cy="156" r="6" fill="var(--bg-panel)" />
              </g>
            </svg>
          </div>
        </div>

        <div>
          <div className="msect-head">
            <h2>Deformata</h2>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--ink-dim)" }}>scala 200×</span>
          </div>
          <div className="mvp" style={{ marginTop: 10 }}>
            <div className="grid" />
            <span className="stamp">δ<sub>y</sub> · mm</span>
            <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">
              <g stroke="var(--ink-faint)" strokeWidth="1" strokeDasharray="2,3" fill="none">
                <line x1="40" y1="90" x2="320" y2="90" />
              </g>
              <g stroke="var(--accent)" strokeWidth="2" fill="none">
                <path d="M40,90 Q180,140 320,90" />
              </g>
              <g fontFamily="JetBrains Mono" fontSize="11" fontWeight="600" fill="var(--accent)" textAnchor="middle">
                <text x="180" y="156">δ<tspan baselineShift="sub" fontSize="9">max</tspan> = 8.42 mm</text>
                <text x="180" y="170" fontSize="9" fill="var(--ink-dim)">L / 712 &lt; L / 250 ✓</text>
              </g>
              <g stroke="var(--ink)" strokeWidth="1.5" fill="none">
                <path d="M40,90 L32,106 L48,106 Z" fill="var(--ink)" />
                <circle cx="320" cy="106" r="6" fill="var(--bg-panel)" />
              </g>
            </svg>
          </div>
        </div>
      </div>
      <MobileTabbar active="results" />
    </section>
  );
}

window.ResultsView = ResultsView;
