# FEA Pro · Mobile redesign UI kit (scaffolding)

> ⚠️ **This is scaffolding, not the approved Mockup #1.**
> The actual Mobile Dashboard mockup is the **next step** in the redesign pipeline (Claude Design session that follows design-system approval). This folder lays down the tokens, the structural shell (topbar + tabbar + scroll body), and concrete demonstrations of the two most important UX principles — so the team can validate the *direction* before building the high-fidelity screen.

## What's here

| File | What it is |
|---|---|
| `ios-frame.jsx` | iOS 26 device frame starter (drop-in) |
| `MobileTopbar.jsx` | 44pt mobile top bar — logo / title + back / search / menu |
| `MobileTabbar.jsx` | 5-tab bottom bar — Modello · Make · Solve · Risultati · Altro (mirrors `src/components/shell/MobileTabbar.tsx` in repo) |
| `MobileDashboard.jsx` | Scaffold home: hero + stacked hub cards + recent list rows |
| `ElementInspector.jsx` | **Principio #2** — every element ispezionabile in 1 tap, with geometry · materiale completo (E, fy, ν, ρ) · sezione completa (A, Iy, Iz, Wpl) · sollecitazioni *with explicit position* · UR per check |
| `ResultsView.jsx` | **Principio #1** — every diagram (Mz, Vy, deformata) shows numeric peak labels by default: `M_max = 12.45 kNm @ x = 3.00 m`. Never a colored shape without a number. |
| `MIcons.jsx` | Lucide-style inline icons, slightly larger default for mobile |

## What it deliberately does NOT do

- **It does not** replace the Mockup #1 deliverable. Federico's flow is: design system → Mockup #1 (mobile dashboard) → approve → handoff Claude Code. That mockup is owned by the next claude.ai/design session.
- **It does not** prototype navigation, gesture, or transitions. Those are spec'd in `UX_REDESIGN_BRIEF.md` §8 (Spec interazione + Responsive + Accessibilità).
- **It does not** render the Three.js viewport. The "viewport mock" inside `ResultsView` is an SVG placeholder showing what the *diagram overlay* will look like — the real WebGL canvas is in `src/viewport-engine/`.

## How to read this

Open `index.html`. Three iPhone 16 frames (402×874) side-by-side on a dark stage:

1. **Dashboard (scaffold)** — token application + structural tabbar + hub layout. Shows tonality.
2. **Risultati · principio #1** — concrete answer to *"the diagrams have no numbers"* (WhatsApp Paoletto finding #2). Every diagram is annotated with peak value + position.
3. **Inspector · principio #2** — concrete answer to *"click on element shows ambiguous number"* (finding #4). Single-tap surfaces all six categories (geometry · material · section · forces with position · stresses · verifications by code).

## Source of truth

- The brief: `../../uploads/UX_REDESIGN_BRIEF.md` — 7 principles, persona, 13 components
- Project state: `../../uploads/PROJECT_STATE.md`
- Repo: [github.com/fedesanna99/FIA](https://github.com/fedesanna99/FIA) — explore `src/components/shell/MobileTabbar.tsx`, `MobilePanel.tsx`, `MobileMoreMenu.tsx`
- Tokens: `../../colors_and_type.css`
