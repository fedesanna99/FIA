// Mobile bottom tabbar — 5 tabs, mirrors src/components/shell/MobileTabbar.tsx.
function MobileTabbar({ active = "model" }) {
  const tabs = [
    { id: "model",   label: "Modello",   icon: <MIcon.Box /> },
    { id: "make",    label: "Make",      icon: <MIcon.Hammer /> },
    { id: "solve",   label: "Solve",     icon: <MIcon.Zap /> },
    { id: "results", label: "Risultati", icon: <MIcon.Chart /> },
    { id: "more",    label: "Altro",     icon: <MIcon.More /> },
  ];

  return (
    <nav className="mtabbar" aria-label="Navigazione mobile">
      {tabs.map((t) => (
        <button
          key={t.id}
          type="button"
          className={`mtab ${active === t.id ? "active" : ""}`}
          aria-current={active === t.id ? "page" : undefined}
          aria-label={t.label}
        >
          {t.icon}
          <span className="lbl">{t.label}</span>
        </button>
      ))}
    </nav>
  );
}

window.MobileTabbar = MobileTabbar;
