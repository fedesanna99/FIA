// FEA Pro · Nuovo Guscio — App root
// Layout: TopBar / [Rail · Viewport · Panel] / StatusBar.
// Tweaks: workspace · accent · theme · density · panel-width · viewport-personality · soft/sharp · stato.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "workspace": "risultati",
  "accent": "cyan",
  "theme": "light",
  "density": "comfortable",
  "panelWidth": 380,
  "viewport": "neutral",
  "rounding": "soft",
  "trustState": "preliminary",
  "showPalette": false,
  "showSelection": true,
  "showWatermark": true,
  "showDeformed": true,
  "showStress": true,
  "showLoads": true,
  "deformationScale": 200
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply tokens to <html> + <body>
  React.useEffect(() => {
    document.documentElement.dataset.accent = t.accent;
    document.documentElement.dataset.theme = t.theme;
    document.body.className = [
      t.theme === "dark"  ? "theme-dark" : "theme-light",
      t.rounding === "sharp" ? "shell-sharp" : "shell-soft",
      t.density === "compact" ? "shell-density-compact" : "shell-density-comfy",
      `shell-panel-w-${t.panelWidth}`,
      `shell-vp-${t.viewport}`,
    ].join(" ");
  }, [t.accent, t.theme, t.rounding, t.density, t.panelWidth, t.viewport]);

  // Keyboard: ⌘K toggles palette, Esc closes it
  React.useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setTweak("showPalette", !t.showPalette);
      } else if (e.key === "Escape" && t.showPalette) {
        setTweak("showPalette", false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [t.showPalette, setTweak]);

  // Workspace switcher routes both rail click & tweak
  const setWorkspace = (id) => setTweak("workspace", id);

  return (
    <div className="shell">
      <ShellTopBar
        onOpenPalette={() => setTweak("showPalette", true)}
        trustState={t.trustState}
      />
      <div className="shell-mid">
        <ShellRail active={t.workspace} onChange={setWorkspace} />
        <ShellViewport
          display={{
            deformata: t.showDeformed,
            stress: t.showStress,
            carichi: t.showLoads,
          }}
          scale={t.deformationScale}
          showWatermark={t.showWatermark && t.trustState !== "validated"}
          showSelection={t.showSelection}
        />
        <ShellPanel workspace={t.workspace} />
      </div>
      <ShellStatusBar
        selection={t.showSelection ? "Elemento 5 · IPE 300" : "Nessuna selezione"}
      />

      {t.showPalette && (
        <CommandPalette onClose={() => setTweak("showPalette", false)} />
      )}

      <TweaksPanel title="Tweaks · Nuovo Guscio">
        <TweakSection label="Workspace attivo" />
        <TweakSelect label="Workspace" value={t.workspace}
          options={[
            { value: "modello",   label: "1 · Modello" },
            { value: "analisi",   label: "2 · Analisi" },
            { value: "risultati", label: "3 · Risultati (mostrato)" },
            { value: "verifiche", label: "4 · Verifiche" },
            { value: "io",        label: "5 · I/O & Collab" },
          ]}
          onChange={(v) => setTweak("workspace", v)} />

        <TweakSection label="Aspetto" />
        <TweakRadio label="Stile" value={t.rounding}
          options={[
            { value: "soft",  label: "Soft" },
            { value: "sharp", label: "Sharp" },
          ]}
          onChange={(v) => setTweak("rounding", v)} />
        <TweakRadio label="Theme" value={t.theme}
          options={[
            { value: "light", label: "Light" },
            { value: "dark",  label: "Dark" },
          ]}
          onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={t.accent}
          options={[
            { value: "cyan",   color: "#0891B2" },
            { value: "amber",  color: "#B45309" },
            { value: "violet", color: "#534AB7" },
          ]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakRadio label="Densità" value={t.density}
          options={[
            { value: "comfortable", label: "Comfort" },
            { value: "compact",     label: "Compact" },
          ]}
          onChange={(v) => setTweak("density", v)} />
        <TweakRadio label="Panel width" value={t.panelWidth}
          options={[
            { value: 320, label: "320" },
            { value: 380, label: "380" },
            { value: 420, label: "420" },
          ]}
          onChange={(v) => setTweak("panelWidth", v)} />

        <TweakSection label="Viewport" />
        <TweakRadio label="Personality" value={t.viewport}
          options={[
            { value: "neutral", label: "Neutro" },
            { value: "tech",    label: "Tech grid" },
            { value: "dark",    label: "Studio dark" },
          ]}
          onChange={(v) => setTweak("viewport", v)} />
        <TweakToggle label="Deformata" value={t.showDeformed}
          onChange={(v) => setTweak("showDeformed", v)} />
        <TweakToggle label="Stress σ Von Mises" value={t.showStress}
          onChange={(v) => setTweak("showStress", v)} />
        <TweakToggle label="Carichi distribuiti" value={t.showLoads}
          onChange={(v) => setTweak("showLoads", v)} />
        <TweakToggle label="Selezione EL 5" value={t.showSelection}
          onChange={(v) => setTweak("showSelection", v)} />
        <TweakSlider label="Scala deformazione" value={t.deformationScale}
          min={1} max={500} step={1} suffix="×"
          onChange={(v) => setTweak("deformationScale", v)} />

        <TweakSection label="Trust layer" />
        <TweakRadio label="Stato" value={t.trustState}
          options={[
            { value: "preliminary", label: "Prelim" },
            { value: "draft",       label: "Draft" },
            { value: "validated",   label: "Valid" },
          ]}
          onChange={(v) => setTweak("trustState", v)} />
        <TweakToggle label="Watermark viewport" value={t.showWatermark}
          onChange={(v) => setTweak("showWatermark", v)} />

        <TweakSection label="Overlay" />
        <TweakToggle label="Command palette (⌘K)" value={t.showPalette}
          onChange={(v) => setTweak("showPalette", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(<App />);
