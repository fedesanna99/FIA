// FEA Pro · Nuovo Guscio — Shell chrome (TopBar v2, Rail sinistro, Status Bar)
// Caso d'uso: Trave bi-appoggiata UC1, modello risolto, workspace Risultati.
// Riprende il design system Precision v2.0 in modalità Soft (radius 8-16, ombra morbida).

// ───────────────────────────────────────────────────────────────────────
// TopBar v2
// ───────────────────────────────────────────────────────────────────────
function ShellTopBar({ onOpenPalette, runState = "ok", trustState = "preliminary", savedAt = "14:32" }) {
  const trustLabels = {
    preliminary: { txt: "Preliminary", desc: "Risultati indicativi — v2.3.x non raccomandata per progetti reali" },
    draft:       { txt: "Draft",       desc: "Modello in lavorazione — validazione non completata" },
    validated:   { txt: "Validated",   desc: "Risultati verificati — pronti per consegna" },
  };
  const trust = trustLabels[trustState] || trustLabels.preliminary;

  return (
    <header className="shell-topbar">
      <div className="tb-brand">
        <div className="tb-mark">F</div>
        <span className="tb-brand-name">FEA Pro</span>
        <span className="tb-tier">FREE</span>
        <span className="tb-ver">v2.3.7</span>
      </div>

      <button className="tb-model" type="button">
        <span className="tb-model-id">UC1</span>
        Trave bi-appoggiata
        <Icon.ChevD s={12} />
      </button>

      <div className="tb-save">
        <Icon.Check s={10} /> Salvato {savedAt}
      </div>

      <div className="tb-trust" title={trust.desc}>
        {trust.txt}
      </div>

      <div className="tb-spacer" />

      <button className="tb-search" type="button" onClick={onOpenPalette}>
        <Icon.Search s={14} />
        <span>Cerca azioni, modelli, norme…</span>
        <span style={{ flex: 1 }} />
        <kbd>⌘ K</kbd>
      </button>

      <button className="tb-run" type="button">
        <Icon.Play s={12} /> Esegui
        <kbd>F5</kbd>
      </button>

      <div style={{ width: 8 }} />

      <button className="tb-iconbtn" type="button" aria-label="Annulla" title="Annulla (⌘Z)"><Icon.Undo s={15} /></button>
      <button className="tb-iconbtn" type="button" aria-label="Ripeti" title="Ripeti (⌘⇧Z)"><Icon.Redo s={15} /></button>

      <div className="tb-iconbtn-wrap">
        <button className="tb-iconbtn" type="button" aria-label="Notifiche">
          <Icon.Bell s={15} />
          <span className="tb-iconbtn-badge" />
        </button>
      </div>

      <button className="tb-avatar" type="button" aria-label="Account">FS</button>
    </header>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Left Rail — 5 workspace + docs/auto-detect
// ───────────────────────────────────────────────────────────────────────
const WORKSPACES = [
  { id: "modello",   name: "Modello",      icon: "Cube",     kbd: "1", desc: "Costruisci la struttura" },
  { id: "analisi",   name: "Analisi",      icon: "Cog",      kbd: "2", desc: "Scegli e lancia l'analisi" },
  { id: "risultati", name: "Risultati",    icon: "Activity", kbd: "3", desc: "Visualizza e interpreta" },
  { id: "verifiche", name: "Verifiche",    icon: "Check2",   kbd: "4", desc: "EC2 · EC3 · EC5 · EC8 · NTC18" },
  { id: "io",        name: "I/O & Collab", icon: "Shuffle",  kbd: "5", desc: "Import · Export · AI · Compare" },
];

function ShellRail({ active = "risultati", onChange }) {
  return (
    <nav className="shell-rail" aria-label="Workspace switcher">
      {WORKSPACES.map(ws => {
        const I = window.Icon[ws.icon];
        return (
          <button
            key={ws.id}
            type="button"
            className={"rail-btn " + (active === ws.id ? "active" : "")}
            onClick={() => onChange?.(ws.id)}
            aria-label={ws.name}
            aria-current={active === ws.id ? "page" : undefined}
          >
            <I s={20} />
            <span className="rail-kbd">{ws.kbd}</span>
            <span className="rail-tooltip">
              {ws.name}
              <kbd>{ws.kbd}</kbd>
            </span>
          </button>
        );
      })}

      <div className="rail-sep" />

      <button type="button" className="rail-btn" aria-label="Auto-detect">
        <Icon.Bug s={18} />
        <span className="rail-tooltip">Auto-detect <kbd>F3</kbd></span>
      </button>
      <button type="button" className="rail-btn" aria-label="Documentazione">
        <Icon.BookOpen s={18} />
        <span className="rail-tooltip">Docs <kbd>?</kbd></span>
      </button>

      <div className="rail-spacer" />

      <button type="button" className="rail-btn" aria-label="Impostazioni">
        <Icon.Settings s={18} />
        <span className="rail-tooltip">Impostazioni</span>
      </button>
    </nav>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Status Bar (bottom)
// ───────────────────────────────────────────────────────────────────────
function ShellStatusBar({ selection = "Elemento 5", units = "SI · kN, m, MPa", zoom = 100 }) {
  return (
    <footer className="shell-statusbar">
      <div className="sb-item">
        <span className="sb-dot" />
        <span className="sb-v">Online</span>
        <span className="sb-k">· fea-pro.fly.dev</span>
      </div>
      <div className="sb-sep" />
      <div className="sb-item">
        <span className="sb-k">Selezione</span>
        <span className="sb-v">{selection}</span>
      </div>
      <div className="sb-sep" />
      <div className="sb-item">
        <span className="sb-k">Unità</span>
        <span className="sb-v">{units}</span>
      </div>
      <div className="sb-sep" />
      <div className="sb-item">
        <span className="sb-k">Snap</span>
        <span className="sb-v">0.10 m</span>
      </div>

      <div className="sb-spacer" />

      <div className="sb-item">
        <span className="sb-k">Solver</span>
        <span className="sb-dot" />
        <span className="sb-v">Static · 0.84s</span>
      </div>
      <div className="sb-sep" />
      <div className="sb-item">
        <span className="sb-k">Collab</span>
        <span className="sb-v">Solo</span>
      </div>
      <div className="sb-sep" />
      <div className="sb-item">
        <span className="sb-k">Zoom</span>
        <span className="sb-v">{zoom}%</span>
      </div>
      <div className="sb-sep" />
      <div className="sb-item">
        <span className="sb-v">11 nodi · 10 beam · 2 vincoli · 1 carico</span>
      </div>
    </footer>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Beam model SVG — Trave bi-appoggiata UC1, stato risolto.
// Mostra: distrib load q, supports, beam con stress colormap σ_VM,
// deformed shape (scala 200x), nodi numerati, elemento 5 selezionato.
// ───────────────────────────────────────────────────────────────────────
function BeamModelSVG({ selectedElement = 5, showDeformed = true, showStress = true, showLoads = true, scale = 200 }) {
  // Geometry
  const L = 6.0;                 // m
  const nodes = 11;
  const x0 = 90, x1 = 870;       // px
  const yAxis = 240;             // beam y position
  const dx = (x1 - x0) / (nodes - 1);
  const nodeX = i => x0 + i * dx;

  // Deformed: half-sine, max at center
  const deltaMax = 60;           // px (visual representation of 200x deformation scale)
  const def = x => deltaMax * Math.sin(Math.PI * (x - x0) / (x1 - x0));

  // Stress colormap (von Mises): max at center, zero at supports
  // Pseudo-Jet colormap
  const jetColor = (t) => {
    // t in 0..1
    if (t < 0.20) return `rgb(${Math.round(40 + t*120)}, ${Math.round(30 + t*100)}, ${Math.round(160 + t*200)})`;
    if (t < 0.40) return `rgb(${Math.round(40)}, ${Math.round(120 + (t-0.2)*500)}, ${Math.round(220 - (t-0.2)*200)})`;
    if (t < 0.60) return `rgb(${Math.round(40 + (t-0.4)*900)}, ${Math.round(220 - (t-0.4)*200)}, ${Math.round(180 - (t-0.4)*700)})`;
    if (t < 0.80) return `rgb(${Math.round(255)}, ${Math.round(180 - (t-0.6)*500)}, ${Math.round(40 - (t-0.6)*180)})`;
    return `rgb(${Math.round(255 - (t-0.8)*100)}, ${Math.round(80 - (t-0.8)*300)}, ${Math.round(40)})`;
  };
  // Bending moment shape (parabolic) — stress proportional
  const stressAt = x => 4 * (x - x0) * (x1 - x) / Math.pow(x1 - x0, 2);

  const beamThick = 12;

  return (
    <svg className="vp-svg" viewBox="0 0 960 480" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
      <defs>
        {/* Stress gradient along beam */}
        <linearGradient id="beam-stress" x1="0" x2="1" y1="0" y2="0">
          {[0, 0.1, 0.25, 0.5, 0.75, 0.9, 1].map(t => (
            <stop key={t} offset={t} stopColor={jetColor(stressAt(x0 + t*(x1-x0)))} />
          ))}
        </linearGradient>
        {/* Highlight gradient for selected element */}
        <linearGradient id="el-selected" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="rgba(8,145,178,0.35)" />
          <stop offset="1" stopColor="rgba(8,145,178,0.05)" />
        </linearGradient>
        {/* Load arrow */}
        <marker id="arrow-down" viewBox="0 0 12 12" refX="6" refY="11" markerWidth="8" markerHeight="8" orient="auto">
          <path d="M2,1 L6,11 L10,1" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </marker>
      </defs>

      {/* Section line / span label */}
      <g stroke="currentColor" strokeOpacity="0.18" strokeDasharray="3 4" strokeWidth="1">
        <line x1={x0} y1={20} x2={x0} y2={460} />
        <line x1={x1} y1={20} x2={x1} y2={460} />
      </g>

      {/* Span dimension at top */}
      {showLoads && (
        <g fontFamily="JetBrains Mono, monospace" fontSize="11" fill="currentColor" fillOpacity="0.7" textAnchor="middle">
          <line x1={x0} y1={50} x2={x1} y2={50} stroke="currentColor" strokeOpacity="0.4" strokeWidth="1" />
          <line x1={x0} y1={45} x2={x0} y2={55} stroke="currentColor" strokeOpacity="0.4" strokeWidth="1" />
          <line x1={x1} y1={45} x2={x1} y2={55} stroke="currentColor" strokeOpacity="0.4" strokeWidth="1" />
          <rect x={(x0+x1)/2 - 30} y={42} width="60" height="16" fill="var(--bg-viewport)" />
          <text x={(x0+x1)/2} y={54} fontWeight="600">L = 6.00 m</text>
        </g>
      )}

      {/* Distributed load q = 10 kN/m */}
      {showLoads && (
        <g color="var(--coral)">
          {/* Top horizontal line */}
          <line x1={x0} y1={90} x2={x1} y2={90} stroke="currentColor" strokeWidth="2" />
          {/* Arrows */}
          {Array.from({ length: 13 }).map((_, i) => {
            const x = x0 + (i+0.5) * (x1-x0) / 13;
            return <line key={i} x1={x} y1={92} x2={x} y2={yAxis - beamThick/2 - 2}
              stroke="currentColor" strokeWidth="1.4" strokeOpacity="0.85"
              markerEnd="url(#arrow-down)" />;
          })}
          <rect x={x0 + 8} y={68} width="118" height="20" fill="var(--bg-viewport)" />
          <text x={x0 + 12} y={82} fontFamily="JetBrains Mono, monospace" fontSize="12" fontWeight="700" fill="currentColor">
            q = 10.0 kN/m
          </text>
        </g>
      )}

      {/* Original (undeformed) beam — ghost outline */}
      {showDeformed && (
        <line x1={x0} y1={yAxis} x2={x1} y2={yAxis}
          stroke="currentColor" strokeOpacity="0.15" strokeWidth="2" strokeDasharray="2 3" />
      )}

      {/* Stress-colored beam (deformed) */}
      {(() => {
        // Sample the deformed shape as polyline, color by stress
        const samples = 24;
        const segs = [];
        for (let i = 0; i < samples; i++) {
          const t0 = i / samples, t1 = (i+1) / samples;
          const xa = x0 + t0*(x1-x0), xb = x0 + t1*(x1-x0);
          const ya = yAxis + (showDeformed ? def(xa) : 0);
          const yb = yAxis + (showDeformed ? def(xb) : 0);
          const tm = (t0+t1)/2;
          const stress = stressAt(x0 + tm*(x1-x0));
          segs.push({ xa, ya, xb, yb, color: showStress ? jetColor(stress) : "var(--ink)" });
        }
        return segs.map((s, i) => (
          <line key={i} x1={s.xa} y1={s.ya} x2={s.xb} y2={s.yb}
            stroke={s.color} strokeWidth={beamThick} strokeLinecap="butt" />
        ));
      })()}

      {/* Selected element halo (element 5 is between nodes 5 and 6, centered around x=(nodeX(4)+nodeX(5))/2 ≈ mid span) */}
      {selectedElement && (() => {
        const i = selectedElement - 1;
        const xa = nodeX(i), xb = nodeX(i+1);
        const xm = (xa+xb)/2;
        const ym = yAxis + (showDeformed ? def(xm) : 0);
        return (
          <g>
            <rect x={xa - 4} y={yAxis - 32} width={xb - xa + 8} height={64} rx="6" ry="6"
              fill="rgba(8,145,178,0.10)" stroke="var(--accent)" strokeWidth="1.5" strokeDasharray="4 3" />
            {/* selection label */}
            <g transform={`translate(${xm}, ${ym - 36})`}>
              <rect x="-32" y="-12" width="64" height="20" rx="4" ry="4"
                fill="var(--bg-panel)" stroke="var(--accent)" strokeWidth="1" />
              <text x="0" y="2" textAnchor="middle"
                fontFamily="JetBrains Mono, monospace" fontSize="11" fontWeight="700" fill="var(--accent)">
                EL 5
              </text>
            </g>
          </g>
        );
      })()}

      {/* Nodes */}
      {Array.from({ length: nodes }).map((_, i) => {
        const x = nodeX(i);
        const y = yAxis + (showDeformed ? def(x) : 0);
        const isSupport = i === 0 || i === nodes - 1;
        const isSelected = selectedElement && (i === selectedElement - 1 || i === selectedElement);
        return (
          <g key={i}>
            <circle cx={x} cy={y} r={isSupport ? 5 : 3.5}
              fill={isSelected ? "var(--accent)" : "var(--bg-panel)"}
              stroke={isSelected ? "var(--accent)" : "var(--ink)"}
              strokeWidth="1.5" />
            {/* node id (only some) */}
            {(isSupport || i === 5) && (
              <text x={x} y={y + 28} textAnchor="middle"
                fontFamily="JetBrains Mono, monospace" fontSize="9" fill="currentColor" fillOpacity="0.55">
                N{i+1}
              </text>
            )}
          </g>
        );
      })}

      {/* Left support — cerniera (triangle) */}
      <g transform={`translate(${x0}, ${yAxis + beamThick/2 + 4})`} color="var(--ink-muted)">
        <polygon points="0,0 -12,18 12,18" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <line x1="-16" y1="22" x2="16" y2="22" stroke="currentColor" strokeWidth="1.5" />
        {/* hatching */}
        {[-12, -6, 0, 6].map(dx => (
          <line key={dx} x1={dx} y1="22" x2={dx-4} y2="28" stroke="currentColor" strokeWidth="1" />
        ))}
        <text x="0" y="44" textAnchor="middle"
          fontFamily="JetBrains Mono, monospace" fontSize="10" fontWeight="600" fill="currentColor">
          CERNIERA
        </text>
      </g>

      {/* Right support — carrello (triangle + roller) */}
      <g transform={`translate(${x1}, ${yAxis + beamThick/2 + 4})`} color="var(--ink-muted)">
        <polygon points="0,0 -12,14 12,14" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="-6" cy="19" r="3" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="6"  cy="19" r="3" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <line x1="-16" y1="24" x2="16" y2="24" stroke="currentColor" strokeWidth="1.5" />
        {[-12, -6, 0, 6].map(dx => (
          <line key={dx} x1={dx} y1="24" x2={dx-4} y2="30" stroke="currentColor" strokeWidth="1" />
        ))}
        <text x="0" y="44" textAnchor="middle"
          fontFamily="JetBrains Mono, monospace" fontSize="10" fontWeight="600" fill="currentColor">
          CARRELLO
        </text>
      </g>

      {/* Max deflection annotation */}
      {showDeformed && (
        <g color="var(--accent)">
          <line x1={(x0+x1)/2} y1={yAxis - 1} x2={(x0+x1)/2} y2={yAxis + deltaMax + 4}
            stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" />
          <text x={(x0+x1)/2 + 8} y={yAxis + deltaMax - 4}
            fontFamily="JetBrains Mono, monospace" fontSize="11" fontWeight="700" fill="currentColor">
            δ = 9.61 mm
          </text>
          <text x={(x0+x1)/2 + 8} y={yAxis + deltaMax + 10}
            fontFamily="JetBrains Mono, monospace" fontSize="9" fill="currentColor" fillOpacity="0.7">
            @ x = 3.00 m
          </text>
        </g>
      )}

      {/* Section badge — IPE 300 / S355 */}
      <g transform={`translate(40, 410)`}>
        <rect x="0" y="0" width="200" height="50" rx="8" ry="8"
          fill="var(--bg-panel)" stroke="var(--border)" strokeWidth="1" />
        <text x="14" y="20" fontFamily="JetBrains Mono, monospace" fontSize="10" fontWeight="700"
          letterSpacing="0.10em" fill="currentColor" fillOpacity="0.55">SEZIONE · MATERIALE</text>
        <text x="14" y="40" fontFamily="JetBrains Mono, monospace" fontSize="13" fontWeight="700" fill="currentColor">
          IPE 300 · S355 (E=210 GPa)
        </text>
      </g>
    </svg>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Viewport area — host of model SVG + HUDs
// ───────────────────────────────────────────────────────────────────────
function ShellViewport({ display = {}, scale = 200, viewMode = "perspective", showWatermark = true, showSelection = true }) {
  return (
    <section className="shell-viewport" aria-label="Viewport 3D">
      <div className="vp-grid" />
      <div className="vp-grid-major" />

      <div className="vp-canvas">
        <BeamModelSVG
          showDeformed={display.deformata !== false}
          showStress={display.stress !== false}
          showLoads={display.carichi !== false}
          selectedElement={showSelection ? 5 : null}
          scale={scale}
        />
      </div>

      {showWatermark && (
        <div className="vp-watermark">
          <div className="vp-watermark-text">PRELIMINARY · PRELIMINARY · PRELIMINARY</div>
        </div>
      )}

      {/* Selection breadcrumb */}
      {showSelection && (
        <div className="vp-selection">
          <span className="vp-sel-tag">EL 5</span>
          <span>Beam · IPE 300 · S355</span>
          <span className="vp-sel-meta">N₅ → N₆ · L = 0.60 m</span>
          <button type="button" className="tb-iconbtn" style={{ marginLeft: 4, width: 22, height: 22 }} aria-label="Deseleziona">
            <Icon.X s={12} />
          </button>
        </div>
      )}

      {/* HUD — colormap legend */}
      <div className="vp-hud vp-legend">
        <div className="vp-hud-row" style={{ justifyContent: "space-between" }}>
          <span className="vp-hud-title">σ Von Mises</span>
          <button className="vp-ctrl-btn" style={{ height: 20, padding: "0 5px" }} aria-label="Cambia colormap">
            <Icon.Sliders s={11} />
          </button>
        </div>
        <div className="vp-legend-bar" />
        <div className="vp-legend-axis">
          <span>0.0</span>
          <span>44.6</span>
          <span>89.1</span>
          <span>133</span>
          <span>178</span>
        </div>
        <div className="vp-legend-unit">MPa · fyk = 355 · UR_σ = 0.50</div>
      </div>

      {/* HUD — view controls */}
      <div className="vp-hud vp-controls">
        <button className={"vp-ctrl-btn " + (viewMode === "perspective" ? "on" : "")} aria-label="Prospettica">
          <Icon.Cube s={12} /> Persp
        </button>
        <button className={"vp-ctrl-btn " + (viewMode === "ortho" ? "on" : "")} aria-label="Ortografica">
          <Icon.Grid s={12} /> Ortho
        </button>
        <span style={{ width: 1, background: "var(--border)", margin: "4px 2px" }} />
        <button className="vp-ctrl-btn on" aria-label="Solid"><Icon.Layers2 s={12} /> Solid</button>
        <button className="vp-ctrl-btn" aria-label="Wireframe"><Icon.Beam s={12} /></button>
        <button className="vp-ctrl-btn" aria-label="Toggle grid"><Icon.Grid s={12} /></button>
      </div>

      {/* HUD — gizmo (axes) */}
      <div className="vp-hud vp-gizmo">
        <svg width="76" height="76" viewBox="0 0 80 80">
          <g transform="translate(40 40)">
            {/* Z axis (up) */}
            <line x1="0" y1="0" x2="0" y2="-26" stroke="#3DA9FC" strokeWidth="2" strokeLinecap="round" />
            <circle cx="0" cy="-30" r="8" fill="#3DA9FC" />
            <text x="0" y="-27" fontFamily="JetBrains Mono, monospace" fontSize="10" fontWeight="700" fill="#fff" textAnchor="middle">Z</text>
            {/* X axis */}
            <line x1="0" y1="0" x2="22" y2="13" stroke="#EF4444" strokeWidth="2" strokeLinecap="round" />
            <circle cx="26" cy="15" r="8" fill="#EF4444" />
            <text x="26" y="18" fontFamily="JetBrains Mono, monospace" fontSize="10" fontWeight="700" fill="#fff" textAnchor="middle">X</text>
            {/* Y axis */}
            <line x1="0" y1="0" x2="-22" y2="13" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" />
            <circle cx="-26" cy="15" r="8" fill="#22C55E" />
            <text x="-26" y="18" fontFamily="JetBrains Mono, monospace" fontSize="10" fontWeight="700" fill="#fff" textAnchor="middle">Y</text>
            {/* origin */}
            <circle cx="0" cy="0" r="2.5" fill="var(--ink)" />
          </g>
        </svg>
      </div>

      {/* HUD — scale ruler */}
      <div className="vp-hud vp-ruler">
        <span>1 m</span>
        <span className="vp-ruler-bar" />
        <span>Zoom 100%</span>
      </div>

      {/* HUD — zoom controls (center bottom) */}
      <div className="vp-hud vp-zoom">
        <button aria-label="Pan"><Icon.Move s={14} /></button>
        <span className="vp-zoom-sep" />
        <button aria-label="Zoom out"><Icon.ZoomOut s={14} /></button>
        <span className="vp-zoom-val">100%</span>
        <button aria-label="Zoom in"><Icon.ZoomIn s={14} /></button>
        <span className="vp-zoom-sep" />
        <button aria-label="Centra vista" title="Fit (F)"><Icon.Crosshair s={14} /></button>
        <span className="vp-zoom-sep" />
        <button aria-label="Schermo intero"><Icon.Maximize s={14} /></button>
      </div>
    </section>
  );
}

Object.assign(window, { ShellTopBar, ShellRail, ShellStatusBar, ShellViewport, BeamModelSVG, WORKSPACES });
