// QuickAction — 4-up grid card. icon + name + sub + tag/shortcut foot.
function QuickAction({ icon, name, sub, tag, shortcut, onClick }) {
  return (
    <button type="button" className="qcard" onClick={onClick}>
      <span className="icon">{icon}</span>
      <div>
        <div className="name">{name}</div>
        <div className="sub">{sub}</div>
      </div>
      <div className="foot">
        <span>{tag}</span>
        <span>{shortcut}</span>
      </div>
    </button>
  );
}

window.QuickAction = QuickAction;
