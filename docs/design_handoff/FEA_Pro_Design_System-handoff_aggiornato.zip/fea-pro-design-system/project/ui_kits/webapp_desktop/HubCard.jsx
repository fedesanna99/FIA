// HubCard — the dual hero card for Studio Pro / Percorsi.
function HubCard({ axis = "studio", title, subtitle, bullets = [], cta, primary = false }) {
  const axisLabel = axis === "studio" ? "/ Studio Pro" : "/ Percorsi";
  return (
    <article className="hub" data-axis={axis}>
      <span className={`hub-tag ${axis}`}>{axisLabel}</span>
      <h2 dangerouslySetInnerHTML={{ __html: title }} />
      <p>{subtitle}</p>
      {bullets.length > 0 && (
        <ul>
          {bullets.map((b, i) => <li key={i}>{b}</li>)}
        </ul>
      )}
      <div className="cta">
        <button type="button" className={primary ? "btn btn-primary" : "btn btn-outline"}>
          {cta} <Icon.ArrowR />
        </button>
      </div>
    </article>
  );
}

window.HubCard = HubCard;
