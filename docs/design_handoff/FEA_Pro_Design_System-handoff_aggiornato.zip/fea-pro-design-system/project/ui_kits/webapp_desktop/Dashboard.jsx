// Dashboard wrapper — variant + style + theme switcher.
//
// THREE INDEPENDENT KNOBS:
//   variant : A · Centrato | B · Continua | D · Essenziale  (layout structure)
//   style   : precision    | soft                            (rounding/font/shadows)
//   theme   : light        | dark                            (color tokens)
//
// Default = D · Soft · Dark (the most recent direction the user reacted to).
// All combinations preserved — nothing is lost. Mix freely.
function Dashboard() {
  const [variant, setVariant] = React.useState(() => {
    try { return localStorage.getItem("fea_dash_variant") || "D"; }
    catch { return "D"; }
  });
  const [style, setStyle] = React.useState(() => {
    try { return localStorage.getItem("fea_dash_style") || "soft"; }
    catch { return "soft"; }
  });
  const [theme, setTheme] = React.useState(() => {
    try { return localStorage.getItem("fea_dash_theme") || "dark"; }
    catch { return "dark"; }
  });

  // Apply style (rounding / font / shadows)
  React.useEffect(() => {
    document.body.classList.toggle("theme-soft", style === "soft");
    try { localStorage.setItem("fea_dash_style", style); } catch {}
  }, [style]);

  // Apply theme (light / dark color tokens) on both root attr (Precision)
  // and body class (Soft overrides).
  React.useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.body.classList.toggle("theme-dark", theme === "dark");
    document.body.classList.toggle("theme-light", theme === "light");
    try { localStorage.setItem("fea_dash_theme", theme); } catch {}
  }, [theme]);

  const changeVariant = (v) => {
    setVariant(v);
    try { localStorage.setItem("fea_dash_variant", v); } catch {}
  };
  const toggleTheme = () => setTheme(t => t === "dark" ? "light" : "dark");
  const toggleStyle = () => setStyle(s => s === "soft" ? "precision" : "soft");

  const variants = [
    { id: "A", name: "Centrato",   component: window.DashboardA, sub: "candidata" },
    { id: "B", name: "Continua",   component: window.DashboardB, sub: "in test" },
    { id: "D", name: "Essenziale", component: window.DashboardD, sub: "minimal" },
  ];
  const Current = variants.find(v => v.id === variant)?.component || window.DashboardA;

  return (
    <>
      <Current />

      <div className="layout-switcher" role="toolbar" aria-label="Switcher">

        {/* Layout group */}
        <span className="ttl">Layout</span>
        {variants.map(v => (
          <button
            key={v.id}
            type="button"
            role="tab"
            aria-selected={variant === v.id}
            className={variant === v.id ? "active" : ""}
            onClick={() => changeVariant(v.id)}
            title={v.sub}
          >
            <span className="id">{v.id}</span>
            {v.name}
            <span className="sub">{v.sub}</span>
          </button>
        ))}

        {/* Style group */}
        <span className="ttl ttl-sep">Stile</span>
        <button
          type="button"
          className={`style-pill ${style === "precision" ? "active" : ""}`}
          onClick={toggleStyle}
          title={style === "soft" ? "Passa a Precision (spigoloso, Inter, hairline)" : "Passa a Soft (rotondo, Plus Jakarta, ombre)"}
        >
          {style === "soft" ? "Soft" : "Precision"}
        </button>

        {/* Theme toggle */}
        <button
          type="button"
          className="theme-toggle"
          onClick={toggleTheme}
          title={theme === "dark" ? "Passa a chiaro" : "Passa a scuro"}
          aria-label="Toggle tema"
        >
          {theme === "dark" ? (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
          ) : (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
          )}
        </button>

      </div>
    </>
  );
}

window.Dashboard = Dashboard;
