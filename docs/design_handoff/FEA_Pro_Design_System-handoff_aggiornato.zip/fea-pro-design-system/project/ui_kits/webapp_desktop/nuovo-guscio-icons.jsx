// FEA Pro · Nuovo Guscio — icone aggiuntive (lucide-style)
// stroke 1.8, currentColor, never filled.
// Estende `Icon` definito in Icons.jsx.
(function() {
  const stroke = (s) => ({
    width: s, height: s, viewBox: "0 0 24 24",
    fill: "none", stroke: "currentColor",
    strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round"
  });
  const filled = (s) => ({
    width: s, height: s, viewBox: "0 0 24 24", fill: "currentColor"
  });

  const ExtraIcon = {
    // Workspace rail icons
    Cube:     ({ s = 18 }) => <svg {...stroke(s)}><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16zM3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/></svg>,
    Cog:      ({ s = 18 }) => <svg {...stroke(s)}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
    Activity: ({ s = 18 }) => <svg {...stroke(s)}><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>,
    Check2:   ({ s = 18 }) => <svg {...stroke(s)}><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>,
    Shuffle:  ({ s = 18 }) => <svg {...stroke(s)}><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/></svg>,
    Bug:      ({ s = 18 }) => <svg {...stroke(s)}><rect x="8" y="6" width="8" height="14" rx="4"/><path d="M19 7l-3 2M5 7l3 2M19 13h-3M5 13h3M19 19l-3-2M5 19l3-2M12 2v4M9 6l3-2 3 2"/></svg>,
    HelpCircle: ({ s = 18 }) => <svg {...stroke(s)}><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01"/></svg>,
    Settings: ({ s = 18 }) => <svg {...stroke(s)}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82V9a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9z"/></svg>,
    BookOpen: ({ s = 18 }) => <svg {...stroke(s)}><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2zM22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>,

    // Viewport HUD
    Eye:      ({ s = 14 }) => <svg {...stroke(s)}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
    EyeOff:   ({ s = 14 }) => <svg {...stroke(s)}><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24M1 1l22 22"/></svg>,
    Maximize: ({ s = 14 }) => <svg {...stroke(s)}><path d="M3 7V3h4M21 7V3h-4M3 17v4h4M21 17v4h-4"/></svg>,
    Grid:     ({ s = 14 }) => <svg {...stroke(s)}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>,
    Layers2:  ({ s = 14 }) => <svg {...stroke(s)}><path d="M12 2L2 8l10 6 10-6-10-6zM2 14l10 6 10-6"/></svg>,
    Compass:  ({ s = 14 }) => <svg {...stroke(s)}><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>,
    Move:     ({ s = 14 }) => <svg {...stroke(s)}><path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/></svg>,
    ZoomIn:   ({ s = 14 }) => <svg {...stroke(s)}><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35M11 8v6M8 11h6"/></svg>,
    ZoomOut:  ({ s = 14 }) => <svg {...stroke(s)}><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35M8 11h6"/></svg>,
    Crosshair: ({ s = 14 }) => <svg {...stroke(s)}><circle cx="12" cy="12" r="10"/><path d="M22 12h-4M6 12H2M12 6V2M12 22v-4"/></svg>,

    // Panel actions
    Sliders:  ({ s = 14 }) => <svg {...stroke(s)}><path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/></svg>,
    Camera:   ({ s = 14 }) => <svg {...stroke(s)}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>,
    Download: ({ s = 14 }) => <svg {...stroke(s)}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>,
    Save:     ({ s = 14 }) => <svg {...stroke(s)}><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2zM17 21v-8H7v8M7 3v5h8"/></svg>,
    Filter:   ({ s = 14 }) => <svg {...stroke(s)}><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>,

    // Diagrams / inspector
    Beam:     ({ s = 14 }) => <svg {...stroke(s)}><path d="M2 8h20M2 16h20M6 8v8M18 8v8M10 8v8M14 8v8"/></svg>,
    Wave:     ({ s = 14 }) => <svg {...stroke(s)}><path d="M2 12c2-4 4-4 6 0s4 4 6 0 4-4 6 0"/></svg>,
    Chart:    ({ s = 14 }) => <svg {...stroke(s)}><path d="M3 3v18h18M7 15l3-3 4 4 5-7"/></svg>,
    Triangle: ({ s = 14 }) => <svg {...stroke(s)}><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>,
    Info:     ({ s = 14 }) => <svg {...stroke(s)}><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>,
    X:        ({ s = 14 }) => <svg {...stroke(s)}><path d="M18 6L6 18M6 6l12 12"/></svg>,
    Search:   ({ s = 14 }) => <svg {...stroke(s)}><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>,
    ArrowUp:  ({ s = 12 }) => <svg {...stroke(s)}><path d="M12 19V5M5 12l7-7 7 7"/></svg>,
    ArrowDown:({ s = 12 }) => <svg {...stroke(s)}><path d="M12 5v14M19 12l-7 7-7-7"/></svg>,
    Sparkles: ({ s = 14 }) => <svg {...stroke(s)}><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>,

    // Status bar
    DotOnline: ({ s = 8 }) => <svg width={s} height={s} viewBox="0 0 8 8"><circle cx="4" cy="4" r="3" fill="currentColor"/></svg>,
    User:     ({ s = 12 }) => <svg {...stroke(s)}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
    Ruler:    ({ s = 12 }) => <svg {...stroke(s)}><path d="M21.3 8.7L15.3 2.7a1 1 0 0 0-1.4 0L2.7 13.9a1 1 0 0 0 0 1.4l6 6a1 1 0 0 0 1.4 0l11.2-11.2a1 1 0 0 0 0-1.4zM7.5 11.5l2 2M11 8l2 2M14.5 4.5l2 2"/></svg>,
  };

  // merge into window.Icon (shallow)
  window.Icon = Object.assign({}, window.Icon || {}, ExtraIcon);
})();
