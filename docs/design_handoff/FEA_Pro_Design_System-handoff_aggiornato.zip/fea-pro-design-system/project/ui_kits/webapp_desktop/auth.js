/* Auth state switcher — vanilla, no framework */
(function() {
  const tabs  = document.querySelectorAll(".state-tab");
  const cards = document.querySelectorAll(".auth-card");

  function setState(state) {
    tabs.forEach(t  => t.classList.toggle("is-active", t.dataset.state === state));
    cards.forEach(c => c.hidden = (c.dataset.state !== state));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  tabs.forEach(t => t.addEventListener("click", () => setState(t.dataset.state)));

  // Inline state links (e.g. "Crea uno gratuito" goes to signup)
  document.querySelectorAll("[data-go]").forEach(el => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      setState(el.dataset.go);
    });
  });

  // Show-password toggle
  document.querySelectorAll(".field-trail[aria-label='Mostra password']").forEach(btn => {
    btn.addEventListener("click", () => {
      const input = btn.parentElement.querySelector("input");
      if (!input) return;
      input.type = input.type === "password" ? "text" : "password";
    });
  });

  // OTP auto-advance
  const otpInputs = document.querySelectorAll(".otp-cells input");
  otpInputs.forEach((input, i) => {
    input.addEventListener("input", () => {
      if (input.value.length === 1 && i < otpInputs.length - 1) {
        otpInputs[i + 1].focus();
      }
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "Backspace" && !input.value && i > 0) otpInputs[i - 1].focus();
    });
  });
})();
