// TopBar — h-12, Precision direction. Mirrors fedesanna99/FIA · src/components/shell/TopBar.tsx
function TopBar({ modelName = "Trave bi-appoggiata UC1", tier = "FREE", savedAt = "14:32", onRun }) {
  return (
    <header className="topbar" role="banner">
      <div className="brand-block">
        <div className="brand-mark"><span>F</span></div>
        <span className="brand-name">FEA Pro</span>
        <span className="brand-tier">{tier}</span>
        <span className="brand-ver">v2.3.7</span>
      </div>

      <button className="model-menu" type="button" aria-label="Cambia modello">
        {modelName}
        <Icon.ChevD />
      </button>

      <button className="icon-btn" type="button" aria-label="Modifica modello"><Icon.Pencil /></button>

      {savedAt && (
        <div className="save-chip" aria-label="Stato salvataggio">
          <Icon.Check s={10} />
          Salvato {savedAt}
        </div>
      )}

      <div style={{ marginLeft: 4 }}>
        <button className="btn btn-run" type="button" onClick={onRun}>
          <Icon.Play /> Esegui
        </button>
      </div>

      <div className="spacer" />

      <div className="search-bar">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
        <span>Cerca azioni, modelli, norme…</span>
        <span style={{ flex: 1 }} />
        <kbd>⌘ K</kbd>
      </div>

      <button className="icon-btn" type="button" aria-label="Annulla"><Icon.Undo /></button>
      <button className="icon-btn" type="button" aria-label="Ripeti"><Icon.Redo /></button>
      <button className="icon-btn" type="button" aria-label="Notifiche"><Icon.Bell /></button>

      <div style={{ width: 28, height: 28, background: "var(--bg-hover)", border: "1px solid var(--border)", display: "grid", placeItems: "center", fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--ink-muted)" }}>FS</div>
    </header>
  );
}

window.TopBar = TopBar;
