// Dashboard D — "Essenziale" — same Precision DNA, ruthlessly cut.
// Rule: each card has ONE message. No bullets, no metas, no paragraphs.
// What stays: hero, two hubs, recents, credits. What goes: everything else.
function DashboardD() {
  const recent = [
    { name: "Telaio portale 2D",        is3d: false, status: "run" },
    { name: "Trave bi-appoggiata UC1",  is3d: false, status: "ok" },
    { name: "Reticolo 3D · Capannone",  is3d: true,  status: "ok" },
    { name: "Piastra Q4 2×2 m",         is3d: false, status: "draft" },
  ];

  return (
    <main className="dash dash-d" data-screen-label="Dashboard · Essenziale">
      <div className="dash-main">

        <section className="hero hero-d" aria-label="Hero">
          <span className="hero-eyebrow">
            <span className="dot" />
            4 modelli
          </span>
          <h1>Inizia un'analisi.</h1>
        </section>

        <section className="hubs hubs-d" aria-label="Hub di lavoro">
          <HubCard
            axis="studio"
            primary
            title="Studio Pro"
            subtitle="Modalità expert."
            bullets={[]}
            cta="Apri"
          />
          <HubCard
            axis="percorsi"
            title="Percorsi"
            subtitle="Guidato."
            bullets={[]}
            cta="Apri"
          />
        </section>

        <section aria-label="Modelli recenti">
          <div className="sect-head">
            <h2>Recenti</h2>
            <a href="#">Tutti →</a>
          </div>
          <div className="pgrid">
            {recent.map((m, i) => <ProjectCard key={i} compact {...m} />)}
          </div>
        </section>
      </div>

      <aside className="dash-side" aria-label="Sidebar">
        <CreditsWidget used={42} cap={100} tier="FREE" />
      </aside>
    </main>
  );
}

window.DashboardD = DashboardD;
