// FEA Pro · Nuovo Guscio — Command Palette overlay (⌘K)
// Discoverability: TUTTE le 62 route raggiungibili da qui.
// AI Copilot integrato (linea ai-row) → ⌘K diventa anche entry-point AI.

function CommandPalette({ query = "", onClose }) {
  const items = [
    {
      group: "Suggerito ora",
      rows: [
        { id: "ai-ask", icon: "Sparkles", name: 'Chiedi al Copilot: "Spiega come ridurre l\'UR di EL 5"',
          sub: "AI · gemini-2.5-flash · usa contesto modello attivo", kbd: "↵", ai: true },
        { id: "open-report", icon: "Download", name: "Esporta report PDF",
          sub: "reportlab · 7 sezioni · include statica + EC3", kbd: "⌘ P" },
      ],
    },
    {
      group: "Workspace",
      rows: [
        { id: "ws-modello",   icon: "Cube",     name: "Vai a Modello",      sub: "workspace · costruisci struttura", kbd: "1" },
        { id: "ws-analisi",   icon: "Cog",      name: "Vai a Analisi",      sub: "workspace · run solver", kbd: "2" },
        { id: "ws-risultati", icon: "Activity", name: "Vai a Risultati",    sub: "workspace · viewer + diagrammi · attivo", kbd: "3", active: true },
        { id: "ws-verifiche", icon: "Check2",   name: "Vai a Verifiche",    sub: "workspace · EC2 EC3 EC5 EC8 NTC18", kbd: "4" },
        { id: "ws-io",        icon: "Shuffle",  name: "Vai a I/O & Collab", sub: "workspace · import/export · AI · compare", kbd: "5" },
      ],
    },
    {
      group: "Analisi",
      rows: [
        { id: "run-static",   icon: "Play",  name: "Esegui statica",            sub: "K u = F · ultima 0.84s", kbd: "F5" },
        { id: "run-modal",    icon: "Wave",  name: "Esegui modale",             sub: "ARPACK · 6 modi · ~1.2s atteso" },
        { id: "run-buckling", icon: "Layers",name: "Esegui buckling lineare",   sub: "K φ = λ K_G φ" },
        { id: "run-pushover", icon: "Sparkles", name: "Esegui push-over",       sub: "non-lineare incrementale — NEW v2.4" },
      ],
    },
    {
      group: "Verifiche",
      rows: [
        { id: "verify-ec3", icon: "Check2", name: "Verifica EC3 · acciaio",    sub: "resistenza + buckling + LTB · UR_max 0.24" },
        { id: "verify-ec2", icon: "Check2", name: "Verifica EC2 · CA",         sub: "flessione + taglio · NEW v2.4" },
        { id: "verify-ec8", icon: "Wave",   name: "Spettro elastico EC8",      sub: "T_B/T_C/T_D · q · zone IT" },
      ],
    },
    {
      group: "Modello",
      rows: [
        { id: "mesh-line", icon: "Beam", name: "Mesh lineare…",  sub: "line + n_div · beam2d/3d/truss" },
        { id: "mesh-tri",  icon: "Triangle", name: "Mesh triangolare…", sub: "tri T3 · plane-stress" },
        { id: "mesh-param", icon: "Sparkles", name: "Mesh parametrica…", sub: "L · T · cerchio · anello — NEW" },
        { id: "edit-load", icon: "ArrowDown", name: "Modifica carico distribuito q",
          sub: "q = 10.0 kN/m → cambia valore o direzione" },
      ],
    },
    {
      group: "Sistema",
      rows: [
        { id: "cmd-undo",   icon: "Undo",   name: "Annulla ultima mutation",  sub: "modelStore · cerniera_destra_changed", kbd: "⌘ Z" },
        { id: "cmd-help",   icon: "BookOpen", name: "Apri Docs FEA Pro",       sub: "guida utente IT · troubleshooting · glossario", kbd: "?" },
        { id: "cmd-detect", icon: "Bug",    name: "Esegui auto-detect",       sub: "5 detector: duplicate · coincident · orphan · …", kbd: "F3" },
      ],
    },
  ];

  return (
    <div className="cmd-backdrop" onClick={onClose}>
      <div className="cmd-modal" onClick={(e) => e.stopPropagation()}>
        <div className="cmd-search">
          <span className="cmd-search-icon"><Icon.Search s={18} /></span>
          <input
            type="text"
            placeholder="Cerca: workspace, analisi, verifica, esporta, oppure chiedi all'AI…"
            defaultValue={query}
            autoFocus
          />
          <span className="cmd-esc">esc</span>
        </div>
        <div className="cmd-list">
          {items.map((group, gi) => (
            <React.Fragment key={gi}>
              <div className="cmd-group-head">{group.group}</div>
              {group.rows.map((row, ri) => {
                const I = window.Icon[row.icon] || window.Icon.Play;
                return (
                  <button
                    key={row.id}
                    type="button"
                    className={"cmd-item " + (row.active ? "active" : "")}
                  >
                    <span className="cmd-item-icon" style={row.ai ? {
                      background: "linear-gradient(135deg, rgba(var(--accent-rgb), 0.20), rgba(var(--accent-rgb), 0.05))",
                      borderColor: "rgba(var(--accent-rgb), 0.40)",
                      color: "var(--accent)"
                    } : null}>
                      <I s={13} />
                    </span>
                    <div>
                      <div className="cmd-item-name">{row.name}</div>
                      <div className="cmd-item-sub">{row.sub}</div>
                    </div>
                    {row.kbd && <span className="cmd-item-kbd">{row.kbd}</span>}
                  </button>
                );
              })}
            </React.Fragment>
          ))}
        </div>
        <div className="cmd-foot">
          <span><kbd>↑↓</kbd> navigazione</span>
          <span><kbd>↵</kbd> esegui</span>
          <span><kbd>⌘ ↵</kbd> esegui in nuova tab</span>
          <span className="cmd-ai">
            <Icon.Sparkles s={12} /> Inizia con "?" per parlare al Copilot
          </span>
        </div>
      </div>
    </div>
  );
}

window.CommandPalette = CommandPalette;
