// Dashboard A — "Centrato" — top-down hierarchy: hero → 2 hubs → quick → recent → sidebar.
// The classic informational dashboard. Best for users who haven't picked a workflow yet.
function DashboardA() {
  const recent = [
    { name: "Trave bi-appoggiata UC1", nodes: 11, elements: 10, is3d: false, status: "ok" },
    { name: "Telaio portale 2D",        nodes: 18, elements: 21, is3d: false, status: "run" },
    { name: "Reticolo 3D · Capannone",  nodes: 36, elements: 84, is3d: true,  status: "ok" },
    { name: "Piastra Q4 2×2 m",         nodes:  9, elements:  4, is3d: false, status: "draft" },
  ];

  const checklist = [
    { done: true,  name: "Crea o importa un modello",     sub: "Da zero, template o file .ifc/.dxf" },
    { done: true,  name: "Definisci appoggi e carichi",   sub: "Vincoli + casi di carico + combinazioni" },
    { done: false, name: "Lancia l'analisi",              sub: "Scegli solver e compute profile" },
    { done: false, name: "Verifica risultati",            sub: "UC, σ, δ + checks normativi" },
  ];

  return (
    <main className="dash" data-screen-label="Dashboard">
      <div className="dash-main">

        <section className="hero" aria-label="Hero">
          <span className="hero-eyebrow">
            <span className="dot" />
            4 modelli · 1 job in corso · federico.sanna
          </span>
          <h1>Inizia un'analisi.</h1>
          <p>
            Due modi per costruire e analizzare un modello strutturale.
            Algoritmo prima, AI per accelerare — niente black box,
            tutti i calcoli tracciabili a formule normative.
          </p>
        </section>

        <section className="hubs" aria-label="Hub di lavoro">
          <HubCard
            axis="studio"
            primary
            title="Controllo totale<br/>sul modello."
            subtitle="Modalità expert. Tutti gli strumenti, qualsiasi ordine, senza guardrail. Per chi sa già cosa fare."
            bullets={[
              "Geometria · materiali · sezioni",
              "Solver Lineare, Modale, Sismica, Non-lineare",
              "Verifiche EC2 / EC3 / EC8 / NTC18",
            ]}
            cta="Apri Studio Pro"
          />
          <HubCard
            axis="percorsi"
            title="Guidato, senza<br/>perdere controllo."
            subtitle="Step persistenti, validation per step, sempre passabile a Studio Pro. Per chi vuole una traccia chiara."
            bullets={[
              "Verifica telaio 2D · Beam check",
              "Smart defaults · best practice integrata",
              "Lettura risultati assistita",
            ]}
            cta="Scegli un percorso"
          />
        </section>

        <section aria-label="Inizia da qui">
          <div className="sect-head">
            <h2>Inizia da qui</h2>
            <a href="#">Vedi tutti i template →</a>
          </div>
          <div className="qgrid">
            <QuickAction icon={<Icon.Plus />}    name="Nuovo modello"  sub="Da zero · empty workspace"             tag="NEW"   shortcut="⌘ N" />
            <QuickAction icon={<Icon.Layers />}  name="Da template"    sub="9 schemi resistenti pre-impostati"     tag="9 TPL" shortcut="↗" />
            <QuickAction icon={<Icon.FileUp />}  name="Importa IFC / DXF" sub="Wizard 4 step · geometria + metadata" tag="IMPORT" shortcut="↗" />
            <QuickAction icon={<Icon.Flask />}   name="Esempi"         sub="NAFEMS LE1 / LE2 / LE10 · benchmark"   tag="DEMO"  shortcut="↗" />
          </div>
        </section>

        <section aria-label="Modelli recenti">
          <div className="sect-head">
            <h2>Modelli recenti</h2>
            <a href="#">Vedi tutti →</a>
          </div>
          <div className="pgrid">
            {recent.map((m, i) => <ProjectCard key={i} {...m} />)}
          </div>
        </section>

        <div className="dropzone" role="button" tabIndex={0} aria-label="Dropzone import file">
          <Icon.FileUp />
          <span>Trascina file <b>.fea · .ifc · .dxf · .json</b> in qualsiasi punto della pagina per importarli.</span>
        </div>
      </div>

      <aside className="dash-side" aria-label="Sidebar">
        <CreditsWidget used={42} cap={100} tier="FREE" />
        <ChecklistWidget items={checklist} />
        <CopilotWidget />
        <TipWidget />
      </aside>
    </main>
  );
}

window.DashboardA = DashboardA;
