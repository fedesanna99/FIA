// Dashboard C — "Workshop" — left rail with project list always visible.
// Best for power users who switch between projects often. IDE/Linear pattern.
function DashboardC() {
  const projects = [
    { name: "Telaio portale 2D",        meta: "18 N · ieri",  status: "run",   active: true },
    { name: "Trave bi-appoggiata UC1",  meta: "11 N · ieri",  status: "ok"   },
    { name: "Reticolo 3D · Capannone",  meta: "36 N · 4 mag", status: "ok"   },
    { name: "Piastra Q4 2×2 m",         meta:  "9 N · 2 mag", status: "draft"},
    { name: "Mensola C18 · L=2.5m",     meta:  "3 N · 28 apr",status: "ok"   },
    { name: "Trave continua a 3 campate", meta: "23 N · 25 apr", status: "ok" },
    { name: "Pilastro CA · §7.4.4",     meta:  "4 N · 22 apr",status: "draft"},
  ];

  return (
    <main className="dash dash-c" data-screen-label="Dashboard · Workshop">

      {/* LEFT RAIL — project list always visible */}
      <aside className="rail" aria-label="Progetti">
        <div className="rail-head">
          <span className="hero-eyebrow">Progetti · 4 di 24</span>
          <button className="btn btn-xs btn-outline" type="button"><Icon.Plus s={10}/> Nuovo</button>
        </div>

        <div className="rail-search">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input type="text" placeholder="Cerca progetto…" />
        </div>

        <div className="rail-filters">
          <button type="button" className="rail-filter active">Tutti</button>
          <button type="button" className="rail-filter">Acciaio</button>
          <button type="button" className="rail-filter">CA</button>
          <button type="button" className="rail-filter">Legno</button>
        </div>

        <div className="rail-list">
          {projects.map((p, i) => (
            <button key={i} type="button" className={`rail-item ${p.active ? "active" : ""}`}>
              <span className={`rail-dot ${p.status}`} />
              <div className="rail-body">
                <span className="rail-name">{p.name}</span>
                <span className="rail-meta">{p.meta}</span>
              </div>
              {p.status === "run" && <span className="rail-status">RUN</span>}
            </button>
          ))}
        </div>

        <div className="rail-foot">
          <div className="rail-credits">
            <div className="rail-credits-bar"><div style={{ width: "42%" }} /></div>
            <span className="rail-credits-meta">42 / 100 crediti · FREE</span>
          </div>
        </div>
      </aside>

      {/* MAIN — clean canvas */}
      <div className="dash-main">

        <section className="hero hero-c" aria-label="Hero">
          <h1>Inizia un'analisi.</h1>
          <p>Scegli il livello di guida. Cambi idea quando vuoi.</p>
        </section>

        <section className="hubs hubs-c" aria-label="Hub di lavoro">
          <HubCard
            axis="studio"
            primary
            title="Controllo totale<br/>sul modello."
            subtitle="Modalità expert. Tutti gli strumenti, qualsiasi ordine, senza guardrail. Per chi sa già cosa fare."
            bullets={[
              "Geometria · materiali · sezioni",
              "Solver Lineare, Modale, Sismica, Non-lineare",
              "Verifiche EC2 / EC3 / EC8 / NTC18",
            ]}
            cta="Apri Studio Pro"
          />
          <HubCard
            axis="percorsi"
            title="Guidato, senza<br/>perdere controllo."
            subtitle="Step persistenti, validation per step, sempre passabile a Studio Pro. Per chi vuole una traccia chiara."
            bullets={[
              "Verifica telaio 2D · Beam check",
              "Smart defaults · best practice integrata",
              "Lettura risultati assistita",
            ]}
            cta="Scegli un percorso"
          />
        </section>

        <section aria-label="Azioni rapide">
          <div className="sect-head">
            <h2>Azioni rapide</h2>
            <a href="#">Vedi tutti i template →</a>
          </div>
          <div className="qgrid qgrid-c">
            <QuickAction icon={<Icon.Plus />}    name="Nuovo modello"  sub="Da zero · empty workspace"             tag="NEW"   shortcut="⌘ N" />
            <QuickAction icon={<Icon.Layers />}  name="Da template"    sub="9 schemi resistenti pre-impostati"     tag="9 TPL" shortcut="↗" />
            <QuickAction icon={<Icon.FileUp />}  name="Importa IFC / DXF" sub="Wizard 4 step · geometria + metadata" tag="IMPORT" shortcut="↗" />
            <QuickAction icon={<Icon.Flask />}   name="Esempi"         sub="NAFEMS LE1 / LE2 / LE10 · benchmark"   tag="DEMO"  shortcut="↗" />
          </div>
        </section>

      </div>
    </main>
  );
}

window.DashboardC = DashboardC;
