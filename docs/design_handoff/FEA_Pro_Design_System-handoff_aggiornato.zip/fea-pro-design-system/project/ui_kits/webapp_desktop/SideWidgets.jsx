// Sidebar widgets — Credits / Checklist / Copilot / Tip.
function CreditsWidget({ used = 42, cap = 100, tier = "FREE" }) {
  const pct = Math.min(100, (used / cap) * 100);
  return (
    <section className="widget" aria-label="Crediti">
      <div className="widget-head">
        <span className="title">Crediti · Maggio</span>
        <span className="brand-tier">{tier}</span>
      </div>
      <div className="widget-big">
        <span className="n">{used}</span>
        <span className="d">/ {cap}</span>
      </div>
      <div className="progress"><div style={{ width: `${pct}%` }} /></div>
      <div style={{ display: "flex", justifyContent: "space-between", fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--ink-dim)" }}>
        <span>€{(used * 0.1).toFixed(2).replace(".", ",")} spesi</span>
        <span>reset 1 giu</span>
      </div>
      <button className="btn btn-outline btn-sm" type="button">Vedi fatturazione</button>
    </section>
  );
}

function ChecklistWidget({ items = [] }) {
  const done = items.filter(i => i.done).length;
  return (
    <section className="widget" aria-label="Per iniziare">
      <div className="widget-head">
        <span className="title">Per iniziare</span>
        <span className="eyebrow">{done} / {items.length}</span>
      </div>
      <div className="checklist">
        {items.map((it, i) => (
          <div className="checklist-item" key={i}>
            <span className={`checklist-num ${it.done ? "done" : ""}`}>{it.done ? "✓" : i + 1}</span>
            <div>
              <div className="name">{it.name}</div>
              <div className="sub">{it.sub}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function CopilotWidget() {
  return (
    <section className="widget" aria-label="Copilot">
      <div className="widget-head">
        <span className="title" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
          <span style={{ color: "var(--accent)" }}><Icon.Msg /></span>
          Copilot
        </span>
        <span className="brand-tier">BETA</span>
      </div>
      <p style={{ fontSize: 12, lineHeight: "1.55", color: "var(--ink-muted)", margin: 0 }}>
        Chiedi spiegazioni su un risultato, una norma o un workflow.
        L'algoritmo resta fonte di verità.
      </p>
      <button className="btn btn-outline btn-sm" type="button">Apri Copilot <Icon.ArrowR s={12} /></button>
    </section>
  );
}

function TipWidget() {
  return (
    <section className="widget" aria-label="Suggerimento">
      <div className="widget-head">
        <span className="title">Suggerimento</span>
        <span className="eyebrow">⌘ K</span>
      </div>
      <p style={{ fontSize: 12, lineHeight: "1.55", color: "var(--ink-muted)", margin: 0 }}>
        La <b style={{ color: "var(--ink)" }}>command palette</b> esegue qualsiasi azione: cerca per nome ("esegui", "ispeziona", "report") senza sapere dove sta nel menu.
      </p>
    </section>
  );
}

window.CreditsWidget = CreditsWidget;
window.ChecklistWidget = ChecklistWidget;
window.CopilotWidget = CopilotWidget;
window.TipWidget = TipWidget;
