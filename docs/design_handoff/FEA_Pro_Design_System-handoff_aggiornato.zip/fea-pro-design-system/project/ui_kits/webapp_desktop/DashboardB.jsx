// Dashboard B — "Continua dove eri" — the in-progress model is the hero.
// Best for the recurring engineer working on the same project for days.
function DashboardB() {
  const recent = [
    { name: "Trave bi-appoggiata UC1", nodes: 11, elements: 10, is3d: false, status: "ok" },
    { name: "Reticolo 3D · Capannone",  nodes: 36, elements: 84, is3d: true,  status: "ok" },
    { name: "Piastra Q4 2×2 m",         nodes:  9, elements:  4, is3d: false, status: "draft" },
  ];

  return (
    <main className="dash dash-b" data-screen-label="Dashboard · Continua">
      <div className="dash-main">

        {/* Compact welcome strip */}
        <section className="welcome" aria-label="Welcome">
          <span className="hero-eyebrow">
            <span className="dot" />
            4 modelli · 1 in corso · federico.sanna
          </span>
          <h1 className="welcome-h1">Bentornato.</h1>
        </section>

        {/* HERO: the in-progress model — the centerpiece */}
        <article className="continue" aria-label="Modello in corso">
          <div className="continue-thumb">
            <div className="continue-thumb-grid" />
            <span className="continue-stamp">
              <span className="dot" /> In corso · lineare statica · 64% · ~12s
            </span>
            <svg viewBox="0 0 600 340" preserveAspectRatio="xMidYMid meet">
              {/* portal frame: 2 columns + top beam */}
              <g stroke="var(--ink)" strokeWidth="1.4" fill="none">
                <line x1="120" y1="280" x2="120" y2="80"/>
                <line x1="480" y1="280" x2="480" y2="80"/>
                <line x1="120" y1="80"  x2="480" y2="80"/>
              </g>
              {/* distributed load arrows */}
              <g stroke="var(--coral)" strokeWidth="1" fill="none">
                <line x1="130" y1="50" x2="470" y2="50"/>
                {[140,180,220,260,300,340,380,420,460].map((x,i)=>(
                  <line key={i} x1={x} y1="50" x2={x} y2="74"/>
                ))}
              </g>
              {/* deformed shape ghost */}
              <g stroke="var(--accent)" strokeWidth="1.6" fill="none" strokeDasharray="3,4" opacity="0.9">
                <path d="M120,280 L120,92 Q300,124 480,92 L480,280"/>
              </g>
              {/* supports */}
              <g stroke="var(--ink)" strokeWidth="1.2" fill="none">
                <line x1="100" y1="280" x2="140" y2="280"/>
                {[0,1,2,3].map((i)=>(<line key={i} x1={104+i*10} y1="280" x2={98+i*10} y2="292"/>))}
                <line x1="460" y1="280" x2="500" y2="280"/>
                {[0,1,2,3].map((i)=>(<line key={i} x1={464+i*10} y1="280" x2={458+i*10} y2="292"/>))}
              </g>
              {/* nodes */}
              <g fill="var(--ink)">
                <circle cx="120" cy="80" r="3.5"/>
                <circle cx="480" cy="80" r="3.5"/>
                <circle cx="120" cy="280" r="3.5"/>
                <circle cx="480" cy="280" r="3.5"/>
                <circle cx="300" cy="80" r="5" fill="var(--warn)"/>
              </g>
              {/* peak labels */}
              <g fontFamily="JetBrains Mono" fontSize="11" fontWeight="600">
                <text x="300" y="32" fill="var(--coral)" textAnchor="middle">q = 12.50 kN/m</text>
                <text x="300" y="178" fill="var(--accent)" textAnchor="middle">δ_max = 8.42 mm @ x = 4.00 m</text>
                <text x="300" y="68" fill="var(--warn)" textAnchor="middle">M_max = 62.10 kNm</text>
              </g>
            </svg>
          </div>

          <div className="continue-side">
            <div className="continue-head">
              <span className="hero-eyebrow"><span className="dot" /> Telaio portale 2D</span>
              <h2 className="continue-h2">Continua dove<br/>avevi lasciato.</h2>
              <p className="continue-sub">Solver lineare statica · 11 sub-step su 18 · ultima modifica ieri 14:32.</p>
            </div>

            <div className="continue-kpi">
              <div className="kpi-tile">
                <span className="kpi-k">UR<sub>max</sub></span>
                <span className="kpi-v warn">1.18</span>
                <span className="kpi-meta">EL5 · EC3 §6.3.3</span>
              </div>
              <div className="kpi-tile">
                <span className="kpi-k">δ<sub>max</sub></span>
                <span className="kpi-v">8.42 <small>mm</small></span>
                <span className="kpi-meta">@ x = 4.00 m · L/712</span>
              </div>
              <div className="kpi-tile">
                <span className="kpi-k">M<sub>max</sub></span>
                <span className="kpi-v">62.10 <small>kNm</small></span>
                <span className="kpi-meta">mezzeria · SLU</span>
              </div>
            </div>

            <div className="continue-cta">
              <button className="btn btn-primary" type="button">
                Continua il modello
                <Icon.ArrowR />
              </button>
              <button className="btn btn-outline" type="button">Vedi risultati</button>
            </div>
          </div>
        </article>

        {/* Compact hub picker — secondary action */}
        <section aria-label="Oppure inizia da capo">
          <div className="sect-head">
            <h2>Oppure inizia da capo</h2>
          </div>
          <div className="hubs hubs-compact">
            <HubCard
              axis="studio"
              primary
              title="Studio Pro"
              subtitle="Modalità expert. Tutti gli strumenti, qualsiasi ordine."
              bullets={[]}
              cta="Apri Studio Pro"
            />
            <HubCard
              axis="percorsi"
              title="Percorsi"
              subtitle="Step persistenti, validation per step. Per una traccia chiara."
              bullets={[]}
              cta="Scegli un percorso"
            />
          </div>
        </section>

        {/* Other recents */}
        <section aria-label="Altri modelli recenti">
          <div className="sect-head">
            <h2>Altri modelli recenti</h2>
            <a href="#">Vedi tutti →</a>
          </div>
          <div className="pgrid pgrid-3">
            {recent.map((m, i) => <ProjectCard key={i} {...m} />)}
          </div>
        </section>
      </div>

      <aside className="dash-side" aria-label="Sidebar">
        <CreditsWidget used={42} cap={100} tier="FREE" />
        <TipWidget />
      </aside>
    </main>
  );
}

window.DashboardB = DashboardB;
