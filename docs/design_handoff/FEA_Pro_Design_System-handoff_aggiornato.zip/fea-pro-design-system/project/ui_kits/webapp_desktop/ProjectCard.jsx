// ProjectCard — recent model card with viewport thumbnail + status chip.
// When `compact` is true, hides the "N · EL" meta line for a cleaner row.
function ProjectCard({ name, nodes = 0, elements = 0, is3d = false, status = "ok", compact = false }) {
  const labels = { ok: "OK", run: "RUN", draft: "DRAFT", err: "ERR" };

  return (
    <button type="button" className={`pcard ${compact ? "pcard-compact" : ""}`}>
      <div className="thumb">
        <div className="thumb-grid" />
        <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }} viewBox="0 0 200 110" preserveAspectRatio="xMidYMid meet">
          {is3d ? (
            <g stroke="currentColor" strokeWidth="1.5" fill="none" style={{ color: "var(--ink-muted)" }}>
              <rect x="40" y="25" width="120" height="60" />
              <line x1="40" y1="25" x2="60" y2="15" />
              <line x1="160" y1="25" x2="180" y2="15" />
              <line x1="40" y1="85" x2="60" y2="75" />
              <line x1="160" y1="85" x2="180" y2="75" />
              <rect x="60" y="15" width="120" height="60" />
            </g>
          ) : (
            <g stroke="currentColor" strokeWidth="1.5" fill="none" style={{ color: "var(--ink-muted)" }}>
              <line x1="30" y1="90" x2="30" y2="30" />
              <line x1="170" y1="90" x2="170" y2="30" />
              <line x1="30" y1="30" x2="170" y2="30" />
              <line x1="30" y1="90" x2="170" y2="90" />
              <path d="M30,30 Q100,18 170,30" stroke="var(--accent)" strokeWidth="1.5" strokeDasharray="3,3" />
            </g>
          )}
        </svg>
      </div>
      <div className="meta">
        <div style={{ minWidth: 0 }}>
          <div className="name" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{name}</div>
          {!compact && <div className="sub">{nodes} N · {elements} EL</div>}
        </div>
        <span className={`pstatus ${status}`}>{labels[status]}</span>
      </div>
    </button>
  );
}

window.ProjectCard = ProjectCard;
