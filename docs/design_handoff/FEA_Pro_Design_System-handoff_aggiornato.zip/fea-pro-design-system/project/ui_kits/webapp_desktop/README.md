# FEA Pro · Desktop webapp UI kit

> High-fidelity recreation of the **current Precision v2.0 desktop UI** of FEA Pro.
> Pixel-faithful to `fedesanna99/FIA` · `src/components/shell/Dashboard.tsx` and `TopBar.tsx`.

## Components

| Component | Mirrors in repo |
|---|---|
| `TopBar.jsx` | `src/components/shell/TopBar.tsx` — h-12, brand mark, model menu, save chip, Esegui (run gradient) |
| `HubCard.jsx` | Inline component inside `Dashboard.tsx` — `/ Studio Pro` (cyan) vs `/ Percorsi` (ink) axis tags |
| `QuickAction.jsx` | `QuickAct` sub-component inside `Dashboard.tsx` — 4-up tile with icon, name, sub, foot |
| `ProjectCard.jsx` | `ProjCard` sub-component inside `Dashboard.tsx` — viewport thumbnail + status chip |
| `SideWidgets.jsx` | Sidebar widgets: Credits, Per iniziare checklist, Copilot, ⌘K Tip |
| `Dashboard.jsx` | Top-level composition of the home screen |
| `Icons.jsx` | Lucide-style icons inlined as SVGs (stroke 1.8, currentColor) |

## What this kit covers

The **home / dashboard** screen of FEA Pro on desktop. The two hub cards (Studio Pro vs Percorsi) are the entry points — the rest of the app (workspaces, viewport, panels) lives behind those CTAs in the real product.

## What this kit deliberately omits

- The Three.js 3D viewport — the actual canvas is in `src/viewport-engine/`. Recreate visually with the `viewport-thumbnail` preview card if needed.
- The Command Palette (⌘K) modal — a `cmdk`-powered dialog in the real product.
- The full workspace shell (left rail + right rail + status bar) — those are in `src/components/shell/LeftRail.tsx`, `RightRail.tsx`, etc.
- The Tweaks side panel and live edit mode — not part of the user-facing product.

## How to use

Open `index.html` directly in a browser. No build step. React + Babel via CDN.

To extend: add a new JSX file, attach the component to `window`, and load it via a `<script type="text/babel" src="...">` tag in `index.html` *before* `Dashboard.jsx` (or whatever needs it).

## Visual references

- Source repo: [github.com/fedesanna99/FIA](https://github.com/fedesanna99/FIA)
- Tokens: `../../colors_and_type.css`
- Brand voice & content rules: `../../README.md` § 3 — Content fundamentals
