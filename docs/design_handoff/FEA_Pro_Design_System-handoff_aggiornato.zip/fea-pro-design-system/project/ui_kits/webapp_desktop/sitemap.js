/* ─────────────────────────────────────────────────────────────────
 * FEA Pro · Sitemap data + renderer
 *
 * Mappa completa schermate previste nel redesign.
 * Modifica `SECTIONS` per aggiungere/rimuovere card.
 * Lo status determina il badge e l'ordine di lavoro.
 * Le thumb sono schemi iconografici SVG inline.
 * ───────────────────────────────────────────────────────────────── */

// ── Status registry ─────────────────────────────────────────────
//   done    → mockup HTML hi-fi pronto
//   wip     → struttura presente, da rifinire
//   todo    → ancora da fare
//   next    → prossimo nel piano (badge "NEXT")

const SECTIONS = [
  {
    num: "00",
    title: "Foundation",
    items: [
      {
        title: "Tokens · CSS variables",
        desc: "Colors · type · radii · motion · spacing · z-index. Single source of truth. Import per primo in ogni file.",
        href: "src/tokens.css", path: "src/tokens.css", status: "done",
        meta: ["171 lines", "14 colors", "9 radii"],
        thumb: thumbTokensCSS(),
      },
      {
        title: "Tokens · TypeScript mirror",
        desc: "Mirror TS dei tokens. Per typing prop, Tailwind config dinamico, generazione Storybook.",
        href: "src/tokens.ts", path: "src/tokens.ts", status: "done",
        meta: ["155 lines", "as const", "type SemanticColor"],
        thumb: thumbTokensTS(),
      },
      {
        title: "Design Handoff",
        desc: "Documento maestro per Claude Code: file map · routes · primitives · interazioni · checklist d'implementazione.",
        href: "DESIGN_HANDOFF.md", path: "DESIGN_HANDOFF.md", status: "done",
        meta: ["Markdown", "12 sezioni"],
        thumb: thumbHandoff(),
      },
    ],
  },

  {
    num: "01",
    title: "Auth",
    items: [
      {
        title: "Auth · 4 stati",
        desc: "Login · Signup · Forgot password · Email verify. Card centrato 380px + side art con FEM iconography.",
        href: "ui_kits/webapp_desktop/Auth.html",
        path: "Auth.html", status: "done",
        meta: ["POST /auth/login", "POST /auth/signup"],
        thumb: thumbAuth(),
      },
    ],
  },

  {
    num: "02",
    title: "Onboarding & Hub",
    items: [
      {
        title: "Dashboard · Hub",
        desc: "Hub home: hero \"Inizia da\" · 3 tile (Nuovo modello / Template / Percorso) · progetti recenti · template gallery condensata.",
        href: "ui_kits/webapp_desktop/Dashboard new.html",
        path: "Dashboard new.html", status: "done",
        meta: ["GET /api/projects", "GET /api/templates"],
        thumb: thumbDashboard(),
      },
      {
        title: "Template Gallery",
        desc: "9 template (Trave · Mensola · Telaio 2D · Torre 3D · Piastra · Tirante · Reticolare · Mensola incastrata · Cap.) con preview SVG e filtri.",
        href: "ui_kits/webapp_desktop/Templates.html",
        path: "Templates.html", status: "done",
        meta: ["9 template", "tier free/pro"],
        thumb: thumbTemplates(),
      },
      {
        title: "Percorso UC1 · stepper",
        desc: "Onboarding guidato 6 step: Geometria → Vincoli → Carichi → Solve → Verify → Export. Coach contestuale a lato + canvas live.",
        href: "ui_kits/webapp_desktop/Percorso UC1.html",
        path: "Percorso UC1.html", status: "done",
        meta: ["6 step", "Quickstart README"],
        thumb: thumbPercorso(),
      },
    ],
  },

  {
    num: "03",
    title: "Studio Pro · 5 workspace",
    items: [
      {
        title: "Studio · Modello",
        desc: "Albero gerarchico + Mesh wizard (lineare · quad · tri · box · parametrica L/T/cerchio) + Schema editor (winkler_k, releases, compression_only).",
        href: "ui_kits/webapp_desktop/Studio Modello.html",
        path: "Studio Modello.html", status: "done",
        meta: ["MESH PARAM", "SCHEMA EDITOR"],
        thumb: thumbStudio("modello"),
      },
      {
        title: "Studio · Analisi",
        desc: "Catalogo analisi (statica · modale · dinamica Newmark · buckling · push-over · sismica TH) · parametri solver · monitor WS in tempo reale.",
        href: "ui_kits/webapp_desktop/Studio Analisi.html",
        path: "Studio Analisi.html", status: "done",
        meta: ["WS /ws/solver", "push-over", "sismica"],
        thumb: thumbStudio("analisi"),
      },
      {
        title: "Studio · Risultati",
        desc: "Workspace risultati ESPANSO: Viewport · Diagrammi N/V/M · Postprocess iso-linee/slice planes · Qualità mesh (ZZ error · h-refinement).",
        href: "ui_kits/webapp_desktop/Nuovo Guscio.html",
        path: "Nuovo Guscio.html", status: "done",
        meta: ["1/4 tab done", "espansione TODO"],
        thumb: thumbStudio("risultati"),
      },
      {
        title: "Studio · Verifiche",
        desc: "EC3 + NUOVI EC2 (CA flex/taglio) · EC5 (legno k_mod) · EC8 (spettro elastico, drift) · NTC 2018 (combinazioni SLU/SLE). UR per elemento + report PDF.",
        href: "ui_kits/webapp_desktop/Studio Verifiche.html",
        path: "Studio Verifiche.html", status: "done",
        meta: ["EC2/3/5/8", "NTC18", "report PDF"],
        thumb: thumbStudio("verifiche"),
      },
      {
        title: "Studio · I/O & Collab",
        desc: "Import DXF/IFC/XLSX/JSON · Export PDF/XLSX/DXF/IFC · Compare A/B server-side · Auto-detect 5 detector · AI Copilot · Collab live cursori.",
        href: "ui_kits/webapp_desktop/Studio IO.html",
        path: "Studio IO.html", status: "done",
        meta: ["Compare A/B", "AI Copilot", "Collab"],
        thumb: thumbStudio("io"),
      },
      {
        title: "Inspector · Component reference",
        desc: "Inspector panel in 6 stati (Node · Beam · Shell · Cable · Plate · Multi) + 3 bonus (Empty · Loading · Error). Ogni stato include il contratto dati backend (REQUIRED/OPTIONAL fields, endpoint, position annotation, governing failure).",
        href: "ui_kits/webapp_desktop/Inspector reference.html",
        path: "Inspector reference.html", status: "done",
        meta: ["6 stati", "+3 bonus", "backend contract"],
        thumb: thumbInspectorRef(),
      },
    ],
  },

  {
    num: "04",
    title: "Dialogs & Wizards",
    items: [
      {
        title: "Dialog · Node + Element",
        desc: "Modal a tab. Crea/modifica nodo (coord X/Y/Z · DOF · vincoli) ed elemento (tipo beam2d/3d/truss/shell · sezione · materiale · release).",
        href: "ui_kits/webapp_desktop/Dialogs.html#node",
        path: "Dialogs.html · #node", status: "done",
        meta: ["NodeData", "ElementData"],
        thumb: thumbDialog("node"),
      },
      {
        title: "Dialog · Load + Constraint",
        desc: "Carico nodale/distribuito (Fx/Fy/Fz · q_x/q_y · combo) · vincolo (cerniera · carrello · incastro · compression_only · winkler · spring_k).",
        href: "ui_kits/webapp_desktop/Dialogs.html#load",
        path: "Dialogs.html · #load", status: "done",
        meta: ["LoadData", "ConstraintData"],
        thumb: thumbDialog("load"),
      },
      {
        title: "Wizard · Mesh parametrica",
        desc: "Stepper: Forma (L / T / cerchio / anello) → Dimensioni → Sub-divisione → Materiale → Preview. NEW v2.4.",
        href: "ui_kits/webapp_desktop/Dialogs.html#mesh",
        path: "Dialogs.html · #mesh", status: "done",
        meta: ["5 step", "preview live", "NEW"],
        thumb: thumbDialog("mesh"),
      },
      {
        title: "Dialog · New Model",
        desc: "Modal apertura: parti da Template / Importa file / Modello vuoto. Combobox unità (SI · imperial) e nome progetto.",
        href: "ui_kits/webapp_desktop/Dialogs.html#new",
        path: "Dialogs.html · #new", status: "done",
        meta: ["3 modalità"],
        thumb: thumbDialog("new"),
      },
    ],
  },

  {
    num: "05",
    title: "Settings",
    items: [
      {
        title: "Settings · Account",
        desc: "Sidebar settings con 5 tab: Account · Profilo · Billing & tier · API keys · Preferenze (theme · density · unità default · scorciatoie).",
        href: "ui_kits/webapp_desktop/Settings.html",
        path: "Settings.html", status: "done",
        meta: ["5 tab", "tier · API keys"],
        thumb: thumbSettings(),
      },
    ],
  },

  {
    num: "06",
    title: "Stati di sistema",
    items: [
      {
        title: "Solver running",
        desc: "Schermata mid-analisi: viewport con elementi in evidenziazione progressiva · panel destro con WS progress · log streaming · cancel.",
        href: "ui_kits/webapp_desktop/States.html#solver",
        path: "States.html · #solver", status: "done",
        meta: ["WS /ws/solver", "progress"],
        thumb: thumbState("solver"),
      },
      {
        title: "Empty · primo modello",
        desc: "Stato vuoto del workspace Modello: hero illustrato + 3 CTA (Nuovo / Template / Importa). Niente \"no data\" generico.",
        href: "ui_kits/webapp_desktop/States.html#empty",
        path: "States.html · #empty", status: "done",
        meta: ["call-to-action"],
        thumb: thumbState("empty"),
      },
      {
        title: "Error · solver fail",
        desc: "Stato errore: matrice singolare con explainer + suggerimento auto-fix · vincoli mancanti · NaN warning · log download.",
        href: "ui_kits/webapp_desktop/States.html#error",
        path: "States.html · #error", status: "done",
        meta: ["explainer", "auto-fix"],
        thumb: thumbState("error"),
      },
      {
        title: "404 · Not found",
        desc: "Pagina 404 minimal con FEM iconography (matrice K). Link rapidi: Dashboard · Studio Pro · Docs.",
        href: "ui_kits/webapp_desktop/States.html#404",
        path: "States.html · #404", status: "done",
        meta: ["fallback"],
        thumb: thumbState("404"),
      },
    ],
  },

  {
    num: "07",
    title: "Mobile",
    items: [
      {
        title: "Mobile · Viewer + Inspector",
        desc: "Redesign mobile: bottom tabbar 4 voci · viewport pinch/pan · inspector pannello sheet bottom-up · Risultati read-only.",
        href: "ui_kits/mobile_redesign/Mobile.html",
        path: "Mobile.html", status: "done",
        meta: ["375×812", "iPhone 13"],
        thumb: thumbMobile(),
      },
    ],
  },
];


// ── Thumbnails (schematic SVG inline) ───────────────────────────

function thumbTokensCSS() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect x="14" y="14" width="172" height="36" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="22" y="32" fill="var(--ink)" font-family="JetBrains Mono" font-size="8" font-weight="700">/* tokens.css */</text>
    <text x="22" y="44" fill="var(--ink-dim)" font-family="JetBrains Mono" font-size="6">--accent: #0891B2;</text>
    <g transform="translate(14 60)">
      <rect width="26" height="14" rx="3" fill="#0891B2"/>
      <rect x="30" width="26" height="14" rx="3" fill="#65A30D"/>
      <rect x="60" width="26" height="14" rx="3" fill="#B45309"/>
      <rect x="90" width="26" height="14" rx="3" fill="#534AB7"/>
      <rect x="120" width="26" height="14" rx="3" fill="#DC2626"/>
      <rect x="150" width="22" height="14" rx="3" fill="#FAFAFA" stroke="var(--border)" stroke-width="0.5"/>
    </g>
    <g transform="translate(14 84)">
      <rect width="32" height="28" rx="2" fill="none" stroke="var(--accent)" stroke-width="0.8"/>
      <rect x="40" width="32" height="28" rx="6" fill="none" stroke="var(--accent)" stroke-width="0.8"/>
      <rect x="80" width="32" height="28" rx="10" fill="none" stroke="var(--accent)" stroke-width="0.8"/>
      <rect x="120" width="32" height="28" rx="14" fill="none" stroke="var(--accent)" stroke-width="0.8"/>
      <rect x="160" width="22" height="28" rx="11" fill="none" stroke="var(--accent)" stroke-width="0.8"/>
    </g>
  </svg>`;
}

function thumbTokensTS() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect x="14" y="14" width="172" height="97" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <g font-family="JetBrains Mono" font-size="7.5">
      <text x="22" y="30" fill="#534AB7">export</text>
      <text x="56" y="30" fill="var(--ink)">const tokens = {</text>
      <text x="30" y="44" fill="var(--ink-muted)">light: { ... },</text>
      <text x="30" y="58" fill="var(--ink-muted)">dark:  { ... },</text>
      <text x="30" y="72" fill="var(--ink-muted)">radius: { ... },</text>
      <text x="30" y="86" fill="var(--ink-muted)">motion: { ... },</text>
      <text x="22" y="100" fill="var(--ink)">}</text>
      <text x="38" y="100" fill="var(--accent)">as const;</text>
    </g>
  </svg>`;
}

function thumbHandoff() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect x="14" y="14" width="172" height="97" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="22" y="32" fill="var(--ink)" font-family="Plus Jakarta Sans" font-size="11" font-weight="700"># DESIGN_HANDOFF</text>
    <rect x="22" y="40" width="100" height="3" rx="1" fill="var(--ink)" opacity="0.4"/>
    <rect x="22" y="48" width="140" height="3" rx="1" fill="var(--ink)" opacity="0.4"/>
    <rect x="22" y="56" width="120" height="3" rx="1" fill="var(--ink)" opacity="0.4"/>
    <rect x="22" y="68" width="60" height="6" rx="2" fill="var(--accent)"/>
    <rect x="22" y="80" width="140" height="3" rx="1" fill="var(--ink)" opacity="0.4"/>
    <rect x="22" y="88" width="80" height="3" rx="1" fill="var(--ink-faint)"/>
    <rect x="22" y="96" width="120" height="3" rx="1" fill="var(--ink)" opacity="0.4"/>
  </svg>`;
}

function thumbAuth() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <g opacity="0.4" stroke="var(--border)" stroke-width="0.5">
      <line x1="0" y1="40" x2="200" y2="40"/>
      <line x1="0" y1="80" x2="200" y2="80"/>
      <line x1="60" y1="0" x2="60" y2="125"/>
      <line x1="140" y1="0" x2="140" y2="125"/>
    </g>
    <rect x="60" y="18" width="80" height="90" rx="10" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="68" y="32" font-family="Plus Jakarta Sans" font-size="8" font-weight="700" fill="var(--ink)">Bentornato</text>
    <text x="68" y="42" font-family="Inter" font-size="6" fill="var(--ink-dim)">Accedi al tuo account</text>
    <rect x="68" y="50" width="64" height="9" rx="4" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="71" y="56" font-family="Inter" font-size="5" fill="var(--ink-faint)">Email</text>
    <rect x="68" y="62" width="64" height="9" rx="4" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="71" y="68" font-family="Inter" font-size="5" fill="var(--ink-faint)">Password</text>
    <rect x="68" y="76" width="64" height="9" rx="4" fill="var(--accent)"/>
    <text x="100" y="82" font-family="Inter" font-size="5" font-weight="700" fill="#fff" text-anchor="middle">Entra</text>
    <line x1="68" y1="92" x2="132" y2="92" stroke="var(--border)" stroke-width="0.5"/>
    <text x="100" y="100" font-family="Inter" font-size="5" fill="var(--accent)" text-anchor="middle">Crea account</text>
  </svg>`;
}

function thumbDashboard() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect width="200" height="14" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <circle cx="10" cy="7" r="3" fill="var(--accent)"/>
    <rect x="20" y="4" width="60" height="6" rx="2" fill="var(--ink)" opacity="0.6"/>
    <rect x="155" y="3" width="40" height="8" rx="3" fill="var(--accent-subtle)" stroke="var(--accent)" stroke-width="0.4"/>
    <text x="14" y="28" font-family="Plus Jakarta Sans" font-size="9" font-weight="700" fill="var(--ink)">Ben tornato Federico</text>
    <rect x="14" y="38" width="55" height="42" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <rect x="22" y="46" width="20" height="3" rx="1" fill="var(--accent)"/>
    <rect x="22" y="52" width="38" height="3" rx="1" fill="var(--ink)" opacity="0.5"/>
    <rect x="73" y="38" width="55" height="42" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <rect x="81" y="46" width="20" height="3" rx="1" fill="var(--purple)"/>
    <rect x="81" y="52" width="38" height="3" rx="1" fill="var(--ink)" opacity="0.5"/>
    <rect x="132" y="38" width="55" height="42" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <rect x="140" y="46" width="20" height="3" rx="1" fill="var(--warn)"/>
    <rect x="140" y="52" width="38" height="3" rx="1" fill="var(--ink)" opacity="0.5"/>
    <text x="14" y="92" font-family="JetBrains Mono" font-size="6" fill="var(--ink-dim)">PROGETTI RECENTI</text>
    <rect x="14" y="96" width="172" height="11" rx="3" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <rect x="14" y="110" width="172" height="11" rx="3" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
  </svg>`;
}

function thumbTemplates() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <text x="14" y="22" font-family="Plus Jakarta Sans" font-size="10" font-weight="700" fill="var(--ink)">Template Gallery</text>
    <rect x="14" y="28" width="46" height="7" rx="3" fill="var(--accent-subtle)" stroke="var(--accent)" stroke-width="0.4"/>
    <text x="37" y="33" font-family="Inter" font-size="5" font-weight="600" fill="var(--accent)" text-anchor="middle">Tutti</text>
    <rect x="64" y="28" width="32" height="7" rx="3" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.4"/>
    <text x="80" y="33" font-family="Inter" font-size="5" fill="var(--ink-dim)" text-anchor="middle">Acciaio</text>
    <rect x="100" y="28" width="28" height="7" rx="3" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.4"/>
    <text x="114" y="33" font-family="Inter" font-size="5" fill="var(--ink-dim)" text-anchor="middle">CA</text>
    <rect x="132" y="28" width="28" height="7" rx="3" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.4"/>
    <text x="146" y="33" font-family="Inter" font-size="5" fill="var(--ink-dim)" text-anchor="middle">Legno</text>
    ${[0,1,2].map((c) => [0,1].map((r) => `
      <g transform="translate(${14 + c*60} ${44 + r*38})">
        <rect width="55" height="34" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
        <line x1="6" y1="14" x2="49" y2="14" stroke="var(--ink)" stroke-width="1.4"/>
        <polygon points="6,18 4,22 8,22" fill="none" stroke="var(--ink-muted)" stroke-width="0.6"/>
        <polygon points="49,18 47,22 51,22" fill="none" stroke="var(--ink-muted)" stroke-width="0.6"/>
        <rect x="4" y="26" width="22" height="3" rx="1" fill="var(--ink)" opacity="0.5"/>
      </g>
    `).join('')).join('')}
  </svg>`;
}

function thumbPercorso() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect x="14" y="14" width="172" height="38" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="22" y="26" font-family="JetBrains Mono" font-size="6" font-weight="700" letter-spacing="0.10em" fill="var(--accent)">PERCORSO · UC1</text>
    <text x="22" y="38" font-family="Plus Jakarta Sans" font-size="10" font-weight="700" fill="var(--ink)">Trave bi-appoggiata · Statica</text>
    <rect x="22" y="44" width="40" height="3" rx="1" fill="var(--accent)"/>
    <rect x="14" y="58" width="172" height="50" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <g transform="translate(28 70)">
      <circle cx="6" cy="6" r="6" fill="var(--success)"/>
      <line x1="12" y1="6" x2="30" y2="6" stroke="var(--success)" stroke-width="1.5"/>
      <circle cx="36" cy="6" r="6" fill="var(--success)"/>
      <line x1="42" y1="6" x2="60" y2="6" stroke="var(--success)" stroke-width="1.5"/>
      <circle cx="66" cy="6" r="7" fill="var(--accent-subtle)" stroke="var(--accent)" stroke-width="2"/>
      <text x="66" y="9" font-family="JetBrains Mono" font-size="7" font-weight="700" fill="var(--accent)" text-anchor="middle">3</text>
      <line x1="73" y1="6" x2="90" y2="6" stroke="var(--border)" stroke-width="1.5"/>
      <circle cx="96" cy="6" r="6" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="1.5"/>
      <line x1="102" y1="6" x2="120" y2="6" stroke="var(--border)" stroke-width="1.5"/>
      <circle cx="126" cy="6" r="6" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="1.5"/>
      <line x1="132" y1="6" x2="150" y2="6" stroke="var(--border)" stroke-width="1.5"/>
      <circle cx="156" cy="6" r="6" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="1.5"/>
    </g>
    <text x="22" y="93" font-family="Plus Jakarta Sans" font-size="7" font-weight="600" fill="var(--ink)">Step 3 · Aggiungi i carichi</text>
    <rect x="22" y="98" width="140" height="3" rx="1" fill="var(--ink)" opacity="0.4"/>
  </svg>`;
}

function thumbStudio(ws) {
  const wsConfig = {
    modello: { accent: 0, label: "MODELLO" },
    analisi: { accent: 1, label: "ANALISI" },
    risultati: { accent: 2, label: "RISULTATI", done: true },
    verifiche: { accent: 3, label: "VERIFICHE" },
    io: { accent: 4, label: "I/O" },
  }[ws];
  const railY = (i) => 16 + i * 16;
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect width="200" height="10" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <rect x="2" y="2" width="6" height="6" rx="1.5" fill="var(--accent)"/>
    <text x="12" y="7" font-family="Plus Jakarta Sans" font-size="5" font-weight="700" fill="var(--ink)">FEA Pro</text>
    <rect x="138" y="2" width="32" height="6" rx="2" fill="var(--bg-warn)" stroke="var(--warn)" stroke-width="0.4"/>
    <text x="154" y="6.5" font-family="JetBrains Mono" font-size="4" font-weight="700" fill="var(--warn)" text-anchor="middle">PRELIM</text>
    <rect x="172" y="2" width="24" height="6" rx="2" fill="var(--success)"/>
    <text x="184" y="6.5" font-family="Inter" font-size="4" font-weight="700" fill="#fff" text-anchor="middle">RUN</text>

    <rect width="14" y="10" height="115" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    ${[0,1,2,3,4].map(i => `
      <rect x="2" y="${railY(i)}" width="10" height="12" rx="2"
        fill="${i === wsConfig.accent ? 'var(--accent-subtle)' : 'transparent'}"/>
      <rect x="4" y="${railY(i) + 3}" width="6" height="6" rx="1"
        fill="${i === wsConfig.accent ? 'var(--accent)' : 'var(--ink-dim)'}"/>
    `).join('')}

    ${ws === 'modello' ? `
      <g transform="translate(70 50)">
        <line x1="0" y1="20" x2="60" y2="20" stroke="var(--ink)" stroke-width="1.8"/>
        ${[0,1,2,3,4,5].map(i => `<circle cx="${i*12}" cy="20" r="2" fill="${i === 2 ? 'var(--accent)' : 'var(--ink)'}"/>`).join('')}
        <polygon points="0,22 -4,28 4,28" fill="none" stroke="var(--ink)" stroke-width="0.8"/>
        <polygon points="60,22 56,28 64,28" fill="none" stroke="var(--ink)" stroke-width="0.8"/>
        <text x="30" y="40" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)" text-anchor="middle">L = 6.0 m</text>
      </g>
    ` : ws === 'analisi' ? `
      <g transform="translate(60 40)">
        <rect width="60" height="40" rx="6" fill="var(--bg-panel)" stroke="var(--accent)" stroke-width="0.6" stroke-dasharray="2 2"/>
        <circle cx="30" cy="20" r="12" fill="none" stroke="var(--accent)" stroke-width="1.4"/>
        <circle cx="30" cy="20" r="6" fill="var(--accent)"/>
        <text x="30" y="22" font-family="JetBrains Mono" font-size="6" font-weight="700" fill="#fff" text-anchor="middle">F5</text>
      </g>
    ` : ws === 'risultati' ? `
      <g transform="translate(60 36)">
        <defs>
          <linearGradient id="stress-thumb" x1="0" x2="1">
            <stop offset="0" stop-color="#1e3a8a"/>
            <stop offset="0.3" stop-color="#06b6d4"/>
            <stop offset="0.6" stop-color="#facc15"/>
            <stop offset="1" stop-color="#dc2626"/>
          </linearGradient>
        </defs>
        <path d="M0 28 Q30 50, 60 28" stroke="url(#stress-thumb)" stroke-width="6" fill="none" stroke-linecap="round"/>
        <rect x="0" y="56" width="60" height="3" fill="url(#stress-thumb)" rx="1"/>
        <text x="0" y="68" font-family="JetBrains Mono" font-size="4" fill="var(--ink-dim)">0</text>
        <text x="55" y="68" font-family="JetBrains Mono" font-size="4" fill="var(--ink-dim)">178 MPa</text>
      </g>
    ` : ws === 'verifiche' ? `
      <g transform="translate(60 40)">
        ${[0.08, 0.14, 0.19, 0.22, 0.24, 0.22, 0.19].map((ur, i) => `
          <rect x="${i*9}" y="${42 - ur*120}" width="6" height="${ur*120}" fill="${ur > 0.20 ? 'var(--warn)' : 'var(--accent)'}"/>
        `).join('')}
        <line x1="-2" y1="42" x2="64" y2="42" stroke="var(--ink)" stroke-width="0.6"/>
        <text x="30" y="52" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)" text-anchor="middle">UR EC3 · max 0.24</text>
      </g>
    ` : `
      <g transform="translate(60 40)">
        <rect width="60" height="30" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5" stroke-dasharray="2 2"/>
        <text x="30" y="14" font-family="Inter" font-size="5" fill="var(--ink-dim)" text-anchor="middle">Trascina .dxf .ifc</text>
        <text x="30" y="22" font-family="JetBrains Mono" font-size="4" font-weight="700" fill="var(--accent)" text-anchor="middle">IMPORT</text>
      </g>
    `}

    <rect x="140" y="10" width="60" height="115" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="144" y="22" font-family="JetBrains Mono" font-size="5" font-weight="700" letter-spacing="0.10em" fill="var(--ink-dim)">${wsConfig.label}</text>
    <rect x="144" y="26" width="52" height="3" rx="1" fill="var(--ink)" opacity="0.5"/>
    <line x1="144" y1="34" x2="196" y2="34" stroke="var(--border)" stroke-width="0.5"/>
    <rect x="144" y="40" width="32" height="4" rx="1" fill="var(--accent-subtle)"/>
    <rect x="146" y="41" width="28" height="2" rx="1" fill="var(--accent)"/>
    <rect x="144" y="48" width="52" height="14" rx="2" fill="var(--bg-hover)"/>
    <rect x="144" y="66" width="52" height="14" rx="2" fill="var(--bg-hover)"/>
    <rect x="144" y="84" width="52" height="14" rx="2" fill="var(--bg-hover)"/>
    <rect x="144" y="104" width="52" height="6" rx="2" fill="var(--accent)"/>
  </svg>`;
}

function thumbDialog(kind) {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)" opacity="0.6"/>
    <rect width="200" height="125" fill="#000" opacity="0.10"/>
    <rect x="30" y="18" width="140" height="92" rx="10" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.6"/>
    <text x="40" y="32" font-family="Plus Jakarta Sans" font-size="9" font-weight="700" fill="var(--ink)">
      ${kind === 'node' ? 'Modifica Nodo · N₅'
        : kind === 'load' ? 'Aggiungi Carico'
        : kind === 'mesh' ? 'Mesh Parametrica'
        : 'Nuovo Modello'}
    </text>
    <text x="160" y="32" font-family="JetBrains Mono" font-size="8" fill="var(--ink-dim)" text-anchor="end">✕</text>
    ${kind === 'mesh' ? `
      <g transform="translate(40 42)">
        <circle cx="6" cy="6" r="6" fill="var(--success)"/>
        <line x1="12" y1="6" x2="30" y2="6" stroke="var(--success)" stroke-width="1.5"/>
        <circle cx="36" cy="6" r="6" fill="var(--accent)"/>
        <line x1="42" y1="6" x2="60" y2="6" stroke="var(--border)" stroke-width="1"/>
        <circle cx="66" cy="6" r="6" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="1"/>
        <line x1="72" y1="6" x2="90" y2="6" stroke="var(--border)" stroke-width="1"/>
        <circle cx="96" cy="6" r="6" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="1"/>
        <line x1="102" y1="6" x2="120" y2="6" stroke="var(--border)" stroke-width="1"/>
        <circle cx="126" cy="6" r="6" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="1"/>
      </g>
    ` : `
      <g transform="translate(40 40)">
        <rect width="60" height="9" rx="3" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="0.4"/>
        <text x="3" y="6" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)">x · 2.400</text>
        <rect x="64" width="60" height="9" rx="3" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="0.4"/>
        <text x="67" y="6" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)">y · 0.000</text>
      </g>
    `}
    <rect x="40" y="60" width="120" height="9" rx="3" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="0.4"/>
    <rect x="40" y="74" width="120" height="9" rx="3" fill="var(--bg-hover)" stroke="var(--border)" stroke-width="0.4"/>
    <line x1="40" y1="92" x2="160" y2="92" stroke="var(--border)" stroke-width="0.4"/>
    <rect x="40" y="96" width="40" height="9" rx="3" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.4"/>
    <text x="60" y="103" font-family="Inter" font-size="5" fill="var(--ink-dim)" text-anchor="middle">Annulla</text>
    <rect x="120" y="96" width="40" height="9" rx="3" fill="var(--accent)"/>
    <text x="140" y="103" font-family="Inter" font-size="5" font-weight="700" fill="#fff" text-anchor="middle">Conferma</text>
  </svg>`;
}

function thumbSettings() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect width="60" height="125" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="6" y="14" font-family="Plus Jakarta Sans" font-size="7" font-weight="700" fill="var(--ink)">Impostazioni</text>
    <rect x="0" y="22" width="60" height="12" fill="var(--accent-subtle)"/>
    <rect x="0" y="22" width="2" height="12" fill="var(--accent)"/>
    <text x="8" y="30" font-family="Inter" font-size="6" font-weight="600" fill="var(--accent)">Account</text>
    ${["Profilo","Billing & tier","API keys","Preferenze"].map((s, i) => `
      <text x="8" y="${48 + i*14}" font-family="Inter" font-size="6" fill="var(--ink-dim)">${s}</text>
    `).join('')}
    <text x="68" y="18" font-family="Plus Jakarta Sans" font-size="11" font-weight="700" fill="var(--ink)">Account</text>
    <text x="68" y="28" font-family="Inter" font-size="6" fill="var(--ink-dim)">Email · piano · password · 2FA</text>
    <rect x="68" y="40" width="120" height="20" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="74" y="50" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)">EMAIL</text>
    <text x="74" y="58" font-family="Inter" font-size="6" font-weight="600" fill="var(--ink)">f.sanna@example.com</text>
    <rect x="68" y="66" width="120" height="20" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="74" y="76" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)">PIANO</text>
    <text x="74" y="84" font-family="Inter" font-size="6" font-weight="600" fill="var(--accent)">FREE · upgrade a Pro</text>
    <rect x="68" y="92" width="120" height="20" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="74" y="102" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)">PASSWORD</text>
    <text x="74" y="110" font-family="Inter" font-size="6" font-weight="600" fill="var(--ink)">Cambia password</text>
  </svg>`;
}

function thumbState(kind) {
  if (kind === 'solver') return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect width="200" height="10" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <rect x="138" y="2" width="36" height="6" rx="2" fill="var(--bg-info)" stroke="var(--accent)" stroke-width="0.4"/>
    <text x="156" y="6.5" font-family="JetBrains Mono" font-size="4" font-weight="700" fill="var(--accent)" text-anchor="middle">RUNNING</text>
    <line x1="20" y1="60" x2="180" y2="60" stroke="var(--ink)" stroke-width="2"/>
    ${[0,1,2,3,4,5,6,7,8,9,10].map(i => `<circle cx="${20 + i*16}" cy="60" r="2" fill="${i <= 6 ? 'var(--accent)' : 'var(--ink-faint)'}"/>`).join('')}
    <rect x="14" y="80" width="172" height="32" rx="6" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="22" y="92" font-family="JetBrains Mono" font-size="6" font-weight="700" letter-spacing="0.10em" fill="var(--accent)">SOLVING · STEP 7/11</text>
    <rect x="22" y="98" width="150" height="3" rx="1" fill="var(--bg-hover)"/>
    <rect x="22" y="98" width="95" height="3" rx="1" fill="var(--accent)"/>
    <text x="22" y="108" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)">~0.4s left · matrice 22×22</text>
  </svg>`;
  if (kind === 'empty') return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <g transform="translate(100 38)">
      <rect x="-22" y="-12" width="44" height="24" rx="4" fill="none" stroke="var(--accent)" stroke-width="1" stroke-dasharray="2 2"/>
      <circle cx="-18" cy="0" r="2" fill="var(--accent)"/>
      <circle cx="18" cy="0" r="2" fill="var(--accent)"/>
      <line x1="-18" y1="0" x2="18" y2="0" stroke="var(--accent)" stroke-width="1"/>
    </g>
    <text x="100" y="76" font-family="Plus Jakarta Sans" font-size="9" font-weight="700" fill="var(--ink)" text-anchor="middle">Inizia il tuo modello</text>
    <text x="100" y="86" font-family="Inter" font-size="6" fill="var(--ink-dim)" text-anchor="middle">Parti da un template, importa o costruisci da zero</text>
    <rect x="40" y="96" width="38" height="14" rx="4" fill="var(--accent)"/>
    <text x="59" y="105" font-family="Inter" font-size="6" font-weight="700" fill="#fff" text-anchor="middle">Nuovo</text>
    <rect x="82" y="96" width="38" height="14" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="101" y="105" font-family="Inter" font-size="6" fill="var(--ink)" text-anchor="middle">Template</text>
    <rect x="124" y="96" width="38" height="14" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="143" y="105" font-family="Inter" font-size="6" fill="var(--ink)" text-anchor="middle">Importa</text>
  </svg>`;
  if (kind === 'error') return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <rect x="14" y="14" width="172" height="40" rx="6" fill="var(--bg-danger)" stroke="var(--danger)" stroke-width="0.5"/>
    <circle cx="28" cy="34" r="6" fill="none" stroke="var(--danger)" stroke-width="1.4"/>
    <line x1="28" y1="31" x2="28" y2="34" stroke="var(--danger)" stroke-width="1.4"/>
    <circle cx="28" cy="37" r="0.8" fill="var(--danger)"/>
    <text x="40" y="30" font-family="Plus Jakarta Sans" font-size="8" font-weight="700" fill="var(--danger)">Solver fallito · matrice singolare</text>
    <text x="40" y="40" font-family="Inter" font-size="6" fill="var(--ink-muted)">Manca un vincolo — la struttura è labile.</text>
    <text x="40" y="48" font-family="JetBrains Mono" font-size="5" fill="var(--ink-dim)">cond(K) = ∞ · DOF labili: 3 · rank deficit</text>
    <rect x="14" y="60" width="120" height="14" rx="4" fill="var(--accent)"/>
    <text x="74" y="69" font-family="Inter" font-size="6" font-weight="700" fill="#fff" text-anchor="middle">▶ Auto-fix · aggiungi vincolo</text>
    <rect x="138" y="60" width="48" height="14" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="162" y="69" font-family="Inter" font-size="6" fill="var(--ink)" text-anchor="middle">Mostra log</text>
  </svg>`;
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <text x="100" y="52" font-family="Plus Jakarta Sans" font-size="36" font-weight="700" fill="var(--ink)" opacity="0.20" text-anchor="middle">404</text>
    <text x="100" y="68" font-family="Plus Jakarta Sans" font-size="9" font-weight="700" fill="var(--ink)" text-anchor="middle">Schermata non trovata</text>
    <text x="100" y="78" font-family="Inter" font-size="6" fill="var(--ink-dim)" text-anchor="middle">Forse cercavi una di queste:</text>
    <rect x="40" y="88" width="38" height="14" rx="4" fill="var(--accent)"/>
    <text x="59" y="97" font-family="Inter" font-size="6" font-weight="700" fill="#fff" text-anchor="middle">Dashboard</text>
    <rect x="82" y="88" width="38" height="14" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="101" y="97" font-family="Inter" font-size="6" fill="var(--ink)" text-anchor="middle">Studio</text>
    <rect x="124" y="88" width="38" height="14" rx="4" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.5"/>
    <text x="143" y="97" font-family="Inter" font-size="6" fill="var(--ink)" text-anchor="middle">Docs</text>
  </svg>`;
}

function thumbMobile() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <g transform="translate(72 8)">
      <rect width="56" height="108" rx="9" fill="var(--bg-panel)" stroke="var(--ink)" stroke-width="1.2"/>
      <rect x="2" y="2" width="52" height="104" rx="7" fill="var(--bg)"/>
      <rect x="22" y="3" width="14" height="3" rx="1.5" fill="var(--ink)"/>
      <text x="6" y="14" font-family="JetBrains Mono" font-size="4" fill="var(--ink-dim)">09:41</text>
      <text x="42" y="14" font-family="JetBrains Mono" font-size="4" fill="var(--ink-dim)" text-anchor="end">98%</text>
      <rect x="4" y="18" width="48" height="50" rx="3" fill="var(--bg-viewport)"/>
      <line x1="10" y1="44" x2="46" y2="44" stroke="var(--ink)" stroke-width="1"/>
      <circle cx="10" cy="44" r="1.6" fill="var(--ink)"/>
      <circle cx="28" cy="44" r="1.6" fill="var(--accent)"/>
      <circle cx="46" cy="44" r="1.6" fill="var(--ink)"/>
      <rect x="4" y="72" width="48" height="24" rx="3" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.4"/>
      <text x="6" y="80" font-family="JetBrains Mono" font-size="3" fill="var(--accent)">σ MAX</text>
      <text x="6" y="86" font-family="JetBrains Mono" font-size="6" font-weight="700" fill="var(--ink)">178 MPa</text>
      <rect x="4" y="100" width="48" height="4" rx="1" fill="var(--bg-panel)"/>
      <g transform="translate(8 101)">
        <circle cx="2" cy="2" r="1.4" fill="var(--accent)"/>
        <circle cx="14" cy="2" r="1.4" fill="var(--ink-dim)"/>
        <circle cx="26" cy="2" r="1.4" fill="var(--ink-dim)"/>
        <circle cx="38" cy="2" r="1.4" fill="var(--ink-dim)"/>
      </g>
    </g>
  </svg>`;
}

function thumbInspectorRef() {
  return `<svg viewBox="0 0 200 125" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="125" fill="var(--bg-hover)"/>
    <!-- 6 mini panels in 3×2 grid -->
    <g font-family="JetBrains Mono" font-size="4" fill="var(--ink-dim)">
      <g transform="translate(10 12)">
        <rect width="54" height="44" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.6"/>
        <rect x="3" y="3" width="10" height="4" fill="var(--ink-muted)"/>
        <text x="16" y="6.6" font-weight="700" fill="var(--ink)" font-size="3.4">NODE</text>
        <line x1="3" y1="11" x2="51" y2="11" stroke="var(--border)" stroke-width="0.4"/>
        <text x="3" y="17">x · y · z</text>
        <text x="3" y="23">DOF · 6</text>
        <g transform="translate(3 26)">
          <rect width="7" height="6" fill="var(--accent)" opacity="0.4"/>
          <rect x="8" width="7" height="6" fill="var(--accent)" opacity="0.4"/>
          <rect x="16" width="7" height="6" fill="var(--accent)" opacity="0.4"/>
          <rect x="24" width="7" height="6" fill="var(--bg)" stroke="var(--border)" stroke-width="0.3"/>
          <rect x="32" width="7" height="6" fill="var(--bg)" stroke="var(--border)" stroke-width="0.3"/>
          <rect x="40" width="7" height="6" fill="var(--bg)" stroke="var(--border)" stroke-width="0.3"/>
        </g>
      </g>
      <g transform="translate(73 12)">
        <rect width="54" height="44" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.6"/>
        <rect x="3" y="3" width="10" height="4" fill="var(--accent)"/>
        <text x="16" y="6.6" font-weight="700" fill="var(--ink)" font-size="3.4">BEAM</text>
        <line x1="3" y1="11" x2="51" y2="11" stroke="var(--border)" stroke-width="0.4"/>
        <text x="3" y="17">IPE 300 · S355</text>
        <text x="3" y="23">M_max @ x</text>
        <path d="M3 36 Q27 22 51 36" fill="none" stroke="var(--warn)" stroke-width="0.8"/>
        <line x1="27" y1="22" x2="27" y2="40" stroke="var(--warn)" stroke-width="0.4" stroke-dasharray="1,1"/>
      </g>
      <g transform="translate(136 12)">
        <rect width="54" height="44" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.6"/>
        <rect x="3" y="3" width="10" height="4" fill="var(--purple)"/>
        <text x="16" y="6.6" font-weight="700" fill="var(--ink)" font-size="3.4">SHELL</text>
        <line x1="3" y1="11" x2="51" y2="11" stroke="var(--border)" stroke-width="0.4"/>
        <text x="3" y="17">t = 12 mm</text>
        <text x="3" y="23">σ_vM · top</text>
        <g transform="translate(8 26)">
          <polygon points="0 0 40 0 38 14 2 14" fill="var(--purple)" opacity="0.2" stroke="var(--purple)" stroke-width="0.5"/>
        </g>
      </g>
      <g transform="translate(10 68)">
        <rect width="54" height="44" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.6"/>
        <rect x="3" y="3" width="10" height="4" fill="var(--coral)"/>
        <text x="16" y="6.6" font-weight="700" fill="var(--ink)" font-size="3.4">CABLE</text>
        <line x1="3" y1="11" x2="51" y2="11" stroke="var(--border)" stroke-width="0.4"/>
        <text x="3" y="17">N · 185 kN</text>
        <text x="3" y="23">TAUT ✓</text>
        <line x1="3" y1="34" x2="51" y2="34" stroke="var(--coral)" stroke-width="1.4"/>
        <circle cx="3" cy="34" r="1.4" fill="var(--ink)"/>
        <circle cx="51" cy="34" r="1.4" fill="var(--ink)"/>
      </g>
      <g transform="translate(73 68)">
        <rect width="54" height="44" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.6"/>
        <rect x="3" y="3" width="10" height="4" fill="var(--warn)"/>
        <text x="16" y="6.6" font-weight="700" fill="var(--ink)" font-size="3.4">PLATE</text>
        <line x1="3" y1="11" x2="51" y2="11" stroke="var(--border)" stroke-width="0.4"/>
        <text x="3" y="17">C30/37 · h=200</text>
        <text x="3" y="23">As_x · 10.26</text>
        <g transform="translate(3 27)">
          <line x1="0" y1="0" x2="48" y2="0" stroke="var(--ink-dim)" stroke-width="0.3"/>
          <line x1="0" y1="3" x2="48" y2="3" stroke="var(--ink-dim)" stroke-width="0.3"/>
          <line x1="0" y1="6" x2="48" y2="6" stroke="var(--ink-dim)" stroke-width="0.3"/>
          <line x1="0" y1="9" x2="48" y2="9" stroke="var(--ink-dim)" stroke-width="0.3"/>
          <line x1="0" y1="12" x2="48" y2="12" stroke="var(--ink-dim)" stroke-width="0.3"/>
        </g>
      </g>
      <g transform="translate(136 68)">
        <rect width="54" height="44" fill="var(--bg-panel)" stroke="var(--border)" stroke-width="0.6"/>
        <rect x="3" y="3" width="10" height="4" fill="var(--ink-muted)"/>
        <text x="16" y="6.6" font-weight="700" fill="var(--ink)" font-size="3.4">×24</text>
        <line x1="3" y1="11" x2="51" y2="11" stroke="var(--border)" stroke-width="0.4"/>
        <text x="3" y="17">aggregate</text>
        <g transform="translate(3 22)">
          <rect x="0" y="14" width="3" height="4" fill="var(--success)"/>
          <rect x="4" y="10" width="3" height="8" fill="var(--success)"/>
          <rect x="8" y="6" width="3" height="12" fill="var(--success)"/>
          <rect x="12" y="3" width="3" height="15" fill="var(--success)"/>
          <rect x="16" y="7" width="3" height="11" fill="var(--success)"/>
          <rect x="20" y="11" width="3" height="7" fill="var(--success)"/>
          <rect x="24" y="13" width="3" height="5" fill="var(--success)"/>
          <rect x="28" y="14" width="3" height="4" fill="var(--success)"/>
          <rect x="32" y="13" width="3" height="5" fill="var(--warn)"/>
          <rect x="36" y="14" width="3" height="4" fill="var(--warn)"/>
          <rect x="40" y="15" width="3" height="3" fill="var(--warn)"/>
          <rect x="44" y="14" width="3" height="4" fill="var(--danger)"/>
        </g>
      </g>
    </g>
  </svg>`;
}


// ── Renderer ────────────────────────────────────────────────────

const STATUS_BADGE = {
  done: { cls: "badge-done", txt: "DONE" },
  next: { cls: "badge-new",  txt: "NEXT UP" },
  wip:  { cls: "badge-wip",  txt: "WIP" },
  todo: { cls: "badge-todo", txt: "TODO" },
};

function cardHTML(item) {
  const badge = STATUS_BADGE[item.status] || STATUS_BADGE.todo;
  const featured = item.status === "next" ? " featured" : "";
  const meta = (item.meta || []).map((m, i) =>
    `${i > 0 ? '<span class="dot"></span>' : ''}<span>${m}</span>`
  ).join("");
  return `
    <a class="card${featured}" href="${item.href}">
      <div class="card-thumb">${item.thumb}</div>
      <div class="card-body">
        <div class="card-head">
          <h3>${item.title}</h3>
          <span class="badge ${badge.cls}">${badge.txt}</span>
        </div>
        <p class="card-desc">${item.desc}</p>
        <div class="card-meta">
          <span class="card-path">${item.path}</span>
          ${meta ? `<span class="dot"></span>${meta}` : ""}
        </div>
      </div>
    </a>
  `;
}

function sectionHTML(section) {
  const total = section.items.length;
  const done  = section.items.filter(i => i.status === "done").length;
  const pct   = total > 0 ? Math.round(done / total * 100) : 0;
  const allDone = done === total && total > 0;
  return `
    <section class="section">
      <div class="section-head">
        <span class="section-num">${section.num}</span>
        <h2>${section.title}</h2>
        <span class="section-count">${total} file${total === 1 ? '' : ''}</span>
        <div class="section-progress">
          <div class="bar"><i class="${allDone ? 'done' : ''}" style="width:${pct}%;"></i></div>
          <span class="pct${allDone ? ' done' : ''}">${done}/${total}</span>
        </div>
      </div>
      <div class="grid">
        ${section.items.map(cardHTML).join("")}
      </div>
    </section>
  `;
}

// Render
const root = document.getElementById("sections");
root.innerHTML = SECTIONS.map(sectionHTML).join("");

// Global progress
const allItems = SECTIONS.flatMap(s => s.items);
const totalCards = allItems.length;
const doneCards  = allItems.filter(i => i.status === "done").length;
document.getElementById("prog-num").textContent = doneCards;
document.getElementById("prog-tot").textContent = totalCards;
document.getElementById("prog-fill").style.width = (totalCards ? (doneCards / totalCards * 100) : 0) + "%";
