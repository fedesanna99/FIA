// FEA Pro · Nuovo Guscio — Right Panel
// Contenuto del workspace destra: header workspace + tabs + scroll area.
// Workspace principale dimostrato: Risultati (modello già risolto).
// Stub leggeri per gli altri workspace, attivabili da tweak.

// ───────────────────────────────────────────────────────────────────────
// Helpers
// ───────────────────────────────────────────────────────────────────────
function SectionHead({ title, action }) {
  return (
    <div className="sp-section-head">
      <span className="sp-section-title">{title}</span>
      {action && <button type="button" className="sp-section-action">{action}</button>}
    </div>
  );
}

function Slider({ label, value, min, max, ticks, unit, suffix }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="slider-row">
      <div className="slider-head">
        <span className="slider-label">{label}</span>
        <span className="slider-val">{value}{unit ? ` ${unit}` : ""}{suffix || ""}</span>
      </div>
      <div className="slider-track">
        <div className="slider-fill" style={{ width: pct + "%" }} />
        <div className="slider-thumb" style={{ left: pct + "%" }} />
      </div>
      {ticks && (
        <div className="slider-ticks">
          {ticks.map(t => <span key={t}>{t}</span>)}
        </div>
      )}
    </div>
  );
}

function DisplayRow({ on, name, icon, meta, color }) {
  const I = icon && window.Icon[icon];
  return (
    <div
      role="button"
      tabIndex={0}
      className={"display-row " + (on ? "on" : "")}
    >
      <div className="display-checkbox">
        {on && <Icon.Check s={11} />}
      </div>
      <div>
        <div className="display-name">
          {I && <span className="display-icon"><I s={13} /></span>}
          {name}
        </div>
        {meta && <div className="display-meta" style={color ? { color } : null}>{meta}</div>}
      </div>
      <button
        type="button"
        className="tb-iconbtn"
        style={{ width: 22, height: 22 }}
        aria-label="Impostazioni layer"
        onClick={(e) => e.stopPropagation()}
      >
        <Icon.Sliders s={11} />
      </button>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────
// RISULTATI workspace content (the one we're showcasing)
// ───────────────────────────────────────────────────────────────────────
function WSRisultati() {
  return (
    <>
      {/* Section: Snapshot */}
      <div className="sp-section">
        <SectionHead title="Snapshot · static_01" action="Confronta" />
        <div className="snap-row current">
          <div>
            <div className="snap-name">
              <span style={{
                width: 8, height: 8, borderRadius: 9999,
                background: "var(--accent)", display: "inline-block"
              }} />
              Current
              <span className="snap-time">· 14:31:42</span>
            </div>
          </div>
          <span className="snap-delta zero">Δ —</span>
        </div>
        <div className="snap-row">
          <div>
            <div className="snap-name">
              <span style={{
                width: 8, height: 8, borderRadius: 9999,
                background: "var(--ink-faint)", display: "inline-block"
              }} />
              Pre-LTB
              <span className="snap-time">· 13:18:05</span>
            </div>
          </div>
          <span className="snap-delta pos">+12.3%</span>
        </div>
      </div>

      {/* Section: Metriche post-analisi */}
      <div className="sp-section">
        <SectionHead title="Risultati globali" action="Esporta" />
        <div className="metrics">
          <div className="metric">
            <span className="metric-k">δ_max</span>
            <span className="metric-v">9.61<small>mm</small></span>
            <span className="metric-sub">@ x = 3.00 m · N₆</span>
          </div>
          <div className="metric warn">
            <span className="metric-k">σ_max</span>
            <span className="metric-v">178<small>MPa</small></span>
            <span className="metric-sub">@ EL 5 · σ_VM</span>
          </div>
          <div className="metric">
            <span className="metric-k">f₁</span>
            <span className="metric-v">8.42<small>Hz</small></span>
            <span className="metric-sub">flessionale verticale</span>
          </div>
        </div>
        <div style={{
          marginTop: 10, padding: "8px 10px",
          background: "var(--bg-info)",
          border: "1px solid rgba(var(--accent-rgb), 0.25)",
          borderRadius: 8, fontSize: 11,
          fontFamily: "JetBrains Mono, monospace",
          color: "var(--ink-muted)",
          display: "flex", alignItems: "flex-start", gap: 8
        }}>
          <Icon.Info s={12} />
          <span>
            EC3 §6.2.5 — M_Ed = 45.0 kNm · M_c,Rd = 188 kNm.<br/>
            <span style={{ color: "var(--accent)", fontWeight: 700 }}>UR_σ = 0.24</span> · governing: LTB (vedi sotto).
          </span>
        </div>
      </div>

      {/* Section: Display toggles (which layers to show in viewport) */}
      <div className="sp-section">
        <SectionHead title="Visualizza" />
        <div className="display-list">
          <DisplayRow on name="Deformata" icon="Wave" meta="scala 200× · max δ = 9.61 mm" />
          <DisplayRow on name="Stress σ Von Mises" icon="Layers" meta="colormap Jet · 0–178 MPa" />
          <DisplayRow name="Diagrammi N/V/M" icon="Chart" meta="hidden — apri tab Diagrammi" />
          <DisplayRow name="Forma modale φ₁" icon="Activity" meta="hidden — analisi modale" />
          <DisplayRow on name="Stress σ₁/σ₂ principali" icon="Beam" meta="vettori solo su elementi shell/T3" color="var(--ink-faint)" />
        </div>
      </div>

      {/* Section: Scala deformazione */}
      <div className="sp-section">
        <SectionHead title="Scala deformazione" action="Auto" />
        <Slider
          label="Fattore visualizzazione"
          value={200}
          min={1}
          max={500}
          ticks={["1×", "50×", "100×", "200×", "500×"]}
          suffix="×"
        />
      </div>

      {/* Section: EC3 Verify */}
      <div className="sp-section">
        <SectionHead title="Verifica EC3 · acciaio" action="Apri report" />
        <div className="ur-strip">
          {[
            { id: 1, ur: 0.08, gov: "RES" },
            { id: 2, ur: 0.14, gov: "RES" },
            { id: 3, ur: 0.19, gov: "RES" },
            { id: 4, ur: 0.22, gov: "LTB" },
            { id: 5, ur: 0.24, gov: "LTB", sel: true },
            { id: 6, ur: 0.22, gov: "LTB" },
            { id: 7, ur: 0.19, gov: "RES" },
          ].map(r => (
            <div key={r.id} className={"ur-row" + (r.sel ? " selected" : "") + (r.ur > 0.30 ? " warn" : "")}>
              <span className="ur-tag">EL {r.id}</span>
              <div className="ur-bar">
                <div
                  className={"ur-bar-fill" + (r.ur > 0.80 ? " danger" : (r.ur > 0.50 ? " warn" : ""))}
                  style={{ width: (r.ur * 100) + "%" }}
                />
              </div>
              <span className="ur-val">{r.ur.toFixed(2)}</span>
              <span className="ur-gov">{r.gov}</span>
            </div>
          ))}
        </div>
        <div style={{
          marginTop: 8, fontFamily: "JetBrains Mono, monospace",
          fontSize: 10, color: "var(--ink-dim)", letterSpacing: 0.04
        }}>
          UR_max = 0.24 · 7/10 elementi visualizzati · <a href="#" style={{ color: "var(--accent)" }}>mostra tutti</a>
        </div>
      </div>

      {/* Section: Inspector element 5 */}
      <div className="sp-section">
        <SectionHead title="Ispettore · EL 5" action="Espandi" />
        <div className="inspector-card">
          <div className="inspector-head">
            <span className="inspector-tag">EL 5</span>
            <span className="inspector-title">Beam · IPE 300 · S355</span>
          </div>
          <dl className="inspector-kv">
            <dt>N₅ → N₆</dt><dd>(2.40, 0, 0) → (3.00, 0, 0)</dd>
            <dt>L</dt><dd>0.600 m</dd>
            <dt>A</dt><dd>53.81 cm²</dd>
            <dt>I_y</dt><dd>8356 cm⁴</dd>
            <dt>W_pl,y</dt><dd>628.4 cm³</dd>
            <dt>fyk · fyd</dt><dd>355 · 338 MPa</dd>
          </dl>
          <div style={{ height: 1, background: "var(--border)" }} />
          <dl className="inspector-kv">
            <dt style={{ color: "var(--ink)", fontWeight: 600 }}>M_Ed</dt><dd style={{ color: "var(--warn)" }}>45.00 kNm</dd>
            <dt style={{ color: "var(--ink)", fontWeight: 600 }}>V_Ed</dt><dd>15.00 kN</dd>
            <dt>M_c,Rd</dt><dd>188.4 kNm</dd>
            <dt>M_b,Rd · χ_LT</dt><dd>187.5 · 0.995</dd>
            <dt style={{ color: "var(--accent)", fontWeight: 700 }}>UR_max</dt><dd style={{ color: "var(--accent)", fontWeight: 700 }}>0.240</dd>
          </dl>
        </div>
      </div>

      {/* Footer actions */}
      <div className="sp-section" style={{ borderBottom: "none" }}>
        <div style={{ display: "flex", gap: 8 }}>
          <button type="button" className="btn btn-outline btn-sm" style={{ flex: 1, borderRadius: 8 }}>
            <Icon.Camera s={13} /> Snapshot
          </button>
          <button type="button" className="btn btn-outline btn-sm" style={{ flex: 1, borderRadius: 8 }}>
            <Icon.Download s={13} /> Report PDF
          </button>
        </div>
      </div>
    </>
  );
}

// ───────────────────────────────────────────────────────────────────────
// Placeholder content for other workspaces — light but coherent
// ───────────────────────────────────────────────────────────────────────
function WSModello() {
  return (
    <>
      <div className="sp-section">
        <SectionHead title="Albero modello" action="Espandi tutto" />
        <div className="display-list">
          <DisplayRow on name="Nodi" icon="Crosshair" meta="11 elementi" />
          <DisplayRow on name="Beam · IPE 300" icon="Beam" meta="10 elementi · S355" />
          <DisplayRow on name="Carichi" icon="ArrowDown" meta="1 · q = 10.0 kN/m distribuito" />
          <DisplayRow on name="Vincoli" icon="Triangle" meta="2 · cerniera + carrello_y" />
        </div>
      </div>

      <div className="sp-section">
        <SectionHead title="Mesh wizard" action="?" />
        <div className="display-list">
          <DisplayRow on name="Lineare" icon="Beam" meta="line + n_div · beam2d/3d/truss · attivo" />
          <DisplayRow name="Quadrilatera" icon="Grid" meta="4 corners · shell Q4" />
          <DisplayRow name="Triangolare" icon="Triangle" meta="4 corners · tri T3" />
          <DisplayRow name="Box solida" icon="Cube" meta="origin + sizes · solid H8" />
          <DisplayRow name="Parametrica" icon="Sparkles" meta="L · T · cerchio · anello — NEW" />
        </div>
      </div>

      <div className="sp-section">
        <SectionHead title="Schema avanzato" action="?" />
        <div className="display-list">
          <DisplayRow name="Beam su suolo elastico" icon="Wave" meta="Element.winkler_k · ora editabile da UI" />
          <DisplayRow name="Release cerniera interna" icon="Move" meta="rilascia momento fine/inizio" />
          <DisplayRow name="Vincolo solo compressione" icon="ArrowDown" meta="Constraint.compression_only" />
        </div>
      </div>
    </>
  );
}

function WSAnalisi() {
  return (
    <>
      <div className="sp-section">
        <SectionHead title="Tipo analisi" action="?" />
        <div className="display-list">
          <DisplayRow on name="Statica lineare" icon="Activity" meta="K u = F · ultima eseguita 14:31" />
          <DisplayRow name="Modale" icon="Wave" meta="(K - ω²M)φ = 0 · ARPACK · n_modes = 6" />
          <DisplayRow name="Dinamica Newmark" icon="Chart" meta="β = 0.25 · γ = 0.50 · Rayleigh α/β" />
          <DisplayRow name="Buckling" icon="Layers" meta="K φ = λ K_G φ · n critici" />
          <DisplayRow name="Push-over" icon="Sparkles" meta="non-lineare incrementale — NEW" />
          <DisplayRow name="Sismica time-history" icon="Wave" meta="accelerogramma X/Y/Z + drift" />
        </div>
      </div>
      <div className="sp-section">
        <SectionHead title="Parametri · Statica" action="Reset" />
        <Slider label="Tolleranza solver" value={1} min={0.01} max={10} ticks={["1e-6","1e-3","1e-1"]} unit="e-6" />
        <Slider label="Max iterazioni" value={50} min={10} max={500} ticks={["10","100","500"]} />
      </div>
    </>
  );
}

function WSVerifiche() {
  return (
    <>
      <div className="sp-section">
        <SectionHead title="Normative" />
        <div className="display-list">
          <DisplayRow on name="EC3 · Acciaio" icon="Check2" meta="resistance · stability · LTB · attivo" />
          <DisplayRow name="EC2 · Calcestruzzo" icon="Layers" meta="flessione + taglio sez. rettangolare — NEW" />
          <DisplayRow name="EC5 · Legno" icon="Beam" meta="trazione/comp/flex/taglio · k_mod — NEW" />
          <DisplayRow name="EC8 · Sismica" icon="Wave" meta="spettro elastico 4-rami · q · zone IT — NEW" />
          <DisplayRow name="NTC 2018" icon="BookOpen" meta="combinazioni SLU/SLE · ψ · envelope — NEW" />
        </div>
      </div>
      <div className="sp-section">
        <SectionHead title="EC3 · UR per elemento" action="Esporta tabella" />
        <div className="ur-strip">
          {[
            { id: 1, ur: 0.08 }, { id: 2, ur: 0.14 }, { id: 3, ur: 0.19 },
            { id: 4, ur: 0.22 }, { id: 5, ur: 0.24 }, { id: 6, ur: 0.22 },
            { id: 7, ur: 0.19 }, { id: 8, ur: 0.14 }, { id: 9, ur: 0.08 }, { id: 10, ur: 0.04 },
          ].map(r => (
            <div key={r.id} className="ur-row">
              <span className="ur-tag">EL {r.id}</span>
              <div className="ur-bar">
                <div className="ur-bar-fill" style={{ width: (r.ur * 100) + "%" }} />
              </div>
              <span className="ur-val">{r.ur.toFixed(2)}</span>
              <span className="ur-gov">LTB</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function WSIO() {
  return (
    <>
      <div className="sp-section">
        <SectionHead title="Import" />
        <div className="dropzone" style={{ borderRadius: 10 }}>
          <Icon.FileUp s={16} />
          <span><b>Trascina</b> .json · .dxf · .ifc qui</span>
        </div>
      </div>
      <div className="sp-section">
        <SectionHead title="Export" action="Tutti i formati" />
        <div className="display-list">
          <DisplayRow name="Report PDF (reportlab)" icon="Download" meta="7 sezioni · include statica + modale" />
          <DisplayRow name="Excel multi-sheet (openpyxl)" icon="Download" meta="5-8 sheet stilizzati" />
          <DisplayRow name="DXF · CAD" icon="Download" meta="FEA_* layers strutturati" />
          <DisplayRow name="IFC4 · BIM" icon="Download" meta="storey + axis" />
        </div>
      </div>
      <div className="sp-section">
        <SectionHead title="Strumenti avanzati" />
        <div className="display-list">
          <DisplayRow name="Compare A vs B" icon="Shuffle" meta="diff strutturale + Δ% risultati" />
          <DisplayRow name="Auto-detect" icon="Bug" meta="5 detector + fix automatici" />
          <DisplayRow name="Accelerogrammi" icon="Wave" meta="PEER/ESM + Kanai-Tajimi sintetico" />
          <DisplayRow name="AI Copilot" icon="Sparkles" meta="Q&A sul modello · ⌘K integrato" />
        </div>
      </div>
    </>
  );
}

// ───────────────────────────────────────────────────────────────────────
// ShellPanel — full right panel host
// ───────────────────────────────────────────────────────────────────────
function ShellPanel({ workspace = "risultati" }) {
  const config = {
    risultati: {
      icon: "Activity",
      title: "Risultati",
      desc: "Visualizza e interpreta i risultati dell'ultima analisi statica.",
      tabs: [
        { id: "viewport", name: "Viewport", count: null, active: true },
        { id: "diagrammi", name: "Diagrammi" },
        { id: "postprocess", name: "Postprocess" },
        { id: "qualita", name: "Qualità" },
      ],
      content: <WSRisultati />,
    },
    modello: {
      icon: "Cube",
      title: "Modello",
      desc: "Costruisci la struttura: geometria, mesh, sezioni, materiali.",
      tabs: [
        { id: "albero", name: "Albero", count: 24, active: true },
        { id: "mesh", name: "Mesh" },
        { id: "sezioni", name: "Sezioni · Materiali" },
        { id: "schema", name: "Schema" },
      ],
      content: <WSModello />,
    },
    analisi: {
      icon: "Cog",
      title: "Analisi",
      desc: "Scegli il tipo di analisi, configura i parametri, lancia il solver.",
      tabs: [
        { id: "lineari", name: "Lineari", active: true },
        { id: "nonlineari", name: "Non lineari" },
        { id: "avanzato", name: "Avanzato" },
        { id: "monitor", name: "Monitor" },
      ],
      content: <WSAnalisi />,
    },
    verifiche: {
      icon: "Check2",
      title: "Verifiche",
      desc: "Confronto domanda vs resistenza secondo Eurocodici e NTC 2018.",
      tabs: [
        { id: "ec3", name: "EC3", active: true },
        { id: "ec2", name: "EC2", count: "NEW" },
        { id: "ec5", name: "EC5", count: "NEW" },
        { id: "ec8", name: "EC8", count: "NEW" },
        { id: "ntc", name: "NTC18", count: "NEW" },
      ],
      content: <WSVerifiche />,
    },
    io: {
      icon: "Shuffle",
      title: "I/O & Collab",
      desc: "Import/Export server-side, accelerogrammi, compare A/B, AI Copilot, collaborazione live.",
      tabs: [
        { id: "import", name: "Import", active: true },
        { id: "export", name: "Export" },
        { id: "compare", name: "Compare" },
        { id: "ai", name: "AI · Collab" },
      ],
      content: <WSIO />,
    },
  };

  const c = config[workspace] || config.risultati;
  const HeaderIcon = window.Icon[c.icon];

  return (
    <aside className="shell-panel" aria-label="Pannello workspace">
      <div className="sp-head">
        <div className="sp-head-row">
          <div className="sp-icon"><HeaderIcon s={16} /></div>
          <h2>{c.title}</h2>
          <button type="button" className="sp-help" aria-label="Aiuto">?</button>
        </div>
        <p className="sp-desc">{c.desc}</p>
      </div>

      <div className="sp-tabs" role="tablist">
        {c.tabs.map(t => (
          <button
            key={t.id}
            type="button"
            role="tab"
            className={"sp-tab " + (t.active ? "active" : "")}
            aria-selected={!!t.active}
          >
            {t.name}
            {t.count != null && <span className="sp-tab-count">{t.count}</span>}
          </button>
        ))}
      </div>

      <div className="sp-body">
        {c.content}
      </div>
    </aside>
  );
}

Object.assign(window, {
  ShellPanel,
  WSRisultati, WSModello, WSAnalisi, WSVerifiche, WSIO,
  SectionHead, Slider, DisplayRow,
});
